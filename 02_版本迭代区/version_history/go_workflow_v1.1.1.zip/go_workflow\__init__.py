bl_info = {
    "name": "Go工作流 / Go Workflow",
    "author": "OpenAI Codex",
    "version": (1, 1, 1),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Go工作流",
    "description": "基于工作流的 N 面板筛选与自定义脚本模块工具 / Workflow panel filter and script module manager",
    "category": "3D View",
}

# AI定位：插件升版本时同步更新这里的 bl_info["version"]、__version__ 和 blender_manifest.toml。
__version__ = (1, 1, 1)

import json
import csv
import hashlib
import inspect
import os
import re
import shutil
import subprocess
import sys
import time
import ctypes
import traceback
import uuid
import tempfile
import zipfile
from datetime import datetime

import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .panel_scan import (
    discover_sidebar_panels as shared_discover_sidebar_panels,
    is_registered_panel_class as shared_is_registered_panel_class,
    iter_panel_subclasses as shared_iter_panel_subclasses,
    iter_registered_panel_classes as shared_iter_registered_panel_classes,
    panel_display_category as shared_panel_display_category,
    panel_registration_order_map as shared_panel_registration_order_map,
)
from .text_utils import (
    is_placeholder_ui_text as shared_is_placeholder_ui_text,
    is_suspicious_ui_text as shared_is_suspicious_ui_text,
    normalize_text_value as shared_normalize_text_value,
    normalize_workflow_description as shared_normalize_workflow_description,
    normalize_workflow_name as shared_normalize_workflow_name,
    unique_name_from_existing as shared_unique_name_from_existing,
)
from .workflow_counts import (
    drawer_count_for_entries as shared_drawer_count_for_entries,
    panel_count_label as shared_panel_count_label,
)
from .native_reference import BWFLOW_OT_native_reference_cleanup, BWFLOW_OT_native_reference_viewer


WORKFLOW_CATEGORY = "Go工作流"
SCHEMA_VERSION = 6
CURRENT_WORKFLOW_PRESET_KIND = "active_workflow"
PRESET_FILE_EXTENSION = ".gwpreset"
PRESET_FILE_FILTER = "*.gwpreset"
LEGACY_PRESET_FILE_FILTER = "*.goworkflow;*.goworkflow.zip;*.bworkflow"
SCRIPT_LIBRARY_DOC_URL = "https://docs.qq.com/sheet/DRUNEZ0RFUXdtU2FS"
WORKFLOW_SWITCHER_COLUMNS = 4
AI_DOC_LEGACY_MAX_CHARS = 6200
AI_DOC_DESCRIPTION_MAX_CHARS = 900
MAX_RNA_TEXT_CHARS = 256 * 1024
MAX_RNA_SCRIPT_CHARS = 1024 * 1024
MAX_RNA_SHORT_TEXT_CHARS = 4096
MAX_RNA_NAME_CHARS = 512
MAX_RESTORED_PANEL_TEXT_CHARS = 255
MAX_PRESET_IMPORT_RNA_TEXT_CHARS = 2048
UI_LABEL_MAX_CHARS = 56
UI_BUTTON_MAX_CHARS = 24
PANEL_GROUP_DRAW_LIMIT = 12
SELECTED_PANEL_GROUP_DRAW_LIMIT = 12
MAX_PRESET_FILE_BYTES = 50 * 1024 * 1024
MAX_PRESET_MANIFEST_BYTES = 8 * 1024 * 1024
MAX_PRESET_SCRIPT_ASSET_BYTES = 8 * 1024 * 1024
MAX_GLOBAL_STATE_FILE_BYTES = 12 * 1024 * 1024
DEFAULT_WORKFLOW_NAME = "默认工作流"
DEFAULT_WORKFLOW_DESCRIPTION = "这是默认的工作流配置，可自定义面板与脚本模板"
SUPPORTED_SPACE_TYPES = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "NODE_EDITOR",
)
SPACE_LABELS = {
    "VIEW_3D": "3D视图",
    "IMAGE_EDITOR": "图像/UV编辑器",
    "NODE_EDITOR": "节点/着色器编辑器",
}
SPACE_STATE_PROP_NAMES = {
    "VIEW_3D": "bworkflow_state_view3d",
    "IMAGE_EDITOR": "bworkflow_state_image_editor",
    "NODE_EDITOR": "bworkflow_state_node_editor",
}
GLOBAL_WORKFLOW_FILENAME = "go_workflow_global_state.json"
SPECIAL_PRESET_ARKIT_52 = "arkit_52_reference"

SETTINGS_TABS = [
    ("WORKFLOWS", "工作流", "管理工作流列表与默认工作流"),
    ("PANELS", "面板库", "按工作流勾选需要显示的第三方 N 面板"),
    ("MODULES", "脚本模板", "维护工作流自定义脚本模块模板"),
    ("SCRIPTS", "脚本库", "存放可复用的脚本模板与说明"),
    ("PRESETS", "预设", "导入导出共享工作流"),
    ("GLOBAL", "全局", "配置 Go工作流 的显示与调试选项"),
]

PANEL_CLASS_CACHE_BY_SPACE = {}
PANEL_CLASS_REGISTRY_BY_SPACE = {}
PANEL_POLL_CALLERS = {}
PANEL_POLL_ORIGINALS = {}
PANEL_POLL_TARGETS = {}
PANEL_POLL_ERROR_KEYS = set()
PANEL_DRAW_ORIGINALS = {}
PANEL_DRAW_HEADER_ORIGINALS = {}
PANEL_DRAW_ERROR_KEYS = set()
PANEL_BL_ORDER_ORIGINALS = {}
UNREGISTERED_PANEL_IDS = set()
ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE = {}
PANEL_GROUP_INDEX_CACHE_BY_SPACE = {}
PANEL_REGISTRY_LOOKUP_CACHE_BY_SPACE = {}
PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE = {}
PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE = {}
SELECTED_PANEL_GROUPS_CACHE_BY_SPACE = {}
SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE = {}
PANEL_VISIBILITY_DATA_CACHE_BY_SPACE = {}
WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE = {}
PANEL_GROUP_FILTER_CACHE_BY_SPACE = {}
PANEL_DRAWER_ROOT_CACHE_BY_SPACE = {}
WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE = {}
WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE = {}
RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE = {}
PANEL_ORDER_SIGNATURE_BY_SPACE = {}
PANEL_FILTER_SIGNATURE_BY_SPACE = {}
FILE_TEXT_CACHE = {}
FILE_JSON_CACHE = {}
IMAGE_PREVIEW_ICON_CACHE = {}
PRESET_IMPORT_ENTRY_CACHE = {}
PRESET_IMPORT_ACTIVE_KEYS = set()
IMPORTED_PRESET_ASSET_PATH_CACHE = {}
IMPORTED_WORKFLOW_PANEL_MATCH_CACHE = {}
IMPORTED_WORKFLOW_MISSING_MATCH_CACHE = {}
BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE = {"signature": None, "payloads": []}
LOAD_HANDLER_REGISTERED = False
IS_INITIALIZING_ADDON = False
PRE_GO_WORKFLOW_STATE = None
PANEL_CUSTOM_ICON_PREVIEWS = None
PANEL_CUSTOM_ICON_CACHE = {}
PANEL_GROUP_ICON_CACHE_BY_SPACE = {}
WORKSPACE_TOOL_CLASSES_CACHE = None
PANEL_POLL_MISSING = object()
PANEL_BL_ORDER_MISSING = object()
BROKEN_PANEL_POLL_IDS = {
    "SPIO_PT_PrefPanel",
}
DEFERRED_REFRESH_INTERVALS = (0.25,)
DEFERRED_REFRESH_TOKENS = {}
DEFERRED_REFRESH_PENDING_KEYS = set()
DEFERRED_WORKFLOW_SWITCH_PENDING_KEYS = set()
DEFERRED_SAVE_INTERVAL = 0.35
DEFERRED_SAVE_PENDING_SCENES = set()
IMPORTED_PRESET_PRUNE_PENDING_SCENES = set()
DOUBLE_CLICK_SECONDS = 1.0
DOUBLE_CLICK_CLICK_COUNT = 2
TRACKED_ONE_SHOT_TIMER_CALLBACKS = set()
MODULE_RUNTIME_CLEANUP_CACHE = {}
MODULE_RUNTIME_NAMESPACE_CACHE = {}
MODULE_SOURCE_TEXT_CACHE = {}
MODULE_RUNTIME_FIELD_INIT_CACHE = {}
MODULE_RUNTIME_VOLATILE_STORE = {}
MODULE_RUNTIME_FIELD_SYNC_QUEUE = {}
MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = False
CACHED_MODULE_STATE_PROXY_CLASS = None
CACHED_MODULE_PANEL_API_CLASS = None
BUILTIN_DEFAULT_PANEL_PREFIXES = (
    "bl_ui.",
    "bpy_types",
)
BUILTIN_PANEL_CATEGORY_MAP = {
    "VIEW3D_PT_context_properties": "Item",
    "VIEW3D_PT_view3d_properties": "View",
    "VIEW3D_PT_view3d_lock": "View",
    "VIEW3D_PT_view3d_cursor": "View",
    "VIEW3D_PT_grease_pencil": "View",
    "VIEW3D_PT_collections": "View",
    "VIEW3D_PT_active_tool": "Tool",
    "VIEW3D_PT_tools_object_options": "Tool",
    "VIEW3D_PT_tools_object_options_transform": "Tool",
    "WORKSPACE_PT_main": "Tool",
    "WORKSPACE_PT_custom_props": "Tool",
    "WORKSPACE_PT_addons": "Tool",
    "NODE_PT_backdrop": "View",
    "NODE_PT_annotation": "View",
    "NODE_PT_active_tool": "Tool",
    "IMAGE_PT_view_display": "View",
    "IMAGE_PT_uv_cursor": "View",
    "IMAGE_PT_annotation": "View",
    "IMAGE_PT_active_tool": "Tool",
    "NODE_WORLD_PT_viewport_display": "Options",
    "NODE_PT_quality": "Options",
    "NODE_MATERIAL_PT_viewport": "Options",
    "NODE_EEVEE_MATERIAL_PT_settings": "Options",
    "NODE_DATA_PT_light": "Options",
    "NODE_DATA_PT_EEVEE_light": "Options",
    "NODE_CYCLES_WORLD_PT_settings_volume": "Options",
    "NODE_CYCLES_WORLD_PT_settings_surface": "Options",
    "NODE_CYCLES_WORLD_PT_settings": "Options",
    "NODE_CYCLES_WORLD_PT_ray_visibility": "Options",
    "NODE_CYCLES_MATERIAL_PT_settings_volume": "Options",
    "NODE_CYCLES_MATERIAL_PT_settings_surface": "Options",
    "NODE_CYCLES_MATERIAL_PT_settings": "Options",
    "NODE_CYCLES_LIGHT_PT_light": "Options",
    "NODE_CYCLES_LIGHT_PT_beam_shape": "Options",
}
# 统一占位符/乱码检测
PLACEHOLDER_UI_TEXTS = {
    "ok",
    "好的",
    "确认",
}
SUSPICIOUS_TEXT_TOKENS = (
    "?" * 4,
    "\u95bf?",
    "\u95b5?",
    "\u95c2?",
    "\u9420?",
    "\u95b9?",
    "\u7f02?",
    "\u95b8?",
    "\u6fe1?",
    "\u7f01?",
    "\u745c?",
    "\u59d2?",
    "\u95b3?",
    "\u95c1?",
    "\u6fde?",
    "\u5a34?",
    "\u95bb?",
    "\u7f01?",
    "\u95ba?",
    "\u5a62?",
    "\u95bc?",
    "\u93bc?",
    "\u9353?",
    "\u9418?",
)


def _register_one_shot_timer(callback, first_interval=0.0):
    def _wrapped(callback=callback):
        try:
            return callback()
        finally:
            TRACKED_ONE_SHOT_TIMER_CALLBACKS.discard(_wrapped)

    TRACKED_ONE_SHOT_TIMER_CALLBACKS.add(_wrapped)
    bpy.app.timers.register(_wrapped, first_interval=first_interval)
    return _wrapped


def _cancel_tracked_one_shot_timers():
    callbacks = list(TRACKED_ONE_SHOT_TIMER_CALLBACKS)
    TRACKED_ONE_SHOT_TIMER_CALLBACKS.clear()
    removed = 0
    for callback in callbacks:
        try:
            bpy.app.timers.unregister(callback)
        except Exception:
            pass
        removed += 1
    return removed


def capture_pre_go_workflow_state():
    global PRE_GO_WORKFLOW_STATE
    if PRE_GO_WORKFLOW_STATE is not None:
        return PRE_GO_WORKFLOW_STATE

    system = getattr(getattr(bpy.context, "preferences", None), "system", None)
    compact_tabs = None
    if system is not None and hasattr(system, "show_panel_tabs_compact"):
        try:
            compact_tabs = bool(system.show_panel_tabs_compact)
        except Exception:
            compact_tabs = None

    panel_orders = {}
    panel_order_indices = {}
    panel_bl_orders = {}
    panel_registration_orders = {}
    for space_type in iter_supported_space_types():
        try:
            panels = discover_sidebar_panels(space_type)
            order = tuple(panels.keys())
            panel_orders[space_type] = order
            panel_order_indices[space_type] = {
                panel_id: index for index, panel_id in enumerate(order)
            }
            panel_bl_orders[space_type] = {
                panel_id: int(getattr(cls, "bl_order", 0) or 0)
                for panel_id, cls in panels.items()
            }
            panel_registration_orders[space_type] = panel_registration_order_map(
                space_type=space_type
            )
        except Exception:
            panel_orders[space_type] = ()
            panel_order_indices[space_type] = {}
            panel_bl_orders[space_type] = {}
            panel_registration_orders[space_type] = {}

    PRE_GO_WORKFLOW_STATE = {
        "captured": True,
        "compact_tabs": compact_tabs,
        "panel_orders": panel_orders,
        "panel_order_indices": panel_order_indices,
        "panel_bl_orders": panel_bl_orders,
        "panel_registration_orders": panel_registration_orders,
    }
    return PRE_GO_WORKFLOW_STATE


def extend_pre_go_workflow_order_snapshot(space_type=None):
    """Add panels registered after GoWorkflow without replacing old positions."""
    state = capture_pre_go_workflow_state()
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    panel_orders = state.setdefault("panel_orders", {})
    panel_order_indices = state.setdefault("panel_order_indices", {})
    panel_bl_orders = state.setdefault("panel_bl_orders", {})
    panel_registration_orders = state.setdefault("panel_registration_orders", {})
    for target_space in target_spaces:
        try:
            current_panels = discover_sidebar_panels(target_space)
            current_order = tuple(current_panels.keys())
        except Exception:
            continue
        baseline = list(panel_orders.get(target_space, ()))
        known = set(baseline)
        for panel_id in current_order:
            if panel_id not in known:
                baseline.append(panel_id)
                known.add(panel_id)
        panel_orders[target_space] = tuple(baseline)
        panel_order_indices[target_space] = {
            panel_id: index for index, panel_id in enumerate(baseline)
        }
        panel_bl_orders.setdefault(target_space, {}).update(
            {
                panel_id: int(getattr(cls, "bl_order", 0) or 0)
                for panel_id, cls in current_panels.items()
                if panel_id not in panel_bl_orders.get(target_space, {})
            }
        )
        panel_registration_orders[target_space] = panel_registration_order_map(
            space_type=target_space
        )
    return state


def pre_go_workflow_compact_tabs_state():
    state = PRE_GO_WORKFLOW_STATE or {}
    return state.get("compact_tabs")


def workflow_runtime_initialized(state):
    settings = getattr(state, "settings", None) if state is not None else None
    return bool(settings is not None and getattr(settings, "runtime_initialized", False))


def clear_pre_go_workflow_state():
    global PRE_GO_WORKFLOW_STATE
    PRE_GO_WORKFLOW_STATE = None


def module_runtime_cleanup_cache_key(scene, workflow, module):
    """用稳定的字符串键替代 id()，因为 Blender CollectionProperty 迭代
    每次返回新的 Python 包装器，id() 不跨帧稳定，导致缓存全部 miss。
    """
    scene_id = getattr(scene, "as_pointer", lambda: 0)() if scene is not None else 0
    wf_id = getattr(workflow, "name", "") if workflow is not None else ""
    mod_id = getattr(module, "name", "") if module is not None else ""
    return (str(scene_id), str(wf_id), str(mod_id))


def module_runtime_namespace_cache_key(scene, workflow, module, name):
    return module_runtime_cleanup_cache_key(scene, workflow, module) + (str(name or ""),)


def cache_module_runtime_cleanup(scene, workflow, module, cleanup_fn, module_state=None):
    if not callable(cleanup_fn):
        return False
    MODULE_RUNTIME_CLEANUP_CACHE[module_runtime_cleanup_cache_key(scene, workflow, module)] = {
        "cleanup_runtime": cleanup_fn,
        "module_state": module_state,
    }
    return True


def pop_module_runtime_cleanup(scene, workflow, module):
    return MODULE_RUNTIME_CLEANUP_CACHE.pop(module_runtime_cleanup_cache_key(scene, workflow, module), None)


def iter_panel_subclasses(base_cls):
    yield from shared_iter_panel_subclasses(base_cls)


def iter_registered_panel_classes():
    yield from shared_iter_registered_panel_classes()


def panel_registration_order_map(space_type=None):
    return shared_panel_registration_order_map(space_type=space_type)


def is_registered_panel_class(cls):
    return shared_is_registered_panel_class(cls)


def is_builtin_default_source_module(source_module):
    source_module = (source_module or "").strip()
    return bool(source_module) and source_module.startswith(BUILTIN_DEFAULT_PANEL_PREFIXES)


def is_builtin_default_panel_class(cls):
    return is_builtin_default_source_module(getattr(cls, "__module__", ""))


def builtin_default_panel_category(panel_id):
    return BUILTIN_PANEL_CATEGORY_MAP.get(panel_id, "")


def is_builtin_default_panel_name(panel_id):
    return panel_id in BUILTIN_PANEL_CATEGORY_MAP


def is_builtin_foundation_panel_id(panel_id, space_type=None):
    category = builtin_default_panel_category(panel_id)
    return category in {"Tool", "View"}


def discover_sidebar_panels(space_type="VIEW_3D"):
    panels, registry = shared_discover_sidebar_panels(
        space_type=space_type,
        is_builtin_default_panel_class_fn=is_builtin_default_panel_class,
        is_builtin_default_panel_name_fn=is_builtin_default_panel_name,
        clean_panel_title_fn=clean_panel_title,
    )
    PANEL_CLASS_REGISTRY_BY_SPACE[space_type] = registry
    return panels


def panel_display_category(panel_id, cls, space_type=None):
    return shared_panel_display_category(
        panel_id,
        cls,
        builtin_default_panel_category_fn=builtin_default_panel_category,
        get_panel_cache_fn=get_panel_cache,
        space_type=space_type,
    )


def clean_panel_title(title, fallback):
    text = (title or "").strip()
    return normalize_text_value(text, fallback)


def is_placeholder_ui_text(text):
    return shared_is_placeholder_ui_text(text, PLACEHOLDER_UI_TEXTS)


def normalize_text_value(text, fallback=""):
    return shared_normalize_text_value(
        text,
        fallback,
        placeholder_texts=PLACEHOLDER_UI_TEXTS,
        suspicious_tokens=SUSPICIOUS_TEXT_TOKENS,
    )


def is_suspicious_ui_text(text):
    return shared_is_suspicious_ui_text(text, PLACEHOLDER_UI_TEXTS, SUSPICIOUS_TEXT_TOKENS)


def normalize_workflow_name(name, fallback):
    return shared_normalize_workflow_name(
        name,
        fallback,
        placeholder_texts=PLACEHOLDER_UI_TEXTS,
        suspicious_tokens=SUSPICIOUS_TEXT_TOKENS,
    )


def unique_workflow_name_from_existing(base_name, existing_names, fallback="新工作流"):
    return shared_unique_name_from_existing(
        base_name,
        existing_names,
        fallback=fallback,
        normalize_name_fn=lambda value, default: normalize_workflow_name(value, default),
    )


def unique_workflow_name(state, base_name, fallback="新工作流", exclude_index=None):
    existing = []
    for index, workflow in enumerate(getattr(state, "workflows", [])):
        if exclude_index is not None and index == exclude_index:
            continue
        existing.append(getattr(workflow, "name", ""))
    return unique_workflow_name_from_existing(base_name, existing, fallback=fallback)


def unique_workflow_name_across_spaces(scene, base_name, fallback="新工作流"):
    existing = []
    for space_type in SUPPORTED_SPACE_TYPES:
        state = get_state(scene=scene, space_type=space_type)
        existing.extend(getattr(workflow, "name", "") for workflow in getattr(state, "workflows", []))
    return unique_workflow_name_from_existing(base_name, existing, fallback=fallback)


def normalize_workflow_description(description, fallback):
    return shared_normalize_workflow_description(
        description,
        fallback,
        placeholder_texts=PLACEHOLDER_UI_TEXTS,
        suspicious_tokens=SUSPICIOUS_TEXT_TOKENS,
    )


def normalize_workflow_texts(state):
    if state is None:
        return False

    changed = False
    used_names = []
    for index, workflow in enumerate(state.workflows):
        if workflow.is_default:
            new_name = unique_workflow_name_from_existing(
                normalize_workflow_name(workflow.name, DEFAULT_WORKFLOW_NAME),
                used_names,
                fallback=DEFAULT_WORKFLOW_NAME,
            )
            new_description = normalize_workflow_description(workflow.description, DEFAULT_WORKFLOW_DESCRIPTION)
            if workflow.name != new_name:
                workflow.name = new_name
                changed = True
            if workflow.description != new_description:
                workflow.description = new_description
                changed = True
            used_names.append(new_name)
            continue

        fallback_name = f"工作流{index + 1}"
        new_name = unique_workflow_name_from_existing(
            normalize_workflow_name(workflow.name, fallback_name),
            used_names,
            fallback=fallback_name,
        )
        new_description = normalize_workflow_description(workflow.description, "自定义工作流，可在面板库中配置显示的面板")
        if workflow.name != new_name:
            workflow.name = new_name
            changed = True
        if workflow.description != new_description:
            workflow.description = new_description
            changed = True
        used_names.append(new_name)
    return changed


def panel_plugin_key_from_module(source_module):
    module_name = (source_module or "").strip()
    if not module_name:
        return ""
    parts = [part for part in module_name.split(".") if part]
    if not parts:
        return ""
    if parts[0] == "bl_ext" and len(parts) >= 3:
        return parts[2]
    if parts[0] in {"user_default", "extensions", "blender_org"} and len(parts) >= 2:
        return parts[1]
    return parts[0]


def panel_plugin_key(panel_id):
    cls = None
    for registry in PANEL_CLASS_REGISTRY_BY_SPACE.values():
        cls = registry.get(panel_id)
        if cls is not None:
            break
    if cls is None:
        for cache in PANEL_CLASS_CACHE_BY_SPACE.values():
            cls = cache.get(panel_id)
            if cls is not None:
                break
    if cls is None:
        return ""
    return panel_plugin_key_from_module(getattr(cls, "__module__", ""))


def addon_version_from_module_name(module_name):
    module_name = str(module_name or "").strip()
    if not module_name:
        return ""
    candidates = [module_name]
    parts = [part for part in module_name.split(".") if part]
    if parts:
        candidates.append(parts[0])
    plugin_key = panel_plugin_key_from_module(module_name)
    if plugin_key:
        candidates.append(plugin_key)
    try:
        addon_keys = list(bpy.context.preferences.addons.keys())
    except Exception:
        addon_keys = []
    candidates.extend(addon_keys)
    seen = set()
    for candidate in candidates:
        candidate = str(candidate or "").strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        addon = None
        try:
            addon = bpy.context.preferences.addons.get(candidate)
        except Exception:
            addon = None
        module = getattr(addon, "module", None) if addon is not None else None
        if module is None:
            module = sys.modules.get(candidate)
        if module is None and plugin_key and candidate in addon_keys and (
            candidate == plugin_key or candidate.endswith("." + plugin_key)
        ):
            module = getattr(bpy.context.preferences.addons.get(candidate), "module", None)
        bl_info = getattr(module, "bl_info", None)
        if isinstance(bl_info, dict):
            version_text = version_tuple_to_text(bl_info.get("version", ()))
            if version_text:
                return version_text
    return ""


def runtime_panel_addon_version(panel_id, space_type=None):
    cls = get_panel_registry(space_type).get(panel_id) or get_panel_cache(space_type).get(panel_id)
    if cls is None:
        return ""
    return addon_version_from_module_name(getattr(cls, "__module__", ""))


def infer_plugin_key_from_panel_id(panel_id):
    value = (panel_id or "").strip()
    if not value:
        return ""
    for marker in ("_PT_", "_MT_", "_UL_", "_HT_"):
        if marker in value:
            return value.split(marker, 1)[0]
    if "_" in value:
        return value.split("_", 1)[0]
    return value


def panel_plugin_label_from_key(plugin_key):
    if not plugin_key:
        return "未分类插件"
    tail = plugin_key.split(".")[-1]
    return tail.replace("_", " ").strip().title() or plugin_key


def addon_name_from_module_name(module_name):
    module_name = str(module_name or "").strip()
    if not module_name:
        return ""
    plugin_key = panel_plugin_key_from_module(module_name)
    candidates = [module_name]
    if plugin_key:
        candidates.append(plugin_key)
    try:
        addon_keys = list(bpy.context.preferences.addons.keys())
    except Exception:
        addon_keys = []
    candidates.extend(
        key
        for key in addon_keys
        if key == plugin_key or (plugin_key and key.endswith("." + plugin_key))
    )

    seen = set()
    for candidate in candidates:
        candidate = str(candidate or "").strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        module = sys.modules.get(candidate)
        if module is None:
            try:
                module = getattr(bpy.context.preferences.addons.get(candidate), "module", None)
            except Exception:
                module = None
        bl_info = getattr(module, "bl_info", None)
        if not isinstance(bl_info, dict):
            continue
        name = normalize_panel_family_text(blender_iface_text(bl_info.get("name", "")))
        if name and is_usable_family_label(name):
            return name
    return ""


def blender_iface_text(text):
    value = str(text or "")
    try:
        return str(bpy.app.translations.pgettext_iface(value) or value)
    except Exception:
        return value


def panel_group_compact_icon_text(category):
    """Match Blender's compact panel-tab text selection."""
    text = blender_iface_text(category).strip()
    if not text:
        return "??"

    chars = [char for char in text if not char.isspace()]
    cjk_chars = [
        char
        for char in chars
        if ("\u3400" <= char <= "\u4dbf")
        or ("\u4e00" <= char <= "\u9fff")
        or ("\uf900" <= char <= "\ufaff")
    ]
    if cjk_chars:
        # Blender's compact tabs reserve one cell for CJK labels.
        return cjk_chars[0]

    words = [word for word in re.findall(r"[A-Za-z]+", text) if word]
    if words and len(words[0]) >= 2:
        return words[0][:2]
    if len(words) >= 2:
        return words[0][0] + words[1][0]

    letters = [char for char in chars if char.isalpha()]
    if len(letters) == 1:
        return letters[0]
    if len(letters) >= 2:
        return "".join(letters[:2])
    return "".join(chars[:2])


def panel_icon_identifiers():
    try:
        prop = bpy.types.Panel.bl_rna.properties.get("bl_icon")
        if prop is not None:
            return {item.identifier for item in prop.enum_items}
    except Exception:
        pass
    return {
        "NONE",
        "WORKSPACE",
        "PREFERENCES",
        "TOOL_SETTINGS",
        "VIEW3D",
        "OBJECT_DATA",
        "MESH_DATA",
        "SHAPEKEY_DATA",
        "ARMATURE_DATA",
        "MODIFIER",
        "CONSTRAINT",
        "IMAGE_DATA",
        "OUTLINER",
        "PLUGIN",
        "MENU_PANEL",
    }


def workspace_tool_icon_value(path):
    global PANEL_CUSTOM_ICON_PREVIEWS
    path = os.path.abspath(os.path.expanduser(str(path or "").strip()))
    if not path:
        return 0
    cached = PANEL_CUSTOM_ICON_CACHE.get(path)
    if cached is not None:
        return int(cached or 0)
    if not os.path.isfile(path):
        return 0
    try:
        if PANEL_CUSTOM_ICON_PREVIEWS is None:
            PANEL_CUSTOM_ICON_PREVIEWS = bpy.utils.previews.new()
        preview = PANEL_CUSTOM_ICON_PREVIEWS.load(
            f"go_workflow_{len(PANEL_CUSTOM_ICON_CACHE)}",
            path,
            "IMAGE",
            force_reload=False,
        )
        icon_value = int(getattr(preview, "icon_id", 0) or 0)
    except Exception:
        icon_value = 0
    PANEL_CUSTOM_ICON_CACHE[path] = icon_value
    return icon_value


def workspace_tool_classes():
    global WORKSPACE_TOOL_CLASSES_CACHE
    if WORKSPACE_TOOL_CLASSES_CACHE is not None:
        return WORKSPACE_TOOL_CLASSES_CACHE
    base = getattr(bpy.types, "WorkSpaceTool", None)
    if base is None:
        WORKSPACE_TOOL_CLASSES_CACHE = ()
        return WORKSPACE_TOOL_CLASSES_CACHE
    try:
        WORKSPACE_TOOL_CLASSES_CACHE = tuple(iter_panel_subclasses(base))
    except Exception:
        WORKSPACE_TOOL_CLASSES_CACHE = ()
    return WORKSPACE_TOOL_CLASSES_CACHE


def workspace_tool_icon_for_group(state, group):
    if state is None or not isinstance(group, dict):
        return 0
    group_key = str(group.get("key", "") or "")
    family_keys = set()
    family_titles = set()
    record_ids = list(group.get("record_ids", ()) or ())
    if not record_ids:
        record_ids = list(group.get("panel_ids", ()) or ())
        record_ids.extend(group.get("drawer_ids", ()) or ())
    record_lookup = get_panel_registry_lookup(state).get("record_by_id", {})
    for panel_id in unique_panel_ids(record_ids):
        record = record_lookup.get(panel_id)
        if record is None:
            continue
        if not panel_id:
            continue
        if group_key and workflow_group_key_for_panel(state, panel_id) != group_key:
            continue
        family_keys.add(panel_plugin_key_for_record(record))
        family_titles.add(normalize_panel_family_text(panel_plugin_title(state, panel_id)).casefold())
        family_titles.add(normalize_panel_family_text(panel_group_original_title(state, panel_id)).casefold())

    for cls in workspace_tool_classes():
        icon_path = getattr(cls, "bl_icon", "")
        if not isinstance(icon_path, str) or not icon_path.strip():
            continue
        tool_key = panel_plugin_key_from_module(getattr(cls, "__module__", ""))
        tool_label = normalize_panel_family_text(
            blender_iface_text(getattr(cls, "bl_label", ""))
        ).casefold()
        if tool_key not in family_keys and tool_label not in family_titles:
            continue
        icon_value = workspace_tool_icon_value(icon_path)
        if icon_value:
            return icon_value
    return 0


def panel_drawer_category_label(state, drawer_id, space_type=None):
    """Return the exact Panel.bl_category used by Blender's sidebar tab."""
    target_space = space_type or (
        getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    )
    root_id = panel_drawer_root_id(drawer_id, space_type=target_space) or drawer_id
    cls = get_panel_registry(target_space).get(root_id) or get_panel_cache(target_space).get(root_id)
    if cls is None:
        cls = resolve_panel_class_anywhere(root_id, space_type=target_space)
    if cls is not None:
        category = str(getattr(cls, "bl_category", "") or "").strip()
        if category:
            return blender_iface_text(category).strip()
        category = panel_display_category(root_id, cls, space_type=target_space)
        if category:
            return blender_iface_text(category).strip()
    record = find_registry_record(state, root_id) if state is not None else None
    return str(getattr(record, "category", "") or "").strip()


def _panel_group_icon_data_uncached(state, group):
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    panel_ids = []
    if isinstance(group, dict):
        panel_ids.extend(group.get("drawer_ids", ()) or ())
        panel_ids.append(group.get("panel_id", ""))

    seen = set()
    category_label = ""
    for panel_id in panel_ids:
        panel_id = str(panel_id or "").strip()
        if not panel_id or panel_id in seen:
            continue
        seen.add(panel_id)
        panel_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
        category_label = category_label or panel_drawer_category_label(
            state, panel_id, space_type=space_type
        )

    return {
        "icon_value": 0,
        "icon": "NONE",
        "text": panel_group_compact_icon_text(
            category_label
            or (group.get("title", "") if isinstance(group, dict) else "")
        ),
    }


def panel_group_icon_data(state, group):
    if state is None or not isinstance(group, dict):
        return _panel_group_icon_data_uncached(state, group)
    space_type = getattr(state, "space_type", "VIEW_3D") or "VIEW_3D"
    group_key = str(group.get("key", "") or "")
    cache_key = (
        group_key,
        str(group.get("title", "") or ""),
        str(group.get("original_title", "") or ""),
        tuple(group.get("drawer_ids", ()) or ()),
        tuple(group.get("panel_ids", ()) or ()),
        len(getattr(state, "panel_registry", [])),
    )
    cache = PANEL_GROUP_ICON_CACHE_BY_SPACE.setdefault(space_type, {})
    cached = cache.get(cache_key)
    if cached is not None:
        return dict(cached)
    result = _panel_group_icon_data_uncached(state, group)
    cache[cache_key] = dict(result)
    return result


def is_usable_family_label(text):
    normalized = normalize_panel_family_text(text)
    if not normalized:
        return False
    if is_suspicious_ui_text(normalized):
        return False
    question_count = normalized.count("?")
    if question_count >= 2:
        return False
    if "\ufffd" in normalized:
        return False
    return True


def panel_text_has_cjk(text):
    value = str(text or "")
    return any(
        ("\u3400" <= char <= "\u4dbf")
        or ("\u4e00" <= char <= "\u9fff")
        or ("\uf900" <= char <= "\ufaff")
        for char in value
    )


def normalize_panel_family_text(text):
    value = re.sub(r"[_\-.]+", " ", str(text or "")).strip()
    value = re.sub(r"\s+", " ", value)
    return value


def panel_family_title_from_candidates(candidates):
    normalized = [
        normalize_panel_family_text(candidate)
        for candidate in candidates
        if str(candidate or "").strip() and is_usable_family_label(candidate)
    ]
    for label in normalized:
        if not label:
            continue
        prefix = re.split(r"\s*[:：|/]\s*", label, maxsplit=1)[0].strip()
        return prefix or label
    return "未分类插件"


def panel_family_key(title):
    return slugify_filename(normalize_panel_family_text(title).casefold(), "panel_family")


def panel_family_aliases(family_title):
    words = [word for word in re.split(r"\s+", normalize_panel_family_text(family_title)) if word]
    aliases = []
    plain = " ".join(words)
    if plain:
        aliases.append(plain)
    compact = re.sub(r"[^0-9a-zA-Z]+", "", plain)
    if compact:
        aliases.append(compact)
    if len(words) >= 2:
        initials = "".join(word[0] for word in words if word)
        if initials:
            aliases.append(initials)
    return unique_panel_ids(alias for alias in aliases if alias)


def strip_family_prefix(text, family_title):
    value = normalize_panel_family_text(text)
    if not value:
        return ""
    for alias in panel_family_aliases(family_title):
        alias_pattern = r"\s*".join(re.escape(char) for char in alias if char.strip())
        patterns = [
            rf"^{re.escape(alias)}\s*[:：\-_/|]\s*(.+)$",
            rf"^{alias_pattern}\s*[:：\-_/|]\s*(.+)$",
            rf"^{re.escape(alias)}\s+(.+)$",
            rf"^{alias_pattern}\s+(.+)$",
        ]
        for pattern in patterns:
            match = re.match(pattern, value, flags=re.IGNORECASE)
            if match:
                return match.group(1).strip()
    return value


def panel_family_title(state, record_or_panel_id):
    record = record_or_panel_id
    if isinstance(record_or_panel_id, str):
        record = find_registry_record(state, record_or_panel_id) if state is not None else None
    panel_id = getattr(record, "panel_id", record_or_panel_id if isinstance(record_or_panel_id, str) else "")
    plugin_title = panel_plugin_title(state, panel_id)
    plugin_key_title = panel_plugin_label_from_key(panel_plugin_key_for_record(record) or infer_plugin_key_from_panel_id(panel_id))
    return panel_family_title_from_candidates([plugin_title, plugin_key_title, getattr(record, "category", ""), getattr(record, "title", ""), panel_id])


def panel_component_title(state, record_or_panel_id, root_id=None):
    record = record_or_panel_id
    if isinstance(record_or_panel_id, str):
        record = find_registry_record(state, record_or_panel_id) if state is not None else None
    panel_id = getattr(record, "panel_id", record_or_panel_id if isinstance(record_or_panel_id, str) else "")
    root_id = root_id or panel_tree_root_id(panel_id, space_type=getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D")
    root_record = find_registry_record(state, root_id) if state is not None else None
    family_title = panel_family_title(state, record or panel_id)
    candidates = [
        getattr(root_record, "title", ""),
        getattr(record, "title", ""),
        getattr(record, "category", ""),
        panel_plugin_title(state, panel_id),
    ]
    for candidate in candidates:
        stripped = strip_family_prefix(candidate, family_title)
        if not stripped:
            continue
        if stripped.casefold() != normalize_panel_family_text(family_title).casefold():
            return stripped
    return family_title or "未分类插件"


def panel_component_key(title):
    return slugify_filename(normalize_panel_family_text(title).casefold(), "panel_component")


def panel_group_index_signature(state, space_type):
    if state is None:
        return ()
    return (
        space_type,
        panel_registry_content_signature(state),
    )


def panel_registry_record_signature(record):
    return (
        getattr(record, "panel_id", ""),
        getattr(record, "title", ""),
        getattr(record, "category", ""),
        getattr(record, "tags", ""),
        getattr(record, "source_module", ""),
        getattr(record, "addon_version", ""),
        bool(getattr(record, "discovered", False)),
    )


def panel_registry_content_signature(state):
    if state is None:
        return ()
    return tuple(panel_registry_record_signature(record) for record in getattr(state, "panel_registry", []))


def get_panel_group_index(state):
    if state is None:
        return {
            "title_by_panel": {},
            "ids_by_panel": {},
            "key_by_panel": {},
            "members_by_key": {},
            "record_count_by_panel": {},
        }
    space_type = getattr(state, "space_type", "VIEW_3D")
    signature = panel_group_index_signature(state, space_type)
    cached = PANEL_GROUP_INDEX_CACHE_BY_SPACE.get(space_type)
    if cached is not None and cached.get("signature") == signature:
        return cached["index"]

    raw_components = {}
    for record in getattr(state, "panel_registry", []):
        if record.panel_id == "BWFLOW_PT_workflow":
            continue
        family_title = panel_family_title(state, record)
        family_key = panel_family_key(family_title)
        root_id = panel_tree_root_id(record.panel_id, space_type=space_type)
        component_title = panel_component_title(state, record, root_id=root_id)
        component_key = panel_component_key(component_title)
        raw_key = (family_key, component_key)
        component = raw_components.setdefault(
            raw_key,
            {
                "family_key": family_key,
                "family_title": family_title,
                "component_title": component_title,
                "root_ids": [],
                "records": [],
            },
        )
        component["root_ids"].append(root_id)
        component["records"].append(record)

    compact_groups = {}
    for component in raw_components.values():
        root_ids = unique_panel_ids(component["root_ids"])
        compact_title = component["family_title"] if len(root_ids) <= 1 else component["component_title"]
        compact_key = (component["family_key"], panel_component_key(compact_title))
        target = compact_groups.setdefault(
            compact_key,
            {
                "family_title": component["family_title"],
                "component_title": compact_title,
                "root_ids": [],
                "records": [],
            },
        )
        target["root_ids"].extend(root_ids)
        target["records"].extend(component["records"])

    index = {
        "title_by_panel": {},
        "ids_by_panel": {},
        "key_by_panel": {},
        "members_by_key": {},
        "record_count_by_panel": {},
    }
    for (family_key, component_key), group in compact_groups.items():
        group_key = f"component:{family_key}:{component_key}"
        root_ids = unique_panel_ids(group["root_ids"])
        record_count = len(unique_panel_ids(record.panel_id for record in group["records"]))
        index["members_by_key"][group_key] = root_ids
        for record in group["records"]:
            index["title_by_panel"][record.panel_id] = group["component_title"]
            index["ids_by_panel"][record.panel_id] = root_ids
            index["key_by_panel"][record.panel_id] = group_key
            index["record_count_by_panel"][record.panel_id] = record_count

    PANEL_GROUP_INDEX_CACHE_BY_SPACE[space_type] = {"signature": signature, "index": index}
    return index


def panel_registry_lookup_signature(state):
    if state is None:
        return ()
    return (
        getattr(state, "space_type", "VIEW_3D"),
        panel_registry_content_signature(state),
    )


def panel_library_groups_signature(state, workflow):
    if state is None:
        return ()
    return (
        panel_registry_lookup_signature(state),
        workflow_panel_membership_signature(workflow),
    )


def selected_panel_groups_signature(state, workflow):
    if state is None:
        return ()
    return (
        panel_registry_lookup_signature(state),
        workflow_panel_membership_signature(workflow),
        clamp_index(getattr(workflow, "active_panel_index", 0), len(getattr(workflow, "panels", []))) if workflow is not None else 0,
    )


def selected_panel_group_summary_signature(state, workflow):
    if state is None:
        return ()
    return (
        panel_registry_lookup_signature(state),
        workflow_panel_membership_signature(workflow),
        clamp_index(getattr(workflow, "active_panel_index", 0), len(getattr(workflow, "panels", []))) if workflow is not None else 0,
        "summary",
    )


def get_panel_registry_lookup(state):
    if state is None:
        return {
            "record_by_id": {},
            "records_by_drawer": {},
            "index_by_id": {},
        }

    space_type = getattr(state, "space_type", "VIEW_3D")
    signature = panel_registry_lookup_signature(state)
    cached = PANEL_REGISTRY_LOOKUP_CACHE_BY_SPACE.get(space_type)
    if cached is not None and cached.get("signature") == signature:
        return cached["lookup"]

    records = list(getattr(state, "panel_registry", []))
    record_by_id = {}
    index_by_id = {}
    records_by_drawer = {}
    records_by_source_module = {}
    records_by_plugin_key = {}

    for index, record in enumerate(records):
        panel_id = getattr(record, "panel_id", "")
        if not panel_id:
            continue
        record_by_id.setdefault(panel_id, record)
        index_by_id.setdefault(panel_id, index)
        drawer_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
        records_by_drawer.setdefault(drawer_id, []).append(record)
        source_module = normalized_panel_match_text(getattr(record, "source_module", ""))
        if source_module:
            records_by_source_module.setdefault(source_module, []).append(record)
        plugin_key = normalized_panel_match_text(panel_plugin_key_for_record(record) or infer_plugin_key_from_panel_id(panel_id))
        if plugin_key:
            records_by_plugin_key.setdefault(plugin_key, []).append(record)

    lookup = {
        "record_by_id": record_by_id,
        "records_by_drawer": records_by_drawer,
        "index_by_id": index_by_id,
        "records_by_source_module": records_by_source_module,
        "records_by_plugin_key": records_by_plugin_key,
    }
    PANEL_REGISTRY_LOOKUP_CACHE_BY_SPACE[space_type] = {"signature": signature, "lookup": lookup}
    return lookup


def compact_component_title(state, panel_id):
    title = get_panel_group_index(state)["title_by_panel"].get(panel_id)
    if title:
        return title
    return panel_family_title(state, panel_id)


def compact_component_workflow_ids(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return []
    ids = get_panel_group_index(state)["ids_by_panel"].get(panel_id)
    if ids:
        return list(ids)
    return panel_component_workflow_ids(state, panel_id)


def compact_component_panel_count(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return 0
    count = get_panel_group_index(state)["record_count_by_panel"].get(panel_id, 0)
    if count:
        return count
    ids = compact_component_workflow_ids(state, panel_id)
    return max(1, len(ids))


def drawer_count_for_entries(entries):
    return shared_drawer_count_for_entries(entries, unique_panel_ids)


def panel_count_label(count):
    return shared_panel_count_label(count)


def panel_plugin_title(state, panel_id):
    record = find_registry_record(state, panel_id) if state is not None else None
    source_module = getattr(record, "source_module", "") if record is not None else ""
    plugin_key = panel_plugin_key_from_module(source_module) or infer_plugin_key_from_panel_id(panel_id)
    return addon_name_from_module_name(source_module) or panel_plugin_label_from_key(plugin_key)


def panel_group_original_title(state, panel_id, fallback=""):
    original = panel_plugin_title(state, panel_id)
    return str(original or fallback or panel_id or "").strip()


def panel_group_display_title(state, records, fallback=""):
    return str(fallback or "").strip()


def panel_plugin_key_for_record(record):
    if record is None:
        return ""
    return panel_plugin_key_from_module(getattr(record, "source_module", "")) or infer_plugin_key_from_panel_id(getattr(record, "panel_id", ""))


def panel_parent_id(panel_id, space_type=None):
    cache = get_panel_cache(space_type)
    registry = get_panel_registry(space_type)
    cls = registry.get(panel_id) or cache.get(panel_id)
    if cls is None:
        return ""
    return getattr(cls, "bl_parent_id", "") or ""


def panel_child_depth(panel_id, space_type=None):
    depth = 0
    seen = set()
    current_id = panel_id
    cache = get_panel_cache(space_type)
    registry = get_panel_registry(space_type)
    while current_id and current_id not in seen:
        seen.add(current_id)
        cls = registry.get(current_id) or cache.get(current_id)
        parent_id = getattr(cls, "bl_parent_id", "") if cls else ""
        if not parent_id:
            break
        depth += 1
        current_id = parent_id
    return depth


def current_space_type(context=None):
    area = getattr(context, "area", None) if context is not None else None
    area_type = getattr(area, "type", "") if area is not None else ""
    if area_type in SUPPORTED_SPACE_TYPES:
        return area_type
    return "VIEW_3D"


def space_state_prop_name(space_type):
    return SPACE_STATE_PROP_NAMES.get(space_type, SPACE_STATE_PROP_NAMES["VIEW_3D"])


def get_panel_cache(space_type=None):
    return PANEL_CLASS_CACHE_BY_SPACE.get(space_type or "VIEW_3D", {})


def get_panel_registry(space_type=None):
    return PANEL_CLASS_REGISTRY_BY_SPACE.get(space_type or "VIEW_3D", {})


def runtime_hidden_panel_ids(space_type=None):
    if space_type is None:
        return set(UNREGISTERED_PANEL_IDS)
    signature = (
        tuple(sorted(UNREGISTERED_PANEL_IDS)),
        len(get_panel_cache(space_type)),
        len(get_panel_registry(space_type)),
    )
    cached = RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.get(space_type)
    if cached is not None and cached.get("signature") == signature:
        return set(cached.get("ids", ()))
    cache = get_panel_cache(space_type)
    registry = get_panel_registry(space_type)
    hidden_ids = set()
    for panel_id in UNREGISTERED_PANEL_IDS:
        cls = cache.get(panel_id) or registry.get(panel_id)
        if cls is None:
            cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
        if cls is not None and getattr(cls, "bl_space_type", None) == space_type:
            hidden_ids.add(panel_id)
    RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE[space_type] = {
        "signature": signature,
        "ids": tuple(hidden_ids),
    }
    return hidden_ids


def iter_registries(space_type=None):
    if space_type:
        yield space_type, get_panel_registry(space_type)
        return
    for item_space_type in iter_supported_space_types():
        yield item_space_type, get_panel_registry(item_space_type)


def resolve_panel_class(panel_id, space_type=None):
    for _space_type, registry in iter_registries(space_type):
        cls = registry.get(panel_id)
        if cls is not None:
            return cls
    return None


def resolve_panel_class_anywhere(panel_id, space_type=None):
    cls = resolve_panel_class(panel_id, space_type=space_type)
    if cls is not None:
        return cls

    for cls in iter_panel_subclasses(bpy.types.Panel):
        candidate_id = getattr(cls, "bl_idname", "") or getattr(cls, "__name__", "")
        if candidate_id != panel_id:
            continue
        if space_type and getattr(cls, "bl_space_type", None) != space_type:
            continue
        if getattr(cls, "bl_region_type", None) != "UI":
            continue
        return cls
    return None


def panel_category_key(panel_id, space_type=None):
    cls = get_panel_registry(space_type).get(panel_id) or get_panel_cache(space_type).get(panel_id)
    category = panel_display_category(panel_id, cls, space_type=space_type) if cls is not None else ""
    return category or f"__panel__:{panel_id}"


def safe_context_scene():
    try:
        return bpy.context.scene
    except Exception:
        return None


def iter_available_scenes():
    try:
        return list(bpy.data.scenes)
    except Exception:
        return []


def tag_redraw_all(space_type=None):
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    target_spaces = set(iter_supported_space_types()) if space_type is None else {space_type}
    for window in wm.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type in target_spaces:
                area.tag_redraw()


def tag_redraw_context_area(context=None):
    area = getattr(context or bpy.context, "area", None)
    if area is None:
        return False
    try:
        area.tag_redraw()
        return True
    except Exception:
        return False


def clamp_index(index, size):
    if size <= 0:
        return 0
    return max(0, min(index, size - 1))


def get_state(context=None, scene=None, space_type=None):
    target_scene = scene
    if target_scene is None and context is not None:
        try:
            target_scene = context.scene
        except Exception:
            target_scene = None
    if target_scene is None:
        target_scene = safe_context_scene()
    if target_scene is None:
        return None

    target_space = space_type or current_space_type(context=context)
    prop_name = space_state_prop_name(target_space)
    if not hasattr(target_scene, prop_name):
        return None
    return getattr(target_scene, prop_name)


def iter_supported_space_types():
    return tuple(SUPPORTED_SPACE_TYPES)


def iter_workflow_lookup_space_types(preferred_space_type=""):
    preferred_space_type = str(preferred_space_type or "").strip()
    ordered = []
    if preferred_space_type in SUPPORTED_SPACE_TYPES:
        ordered.append(preferred_space_type)
    for space_type in iter_supported_space_types():
        if space_type not in ordered:
            ordered.append(space_type)
    return tuple(ordered)


def get_active_workflow(state):
    if state is None or not state.workflows:
        return None
    return state.workflows[clamp_index(state.active_workflow_index, len(state.workflows))]


def resolve_workflow_module(scene, workflow_name="", module_name="", space_type=None):
    workflow_name = str(workflow_name or "").strip()
    module_name = str(module_name or "").strip()
    if scene is None:
        return None, None
    for lookup_space_type in iter_workflow_lookup_space_types(space_type):
        state = get_state(scene=scene, space_type=lookup_space_type)
        if state is None:
            continue
        for workflow in state.workflows:
            if workflow_name and workflow.name != workflow_name:
                continue
            if not module_name:
                return workflow, None
            for module in workflow.modules:
                if module.name == module_name:
                    return workflow, module
    return None, None


def find_registry_record(state, panel_id):
    if state is None or not panel_id:
        return None
    return get_panel_registry_lookup(state)["record_by_id"].get(panel_id)


def is_builtin_default_panel_id(panel_id, space_type=None):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return False
    cls = get_panel_registry(space_type).get(panel_id) or get_panel_cache(space_type).get(panel_id)
    return cls is not None and is_builtin_default_panel_class(cls)


def is_builtin_default_panel_record(record):
    if record is None or record.panel_id == "BWFLOW_PT_workflow":
        return False
    if is_builtin_default_source_module(getattr(record, "source_module", "")):
        return True
    return is_builtin_default_panel_id(getattr(record, "panel_id", ""))


def unique_panel_ids(panel_ids):
    ordered = []
    seen = set()
    for panel_id in panel_ids:
        if panel_id and panel_id not in seen:
            ordered.append(panel_id)
            seen.add(panel_id)
    return ordered


def workflow_module_signature(module):
    if module is None:
        return ()
    return (
        getattr(module, "name", ""),
        bool(getattr(module, "enabled", False)),
        bool(getattr(module, "use_custom_panel", False)),
        bool(getattr(module, "runtime_panel_expanded", True)),
        bool(getattr(module, "runtime_description_expanded", False)),
        getattr(module, "panel_title", ""),
        getattr(module, "panel_description", ""),
        getattr(module, "script_path", ""),
        getattr(module, "description", ""),
        getattr(module, "script_source", ""),
        getattr(module, "config_payload", ""),
        getattr(module, "ai_doc", ""),
    )


def workflow_signature(workflow):
    if workflow is None:
        return ()
    return (
        getattr(workflow, "name", ""),
        bool(getattr(workflow, "is_default", False)),
        getattr(workflow, "description", ""),
        getattr(workflow, "tag_filter", ""),
        bool(getattr(workflow, "missing_warning_dismissed", False)),
        tuple(unique_panel_ids(item.panel_id for item in getattr(workflow, "panels", []))),
        tuple(workflow_module_signature(module) for module in getattr(workflow, "modules", [])),
    )


def workflow_panel_membership_signature(workflow):
    if workflow is None:
        return ()
    panels = getattr(workflow, "panels", [])
    return (
        bool(getattr(workflow, "is_default", False)),
        tuple(getattr(item, "panel_id", "") for item in panels),
    )


def dedupe_panel_registry(state):
    if state is None:
        return False

    records = []
    seen = {}
    changed = False
    for item in state.panel_registry:
        panel_id = (item.panel_id or "").strip()
        if not panel_id:
            changed = True
            continue
        payload = {
            "panel_id": panel_id,
            "title": item.title,
            "category": item.category,
            "tags": item.tags,
            "source_module": item.source_module,
            "addon_version": getattr(item, "addon_version", ""),
            "discovered": bool(item.discovered),
        }
        if panel_id not in seen:
            seen[panel_id] = payload
            records.append(payload)
            continue
        changed = True
        existing = seen[panel_id]
        if payload["discovered"]:
            existing["discovered"] = True
        for key in ("title", "category", "tags", "source_module", "addon_version"):
            if not existing.get(key) and payload.get(key):
                existing[key] = payload[key]

    if not changed:
        return False

    selected_panel_id = ""
    if state.panel_registry and 0 <= state.panel_registry_index < len(state.panel_registry):
        selected_panel_id = state.panel_registry[state.panel_registry_index].panel_id

    clear_collection(state.panel_registry)
    for payload in records:
        item = state.panel_registry.add()
        safe_set_rna_text(item, "panel_id", payload["panel_id"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        safe_set_rna_text(item, "title", payload["title"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        safe_set_rna_text(item, "category", payload["category"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        safe_set_rna_text(item, "tags", payload["tags"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        safe_set_rna_text(item, "source_module", payload["source_module"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        safe_set_rna_text(item, "addon_version", payload.get("addon_version", ""), max_chars=32)
        item.discovered = payload["discovered"]

    state.panel_registry_index = 0
    if selected_panel_id:
        for index, item in enumerate(state.panel_registry):
            if item.panel_id == selected_panel_id:
                state.panel_registry_index = index
                break
    return True


def dedupe_workflow_panels(workflow):
    if workflow is None:
        return False
    before = [item.panel_id for item in workflow.panels]
    after = unique_panel_ids(before)
    if before == after:
        return False
    replace_workflow_panels(workflow, after)
    return True


def dedupe_workflows(state):
    if state is None:
        return False

    changed = False
    for workflow in state.workflows:
        if dedupe_workflow_panels(workflow):
            changed = True

    signatures = set()
    keep_indexes = []
    for index, workflow in enumerate(state.workflows):
        signature = workflow_signature(workflow)
        if signature in signatures:
            changed = True
            continue
        signatures.add(signature)
        keep_indexes.append(index)

    if not changed:
        return False

    active_signature = ()
    if state.workflows and 0 <= state.active_workflow_index < len(state.workflows):
        active_signature = workflow_signature(state.workflows[state.active_workflow_index])

    snapshot = []
    for index in keep_indexes:
        workflow = state.workflows[index]
        snapshot.append(
            {
                "name": workflow.name,
                "is_default": workflow.is_default,
                "description": workflow.description,
                "tag_filter": workflow.tag_filter,
                "missing_warning_dismissed": bool(getattr(workflow, "missing_warning_dismissed", False)),
                "panels": [item.panel_id for item in workflow.panels],
                "modules": [
                    {
                        "name": module.name,
                        "enabled": module.enabled,
                        "use_custom_panel": module.use_custom_panel,
                        "runtime_panel_expanded": getattr(module, "runtime_panel_expanded", True),
                        "runtime_description_expanded": getattr(module, "runtime_description_expanded", False),
                        "panel_title": module.panel_title,
                        "panel_description": module.panel_description,
                        "script_path": module.script_path,
                        "description": module.description,
                        "text_block_name": module.text_block_name,
                        "script_source": module.script_source,
                        "config_payload": getattr(module, "config_payload", ""),
                        "ai_doc": module.ai_doc,
                    }
                    for module in workflow.modules
                ],
            }
        )

    clear_collection(state.workflows)
    for workflow_data in snapshot:
        workflow = state.workflows.add()
        safe_set_rna_text(
            workflow,
            "name",
            workflow_data["name"],
            fallback="Imported Workflow",
            max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
        )
        workflow.is_default = workflow_data["is_default"]
        safe_set_rna_text(workflow, "description", workflow_data["description"], max_chars=MAX_RNA_SHORT_TEXT_CHARS)
        safe_set_rna_text(workflow, "tag_filter", workflow_data["tag_filter"], max_chars=MAX_RNA_SHORT_TEXT_CHARS)
        workflow.missing_warning_dismissed = bool(workflow_data.get("missing_warning_dismissed", False))
        for panel_id in workflow_data["panels"]:
            item = workflow.panels.add()
            safe_set_rna_text(item, "panel_id", panel_id, max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        for module_data in workflow_data["modules"]:
            module = workflow.modules.add()
            safe_set_rna_text(module, "name", module_data["name"], fallback="Imported Module", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            module.enabled = module_data["enabled"]
            module.use_custom_panel = module_data["use_custom_panel"]
            module.runtime_panel_expanded = module_data.get("runtime_panel_expanded", not module_prefers_collapsed_runtime_panel(module_data))
            module.runtime_description_expanded = module_data.get("runtime_description_expanded", False)
            safe_set_rna_text(module, "panel_title", module_data["panel_title"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            safe_set_rna_text(module, "panel_description", module_data["panel_description"], max_chars=MAX_RNA_SHORT_TEXT_CHARS)
            safe_set_rna_text(module, "script_path", module_data["script_path"], max_chars=MAX_RNA_SHORT_TEXT_CHARS)
            safe_set_rna_text(module, "description", module_data["description"], max_chars=MAX_RNA_SHORT_TEXT_CHARS)
            safe_set_rna_text(module, "text_block_name", module_data["text_block_name"], max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            safe_set_rna_text(module, "script_source", module_data["script_source"], max_chars=MAX_RNA_SCRIPT_CHARS)
            safe_set_rna_text(module, "config_payload", module_data.get("config_payload", ""), max_chars=MAX_RNA_TEXT_CHARS)
            safe_set_rna_text(module, "ai_doc", module_data["ai_doc"], max_chars=MAX_RNA_TEXT_CHARS)

    state.active_workflow_index = 0
    if active_signature:
        for index, workflow in enumerate(state.workflows):
            if workflow_signature(workflow) == active_signature:
                state.active_workflow_index = index
                break
    return True


def normalize_state_data(state):
    if state is None:
        return False
    changed = False
    before_registry_ids = [item.panel_id for item in getattr(state, "panel_registry", [])]
    before_workflow_panels = [[item.panel_id for item in workflow.panels] for workflow in getattr(state, "workflows", [])]
    purge_builtin_default_panels(state)
    after_registry_ids = [item.panel_id for item in getattr(state, "panel_registry", [])]
    after_workflow_panels = [[item.panel_id for item in workflow.panels] for workflow in getattr(state, "workflows", [])]
    if before_registry_ids != after_registry_ids or before_workflow_panels != after_workflow_panels:
        changed = True
    if dedupe_panel_registry(state):
        changed = True
    if dedupe_workflows(state):
        changed = True
    if normalize_workflow_texts(state):
        changed = True
    ensure_one_default_workflow(state)
    ensure_go_workflow_panel_entry(state)
    return changed


def referenced_panel_ids_in_state(state):
    panel_ids = set()
    if state is None:
        return panel_ids

    for workflow in state.workflows:
        for item in workflow.panels:
            panel_id = (item.panel_id or "").strip()
            if not panel_id or panel_id == "BWFLOW_PT_workflow":
                continue
            panel_ids.add(panel_id)
    return panel_ids


def validate_panel_registry_against_runtime(state, space_type=None, prune_missing_unreferenced=True):
    if state is None:
        return {
            "changed": False,
            "removed_empty": 0,
            "removed_duplicates": 0,
            "removed_stale": 0,
            "added_runtime": 0,
        }

    target_space = space_type or getattr(state, "space_type", "VIEW_3D") or "VIEW_3D"
    registry = get_panel_registry(target_space)
    cache = get_panel_cache(target_space)
    runtime_ids = set(registry.keys()) | set(cache.keys())
    referenced_ids = referenced_panel_ids_in_state(state)

    changed = False
    removed_empty = 0
    removed_duplicates = 0
    removed_stale = 0
    added_runtime = 0

    selected_panel_id = ""
    if state.panel_registry and 0 <= state.panel_registry_index < len(state.panel_registry):
        selected_panel_id = state.panel_registry[state.panel_registry_index].panel_id

    records = []
    seen = {}
    for item in state.panel_registry:
        panel_id = (item.panel_id or "").strip()
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            removed_empty += 1
            changed = True
            continue
        runtime_cls = registry.get(panel_id) or cache.get(panel_id)
        if runtime_cls is None and prune_missing_unreferenced and panel_id not in referenced_ids:
            removed_stale += 1
            changed = True
            continue

        payload = {
            "panel_id": panel_id,
            "title": clean_panel_title(getattr(runtime_cls, "bl_label", "") if runtime_cls is not None else item.title, panel_id),
            "category": panel_display_category(panel_id, runtime_cls, space_type=target_space) if runtime_cls is not None else item.category,
            "tags": item.tags,
            "source_module": getattr(runtime_cls, "__module__", "") if runtime_cls is not None else item.source_module,
            "addon_version": max_version_text(
                getattr(item, "addon_version", ""),
                addon_version_from_module_name(getattr(runtime_cls, "__module__", "")) if runtime_cls is not None else "",
            ),
            "discovered": runtime_cls is not None,
        }

        existing = seen.get(panel_id)
        if existing is None:
            seen[panel_id] = payload
            records.append(payload)
            continue

        removed_duplicates += 1
        changed = True
        if payload["discovered"]:
            existing["discovered"] = True
        for key in ("title", "category", "tags", "source_module", "addon_version"):
            if not existing.get(key) and payload.get(key):
                existing[key] = payload[key]

    for panel_id in sorted(runtime_ids):
        if panel_id in seen:
            continue
        runtime_cls = registry.get(panel_id) or cache.get(panel_id)
        if runtime_cls is None:
            continue
        records.append(
            {
                "panel_id": panel_id,
                "title": clean_panel_title(getattr(runtime_cls, "bl_label", panel_id), panel_id),
                "category": panel_display_category(panel_id, runtime_cls, space_type=target_space),
                "tags": "",
                "source_module": getattr(runtime_cls, "__module__", ""),
                "addon_version": addon_version_from_module_name(getattr(runtime_cls, "__module__", "")),
                "discovered": True,
            }
        )
        added_runtime += 1
        changed = True

    if not changed:
        return {
            "changed": False,
            "removed_empty": 0,
            "removed_duplicates": 0,
            "removed_stale": 0,
            "added_runtime": 0,
        }

    clear_collection(state.panel_registry)
    for payload in records:
        item = state.panel_registry.add()
        item.panel_id = payload["panel_id"]
        item.title = payload["title"]
        item.category = payload["category"]
        item.tags = payload["tags"]
        item.source_module = payload["source_module"]
        item.addon_version = payload.get("addon_version", "")
        item.discovered = payload["discovered"]

    state.panel_registry_index = 0
    if selected_panel_id:
        for index, item in enumerate(state.panel_registry):
            if item.panel_id == selected_panel_id:
                state.panel_registry_index = index
                break

    return {
        "changed": True,
        "removed_empty": removed_empty,
        "removed_duplicates": removed_duplicates,
        "removed_stale": removed_stale,
        "added_runtime": added_runtime,
    }


def coerce_text_value(value, fallback="", max_chars=None):
    if value is None:
        return fallback
    if isinstance(value, str):
        text = value
    elif isinstance(value, (int, float, bool)):
        text = str(value)
    else:
        return fallback
    text = text.replace("\x00", "")
    text = "".join(ch for ch in text if ch in "\t\r\n" or ord(ch) >= 32)
    if max_chars is not None and max_chars >= 0 and len(text) > max_chars:
        return text[:max_chars]
    return text


def coerce_rna_restore_text(value, fallback="", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS):
    text = coerce_text_value(value, fallback=fallback, max_chars=max_chars)
    if not text:
        return text
    text = "".join(ch for ch in text if ord(ch) <= 0xFFFF and not 0xD800 <= ord(ch) <= 0xDFFF)
    if max_chars is not None and max_chars >= 0 and len(text) > max_chars:
        text = text[:max_chars]
    return text


def safe_set_rna_text(item, attr, value, fallback="", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS):
    text = coerce_rna_restore_text(value, fallback=fallback, max_chars=max_chars)
    try:
        setattr(item, attr, text)
        return True
    except Exception:
        traceback.print_exc()
        try:
            setattr(item, attr, coerce_rna_restore_text(fallback, max_chars=max_chars))
        except Exception:
            traceback.print_exc()
        return False


def coerce_bool_value(value, fallback=False):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized in {"1", "true", "yes", "on", "启用", "是"}:
            return True
        if normalized in {"0", "false", "no", "off", "禁用", "否"}:
            return False
    return fallback


def coerce_int_value(value, fallback=0):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except Exception:
            return fallback
    return fallback


def coerce_version_tuple(value):
    if isinstance(value, (tuple, list)):
        result = []
        for item in value:
            try:
                result.append(int(item))
            except Exception:
                break
        return tuple(result)
    if isinstance(value, str):
        parts = re.findall(r"\d+", value)
        return tuple(int(part) for part in parts)
    return ()


def version_tuple_to_text(value):
    version = coerce_version_tuple(value)
    return ".".join(str(part) for part in version)


def compare_version_tuples(current, required):
    current = coerce_version_tuple(current)
    required = coerce_version_tuple(required)
    if not current or not required:
        return 0
    length = max(len(current), len(required))
    current = current + (0,) * (length - len(current))
    required = required + (0,) * (length - len(required))
    return (current > required) - (current < required)


def max_version_text(*values):
    best = ()
    for value in values:
        version = coerce_version_tuple(value)
        if version and (not best or compare_version_tuples(version, best) > 0):
            best = version
    return version_tuple_to_text(best)


def coerce_list_value(value):
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return []


def coerce_dict_value(value):
    return value if isinstance(value, dict) else {}


def sanitize_panel_match_payload(match_data):
    if not isinstance(match_data, dict):
        return None
    panel_id = coerce_text_value(match_data.get("panel_id", ""), max_chars=MAX_RNA_NAME_CHARS).strip()
    if not panel_id:
        return None
    return {
        "panel_id": panel_id,
        "title": clean_panel_title(coerce_text_value(match_data.get("title", ""), max_chars=MAX_RNA_NAME_CHARS), panel_id),
        "category": coerce_text_value(match_data.get("category", ""), max_chars=MAX_RNA_NAME_CHARS),
        "source_module": coerce_text_value(match_data.get("source_module", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "addon_version": version_tuple_to_text(match_data.get("addon_version", "")),
        "plugin_key": coerce_text_value(match_data.get("plugin_key", ""), max_chars=MAX_RNA_NAME_CHARS),
        "plugin_title": coerce_text_value(match_data.get("plugin_title", ""), max_chars=MAX_RNA_NAME_CHARS),
    }


def sanitize_module_payload(module_data):
    if not isinstance(module_data, dict):
        return None
    return {
        "name": normalize_workflow_name(coerce_text_value(module_data.get("name", ""), max_chars=MAX_RNA_NAME_CHARS), "默认脚本模板"),
        "enabled": coerce_bool_value(module_data.get("enabled", True), True),
        "use_custom_panel": coerce_bool_value(module_data.get("use_custom_panel", False), False),
        "runtime_panel_expanded": coerce_bool_value(
            module_data.get("runtime_panel_expanded", not module_prefers_collapsed_runtime_panel(module_data)),
            not module_prefers_collapsed_runtime_panel(module_data),
        ),
        "runtime_description_expanded": coerce_bool_value(module_data.get("runtime_description_expanded", False), False),
        "panel_title": normalize_text_value(coerce_text_value(module_data.get("panel_title", ""), max_chars=MAX_RNA_NAME_CHARS), ""),
        "panel_description": normalize_text_value(coerce_text_value(module_data.get("panel_description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        "script_path": coerce_text_value(module_data.get("script_path", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "description": normalize_text_value(coerce_text_value(module_data.get("description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        "text_block_name": normalize_text_value(coerce_text_value(module_data.get("text_block_name", ""), max_chars=MAX_RNA_NAME_CHARS), ""),
        "script_source": coerce_text_value(module_data.get("script_source", "")),
        "script_asset": coerce_text_value(module_data.get("script_asset", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "config_payload": coerce_text_value(module_data.get("config_payload", "")),
        "ai_doc": coerce_text_value(module_data.get("ai_doc", "")),
    }


def sanitize_script_library_payload(item_data):
    if not isinstance(item_data, dict):
        return None
    return {
        "name": normalize_workflow_name(coerce_text_value(item_data.get("name", ""), max_chars=MAX_RNA_NAME_CHARS), "脚本模板"),
        "description": normalize_text_value(coerce_text_value(item_data.get("description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        "tags": coerce_text_value(item_data.get("tags", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "use_custom_panel": coerce_bool_value(item_data.get("use_custom_panel", False), False),
        "panel_title": normalize_text_value(coerce_text_value(item_data.get("panel_title", ""), max_chars=MAX_RNA_NAME_CHARS), ""),
        "panel_description": normalize_text_value(coerce_text_value(item_data.get("panel_description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        "script_path": coerce_text_value(item_data.get("script_path", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "text_block_name": normalize_text_value(coerce_text_value(item_data.get("text_block_name", ""), max_chars=MAX_RNA_NAME_CHARS), ""),
        "script_source": coerce_text_value(item_data.get("script_source", "")),
        "script_asset": coerce_text_value(item_data.get("script_asset", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "config_payload": coerce_text_value(item_data.get("config_payload", "")),
        "ai_doc": coerce_text_value(item_data.get("ai_doc", "")),
    }


def sanitize_workflow_payload(workflow_data):
    if not isinstance(workflow_data, dict):
        return None
    return {
        "name": normalize_workflow_name(coerce_text_value(workflow_data.get("name", ""), max_chars=MAX_RNA_NAME_CHARS), "自定义工作流"),
        "is_default": coerce_bool_value(workflow_data.get("is_default", False), False),
        "description": normalize_workflow_description(coerce_text_value(workflow_data.get("description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        "tag_filter": coerce_text_value(workflow_data.get("tag_filter", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "missing_warning_dismissed": coerce_bool_value(workflow_data.get("missing_warning_dismissed", False), False),
        "panels": unique_panel_ids(
            coerce_rna_restore_text(panel_id, max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            for panel_id in coerce_list_value(workflow_data.get("panels", []))
        ),
        "panel_matches": [
            match_payload
            for match_payload in (sanitize_panel_match_payload(item) for item in coerce_list_value(workflow_data.get("panel_matches", [])))
            if match_payload is not None
        ],
        "modules": [
            module_payload
            for module_payload in (sanitize_module_payload(item) for item in coerce_list_value(workflow_data.get("modules", [])))
            if module_payload is not None
        ],
    }


def sanitize_space_payload(space_payload):
    if not isinstance(space_payload, dict):
        return None

    record_map = {}
    ordered_records = []
    for record_data in coerce_list_value(space_payload.get("panel_registry", [])):
        if not isinstance(record_data, dict):
            continue
        panel_id = coerce_rna_restore_text(record_data.get("panel_id", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS).strip()
        if not panel_id:
            continue
        payload = {
            "panel_id": panel_id,
            "title": clean_panel_title(coerce_rna_restore_text(record_data.get("title", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS), panel_id),
            "category": normalize_text_value(coerce_rna_restore_text(record_data.get("category", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS), ""),
            "tags": coerce_rna_restore_text(record_data.get("tags", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS),
            "source_module": normalize_text_value(coerce_rna_restore_text(record_data.get("source_module", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS), ""),
            "addon_version": coerce_rna_restore_text(version_tuple_to_text(record_data.get("addon_version", "")), max_chars=32),
        }
        if panel_id not in record_map:
            record_map[panel_id] = payload
            ordered_records.append(payload)
            continue
        existing = record_map[panel_id]
        for key in ("title", "category", "tags", "source_module"):
            if not existing.get(key) and payload.get(key):
                existing[key] = payload[key]

    workflows = []
    seen_signatures = set()
    for workflow_data in coerce_list_value(space_payload.get("workflows", [])):
        payload = sanitize_workflow_payload(workflow_data)
        if payload is None:
            continue
        signature = (
            payload["name"],
            bool(payload["is_default"]),
            payload["description"],
            payload["tag_filter"],
            tuple(payload["panels"]),
            tuple(
                (
                    module_item["name"],
                    module_item["enabled"],
                    module_item["use_custom_panel"],
                    module_item["runtime_panel_expanded"],
                    module_item["runtime_description_expanded"],
                    module_item["panel_title"],
                    module_item["panel_description"],
                    module_item["script_path"],
                    module_item["description"],
                    module_item["text_block_name"],
                    module_item["script_source"],
                    module_item.get("config_payload", ""),
                    module_item["ai_doc"],
                )
                for module_item in payload["modules"]
            ),
        )
        if signature in seen_signatures:
            continue
        seen_signatures.add(signature)
        workflows.append(payload)

    script_library = []
    seen_library = set()
    for item_data in coerce_list_value(space_payload.get("script_library", [])):
        payload = sanitize_script_library_payload(item_data)
        if payload is None:
            continue
        signature = (
            payload["name"],
            payload["description"],
            payload["tags"],
            payload["use_custom_panel"],
            payload["panel_title"],
            payload["panel_description"],
            payload["script_path"],
            payload["text_block_name"],
            payload["script_source"],
            payload.get("config_payload", ""),
            payload["ai_doc"],
        )
        if signature in seen_library:
            continue
        seen_library.add(signature)
        script_library.append(payload)

    return {
        "label": coerce_text_value(space_payload.get("label", "")),
        "active_workflow_index": coerce_int_value(space_payload.get("active_workflow_index", 0), 0),
        "settings": dict(coerce_dict_value(space_payload.get("settings", {}))),
        "panel_registry": ordered_records,
        "script_library": script_library,
        "workflows": workflows,
    }


def sanitize_full_payload(payload):
    if not isinstance(payload, dict):
        return None
    space_payloads = payload.get("space_states")
    if not isinstance(space_payloads, dict):
        return payload

    cleaned = {
        "schema_version": payload.get("schema_version", SCHEMA_VERSION),
        "exported_at": payload.get("exported_at", ""),
        "space_states": {},
        "window_layouts": sanitize_window_layouts(payload.get("window_layouts", [])),
    }
    for space_type, space_payload in space_payloads.items():
        space_type = coerce_text_value(space_type, "").strip()
        if not space_type:
            continue
        cleaned_payload = sanitize_space_payload(space_payload)
        if cleaned_payload is not None:
            cleaned["space_states"][space_type] = cleaned_payload
    return cleaned


def sanitize_window_layouts(value):
    if not isinstance(value, list):
        return []
    layouts = []
    for layout in value[:64]:
        if not isinstance(layout, dict):
            continue
        areas = []
        for area in layout.get("areas", [])[:64]:
            if not isinstance(area, dict):
                continue
            area_type = coerce_text_value(area.get("type", ""), "").strip()
            if area_type not in SUPPORTED_SPACE_TYPES:
                continue
            areas.append(
                {
                    "index": max(0, coerce_int_value(area.get("index", 0), 0)),
                    "type": area_type,
                    "ui_type": coerce_text_value(area.get("ui_type", ""), ""),
                    "x": coerce_int_value(area.get("x", 0), 0),
                    "y": coerce_int_value(area.get("y", 0), 0),
                    "width": max(0, coerce_int_value(area.get("width", 0), 0)),
                    "height": max(0, coerce_int_value(area.get("height", 0), 0)),
                }
            )
        if not areas:
            continue
        layouts.append(
            {
                "window_index": max(
                    0, coerce_int_value(layout.get("window_index", 0), 0)
                ),
                "workspace": coerce_text_value(layout.get("workspace", ""), ""),
                "screen": coerce_text_value(layout.get("screen", ""), ""),
                "areas": areas,
            }
        )
    return layouts


def sanitize_current_workflow_preset_payload(payload):
    if not isinstance(payload, dict):
        return None
    workflow_payload = sanitize_workflow_payload(payload.get("workflow"))
    if workflow_payload is None:
        return None
    space_payload = sanitize_space_payload(
        {
            "label": payload.get("space_label", ""),
            "active_workflow_index": 0,
            "settings": payload.get("settings", {}),
            "panel_registry": payload.get("panel_registry", []),
            "script_library": payload.get("script_library", []),
            "workflows": [workflow_payload],
        }
    )
    if space_payload is None:
        return None
    return {
        "schema_version": payload.get("schema_version", SCHEMA_VERSION),
        "preset_kind": CURRENT_WORKFLOW_PRESET_KIND,
        "exported_at": payload.get("exported_at", ""),
        "window_layouts": sanitize_window_layouts(payload.get("window_layouts", [])),
        "space_type": payload.get("space_type", "VIEW_3D"),
        "space_label": payload.get("space_label", ""),
        "preset_archive_path": coerce_text_value(payload.get("preset_archive_path", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
        "workflow_name": workflow_payload.get("name", ""),
        "settings": space_payload.get("settings", {}),
        "panel_registry": space_payload.get("panel_registry", []),
        "script_library": space_payload.get("script_library", []),
        "workflow": workflow_payload,
    }


def is_current_workflow_preset_payload(payload):
    if not isinstance(payload, dict):
        return False
    return payload.get("preset_kind") == CURRENT_WORKFLOW_PRESET_KIND or isinstance(payload.get("workflow"), dict)


def parse_tags(text):
    tags = []
    for raw_tag in (text or "").split(","):
        tag = raw_tag.strip().lower()
        if tag:
            tags.append(tag)
    return tags


def workflow_visible_panel_ids(state, workflow):
    if state is None or workflow is None:
        return []
    if workflow.is_default:
        return list(get_panel_cache(getattr(state, "space_type", "VIEW_3D")).keys())

    space_type = getattr(state, "space_type", "VIEW_3D")
    ordered = unique_panel_ids(
        panel_drawer_root_id(item.panel_id, space_type=space_type)
        for item in workflow.panels
        if item.panel_id != "BWFLOW_PT_workflow" and not is_builtin_default_panel_id(item.panel_id, space_type=space_type)
    )
    seen = set(ordered)

    workflow_tags = set(parse_tags(workflow.tag_filter))
    if workflow_tags:
        for record in state.panel_registry:
            record_tags = set(parse_tags(record.tags))
            drawer_id = panel_drawer_root_id(record.panel_id, space_type=space_type)
            if drawer_id not in seen and workflow_tags.intersection(record_tags):
                ordered.append(drawer_id)
                seen.add(drawer_id)
    return ordered


def panel_tree_root_id(panel_id, space_type=None):
    current_id = panel_id
    seen = set()
    while current_id and current_id not in seen:
        seen.add(current_id)
        parent_id = panel_parent_id(current_id, space_type=space_type)
        if not parent_id or parent_id == current_id:
            break
        current_id = parent_id
    return current_id or panel_id


def dynamic_multi_panel_root_id(panel_id, space_type=None):
    """Return the real host drawer for add-ons that generate panel classes."""
    if not panel_id:
        return ""
    target_space = space_type or "VIEW_3D"
    registry = get_panel_registry(target_space)
    cache = get_panel_cache(target_space)
    cls = registry.get(panel_id) or cache.get(panel_id)
    if cls is None:
        return ""

    module_name = str(getattr(cls, "__module__", "") or "").casefold()
    class_name = str(getattr(cls, "__name__", "") or "")
    parent_marker = str(getattr(cls, "PARENT_M_PANEL_ID", "") or "")
    if "uvpackmaster4" not in module_name:
        return ""
    if panel_id == "UVPM4_PT_MultiPanels":
        return panel_id
    if not parent_marker and not class_name.startswith("UVPM4_PT_MultiPanel"):
        return ""

    # UVPackmaster's marker is used to identify generated classes, but it is
    # not consistently the visible drawer ID.  All MultiPanel variants belong
    # to the single public UVPM4 host drawer.
    host_id = "UVPM4_PT_MultiPanels"
    if host_id in registry or host_id in cache:
        return host_id
    return ""


def panel_drawer_root_id(panel_id, space_type=None):
    target_space = space_type or "VIEW_3D"
    cache = PANEL_DRAWER_ROOT_CACHE_BY_SPACE.setdefault(target_space, {})
    cached = cache.get(panel_id)
    if cached is not None:
        return cached
    root_id = dynamic_multi_panel_root_id(panel_id, space_type=target_space)
    if not root_id:
        root_id = panel_tree_root_id(panel_id, space_type=target_space)
    cache[panel_id] = root_id
    return root_id


def panel_drawer_ids_for_records(records, space_type=None):
    return unique_panel_ids(panel_drawer_root_id(record.panel_id, space_type=space_type) for record in records if record is not None)


def panel_drawer_records(state, drawer_id):
    if state is None or not drawer_id:
        return []
    return list(get_panel_registry_lookup(state)["records_by_drawer"].get(drawer_id, []))


def panel_drawer_record(state, drawer_id):
    if state is None:
        return None
    direct = find_registry_record(state, drawer_id)
    if direct is not None:
        return direct
    records = panel_drawer_records(state, drawer_id)
    for record in records:
        if record.discovered:
            return record
    return records[0] if records else None


def panel_drawer_discovered(state, drawer_id):
    if state is None or not drawer_id:
        return False
    space_type = getattr(state, "space_type", "VIEW_3D")
    registry = get_panel_registry(space_type)
    cache = get_panel_cache(space_type)
    if drawer_id in registry or drawer_id in cache:
        return True
    records = get_panel_registry_lookup(state).get("records_by_drawer", {}).get(drawer_id, [])
    return any(record.discovered for record in records)


def panel_drawer_title(state, drawer_id):
    record = panel_drawer_record(state, drawer_id)
    if record is not None:
        return clean_panel_title(record.title, record.panel_id)
    return drawer_id or "未命名面板"


def panel_drawer_entry_for_id(state, drawer_id, selected_ids=None, active_panel_id="", fallback_index=-1):
    selected_ids = selected_ids or set()
    record = panel_drawer_record(state, drawer_id)
    discovered = panel_drawer_discovered(state, drawer_id)
    index = fallback_index
    if state is not None and record is not None:
        index = get_panel_registry_lookup(state).get("index_by_id", {}).get(drawer_id, fallback_index)
    title = panel_drawer_title(state, drawer_id)
    if not discovered and record is not None:
        family_title = panel_family_title(state, record)
        panel_title = clean_panel_title(getattr(record, "title", ""), getattr(record, "panel_id", drawer_id))
        if family_title and panel_title and panel_title.casefold() != family_title.casefold():
            title = f"{family_title} / {panel_title}"
        elif panel_title:
            title = panel_title
    return {
        "index": index,
        "record": record,
        "panel_id": drawer_id,
        "title": title,
        "depth": 0,
        "selected": drawer_id in selected_ids,
        "discovered": discovered,
        "is_active": drawer_id == active_panel_id,
    }


def panel_descendant_ids(panel_ids, space_type=None):
    expanded = set(panel_ids)
    children_map = {}
    cache = get_panel_cache(space_type)
    registry = get_panel_registry(space_type)

    for candidate_id in list(cache.keys()) + list(registry.keys()):
        parent_id = panel_parent_id(candidate_id, space_type=space_type)
        if parent_id and parent_id != candidate_id:
            children_map.setdefault(parent_id, []).append(candidate_id)

    stack = list(panel_ids)
    while stack:
        panel_id = stack.pop()
        for child_id in children_map.get(panel_id, []):
            if child_id in expanded:
                continue
            expanded.add(child_id)
            stack.append(child_id)
    return expanded


def build_panel_library_groups(state, workflow):
    cache_key = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    signature = panel_library_groups_signature(state, workflow)
    cached = PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return cached.get("groups", [])

    selected_ids = {item.panel_id for item in workflow.panels} if workflow is not None else set()
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    registry = list(getattr(state, "panel_registry", []))
    drawer_root_cache = {}

    def cached_drawer_root(panel_id):
        cached = drawer_root_cache.get(panel_id)
        if cached is not None:
            return cached
        cached = panel_drawer_root_id(panel_id, space_type=space_type)
        drawer_root_cache[panel_id] = cached
        return cached

    selected_drawer_ids = {cached_drawer_root(panel_id) for panel_id in selected_ids}
    registry_lookup = get_panel_registry_lookup(state) if state is not None else {}
    direct_record_lookup = registry_lookup.get("record_by_id", {})
    records_by_drawer = registry_lookup.get("records_by_drawer", {})
    panel_cache = get_panel_cache(space_type)
    groups = {}
    for index, record in enumerate(registry):
        try:
            panel_id = getattr(record, "panel_id", "")
            if panel_id == "BWFLOW_PT_workflow":
                continue
            if is_builtin_default_panel_record(record):
                continue
            drawer_id = cached_drawer_root(panel_id)
            family_title = workflow_family_group_title(state, drawer_id)
        except Exception:
            traceback.print_exc()
            continue
        group_key = panel_library_group_key_for_panel(state, drawer_id)
        group = groups.setdefault(
            group_key,
            {
                "key": group_key,
                "original_title": panel_group_original_title(state, panel_id, family_title),
                "title": family_title or "未分类插件",
                "records": [],
                "drawer_ids": [],
                "drawer_indexes": {},
            },
        )
        group["records"].append(record)
        group["drawer_ids"].append(drawer_id)
        group["drawer_indexes"].setdefault(drawer_id, index)

    ordered_groups = []
    for group in groups.values():
        drawer_ids = unique_panel_ids(group["drawer_ids"])
        header_items = []
        for drawer_id in drawer_ids:
            record = direct_record_lookup.get(drawer_id)
            if record is None:
                drawer_records = records_by_drawer.get(drawer_id, [])
                record = next((item for item in drawer_records if item.discovered), drawer_records[0] if drawer_records else None)
            discovered = bool(record and record.discovered)
            if not discovered:
                discovered = drawer_id in panel_cache or drawer_id in direct_record_lookup
            title = clean_panel_title(record.title, record.panel_id) if record is not None else (drawer_id or "未命名面板")
            header_items.append(
                {
                    "panel_id": drawer_id,
                    "index": group["drawer_indexes"].get(drawer_id, -1),
                    "record": record,
                    "title": title,
                    "selected": drawer_id in selected_drawer_ids,
                    "discovered": discovered,
                }
            )
        header_items.sort(
            key=lambda entry: (
                panel_drawer_default_order_index(
                    state,
                    entry["panel_id"],
                    space_type=space_type,
                ),
                entry["index"],
                entry["title"].casefold(),
                entry["panel_id"],
            )
        )
        if not header_items:
            continue

        group["title"] = panel_group_display_title(
            state,
            group.get("records", ()),
            group.get("title", ""),
        ) or group.get("title", "")
        ordered_groups.append(
            {
                "key": group["key"],
                "original_title": group.get("original_title", group["title"]),
                "title": group["title"] or "未分类插件",
                "drawer_ids": [entry["panel_id"] for entry in header_items],
                "record_ids": unique_panel_ids(
                    getattr(record, "panel_id", "")
                    for record in group.get("records", ())
                ),
                "first_panel_index": min(
                    (entry["index"] for entry in header_items),
                    default=-1,
                ),
                "selected_count": sum(1 for entry in header_items if entry["selected"]),
                "panel_count": len(header_items),
                "tree_selected": any(entry["selected"] for entry in header_items),
            }
        )

    ordered_groups.sort(key=lambda item: (item["title"].casefold(), item["key"]))
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE[cache_key] = {"signature": signature, "groups": ordered_groups}
    return ordered_groups


def parse_expanded_group_keys(text):
    return {item for item in (text or "").split("|") if item}


def serialize_expanded_group_keys(keys):
    return "|".join(sorted({item for item in keys if item}))


def is_group_expanded(state, group_key, selected=False):
    if state is None or not group_key:
        return True
    prop_name = "selected_group_expanded_keys" if selected else "panel_group_expanded_keys"
    keys = parse_expanded_group_keys(getattr(state, prop_name, ""))
    return group_key in keys


def set_group_expanded(state, group_key, expanded, selected=False):
    if state is None or not group_key:
        return
    prop_name = "selected_group_expanded_keys" if selected else "panel_group_expanded_keys"
    keys = parse_expanded_group_keys(getattr(state, prop_name, ""))
    if expanded:
        keys.add(group_key)
    else:
        keys.discard(group_key)
    setattr(state, prop_name, serialize_expanded_group_keys(keys))


def toggle_group_expanded(state, group_key, selected=False):
    expanded = is_group_expanded(state, group_key, selected=selected)
    set_group_expanded(state, group_key, not expanded, selected=selected)


def panel_group_matches_filter(group, filter_text):
    query = str(filter_text or "").strip().casefold()
    if not query:
        return True
    haystack = " ".join(
        str(value or "")
        for value in (
            group.get("title", ""),
            group.get("key", ""),
            " ".join(group.get("drawer_ids", []) or []),
            group.get("panel_id", ""),
        )
    ).casefold()
    return all(token in haystack for token in query.split())


def panel_groups_filter_signature(groups, filter_text):
    source = list(groups or [])
    return (
        str(filter_text or ""),
        tuple(
            (
                group.get("key", ""),
                group.get("title", ""),
                group.get("panel_id", ""),
                tuple(group.get("drawer_ids", ()) or ()),
                tuple(group.get("panel_ids", ()) or ()),
                int(group.get("panel_count", 0) or 0),
                int(group.get("selected_count", 0) or 0),
            )
            for group in source
        ),
    )


def filtered_panel_groups(groups, filter_text, cache_key=None):
    if not cache_key:
        return [group for group in list(groups or []) if panel_group_matches_filter(group, filter_text)]
    signature = panel_groups_filter_signature(groups, filter_text)
    cached = PANEL_GROUP_FILTER_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return cached.get("groups", [])
    result = [group for group in list(groups or []) if panel_group_matches_filter(group, filter_text)]
    PANEL_GROUP_FILTER_CACHE_BY_SPACE[cache_key] = {"signature": signature, "groups": result}
    return result


def clear_space_prefixed_cache(cache, space_type):
    prefix = f"{space_type}:"
    for key in list(cache.keys()):
        if str(key).startswith(prefix):
            cache.pop(key, None)


def paged_panel_groups(state, groups, prop_name, limit):
    groups = list(groups or [])
    limit = max(1, int(limit or 1))
    page_count = max(1, (len(groups) + limit - 1) // limit)
    page = clamp_index(int(getattr(state, prop_name, 0) or 0), page_count)
    if getattr(state, prop_name, 0) != page:
        try:
            setattr(state, prop_name, page)
        except Exception:
            pass
    start = page * limit
    return groups[start : start + limit], page, page_count


def clear_panel_library_click_state(state):
    if state is None:
        return
    state.panel_library_last_click_index = -1
    state.panel_library_last_click_time = 0.0
    state.panel_library_last_click_target = ""

def register_click_target(state, click_target):
    now = time.monotonic()
    clicked_same = getattr(state, "panel_library_last_click_target", "") == click_target
    clicked_recently = (now - getattr(state, "panel_library_last_click_time", 0.0)) <= DOUBLE_CLICK_SECONDS
    state.panel_library_last_click_target = click_target
    state.panel_library_last_click_time = now
    return clicked_same and clicked_recently


def event_indicates_double_click(event):
    if event is None:
        return False
    for attr in ("is_double_click", "double_click"):
        if getattr(event, attr, False):
            return True
    if getattr(event, "click_count", 0) >= DOUBLE_CLICK_CLICK_COUNT:
        return True
    return getattr(event, "type", "") == "DOUBLE_CLICK" or getattr(event, "value", "") == "DOUBLE_CLICK"


def is_double_click(state, click_target, event=None):
    if event_indicates_double_click(event):
        return True
    return register_scoped_click_target(state, click_target)


def should_treat_as_double_click(state, click_target, event=None):
    return is_double_click(state, click_target, event=event)


def click_target_scope(click_target):
    prefix = str(click_target or "").split(":", 1)[0]
    if prefix in {"panel", "selected", "group"}:
        return prefix
    return "misc"


def register_scoped_click_target(state, click_target):
    scope = click_target_scope(click_target)
    last_target = getattr(state, "panel_library_last_click_target", "")
    if click_target_scope(last_target) != scope:
        clear_panel_library_click_state(state)
    return register_click_target(state, click_target)


def workflow_panel_registry_index(state, workflow, panel_id):
    if state is None or workflow is None or not panel_id:
        return -1
    space_type = getattr(state, "space_type", "VIEW_3D")
    drawer_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
    lookup = get_panel_registry_lookup(state)
    for candidate_id in (panel_id, drawer_id):
        index = lookup["index_by_id"].get(candidate_id)
        if index is not None:
            return index
    drawer_records = lookup["records_by_drawer"].get(drawer_id, [])
    if drawer_records:
        first_panel_id = getattr(drawer_records[0], "panel_id", "")
        return lookup["index_by_id"].get(first_panel_id, -1)
    return -1


def build_selected_panel_groups(state, workflow):
    if state is None or workflow is None:
        return []
    cache_key = getattr(state, "space_type", "VIEW_3D")
    signature = selected_panel_group_summary_signature(state, workflow)
    cached = SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return cached.get("groups", [])

    active_panel_id = ""
    active_drawer_id = ""
    space_type = getattr(state, "space_type", "VIEW_3D")
    if workflow.panels:
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        active_panel_id = workflow.panels[active_index].panel_id
        active_drawer_id = panel_drawer_root_id(active_panel_id, space_type=space_type) or active_panel_id

    groups = {}
    seen_panel_ids = set()
    for index, item in enumerate(workflow.panels):
        panel_id = item.panel_id
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            continue
        if is_builtin_default_panel_id(panel_id, space_type=space_type):
            continue
        if panel_id in seen_panel_ids:
            continue
        seen_panel_ids.add(panel_id)

        drawer_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
        group_key = workflow_group_key_for_panel(state, panel_id)
        family_title = workflow_family_group_title(state, panel_id)
        group = groups.setdefault(
            group_key,
            {
                "key": group_key,
                "title": family_title or "未分类插件",
                "original_title": panel_group_original_title(state, panel_id, family_title),
                "panel_id": panel_id,
                "drawer_ids": [],
                "panel_ids": [],
                "workflow_indexes": [],
                "first_index": index,
                "is_active": False,
            },
        )
        if index < group["first_index"]:
            group["first_index"] = index
            group["panel_id"] = panel_id
        if drawer_id not in group["drawer_ids"]:
            group["drawer_ids"].append(drawer_id)
        if panel_id not in group["panel_ids"]:
            group["panel_ids"].append(panel_id)
            group["workflow_indexes"].append(index)
        if panel_id == active_panel_id or drawer_id == active_drawer_id:
            group["is_active"] = True

    ordered_groups = []
    for group in groups.values():
        panel_count = len(group["drawer_ids"])
        ordered_groups.append(
            {
                "key": group["key"],
                "title": group["title"] or "未分类插件",
                "original_title": group.get("original_title", group["title"]),
                "panel_id": group["panel_id"],
                "panel_count": panel_count,
                "plugin_title": panel_count_label(panel_count),
                "entries": [],
                "panel_ids": tuple(group.get("panel_ids", ())),
                "workflow_indexes": tuple(group.get("workflow_indexes", ())),
                "first_index": group["first_index"],
                "is_active": group["is_active"],
            }
        )

    ordered_groups.sort(
        key=lambda item: (
            item.get("first_index", 999999),
            item["title"].casefold(),
            item["key"],
        )
    )
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE[cache_key] = {"signature": signature, "groups": ordered_groups}
    return ordered_groups


def selected_panel_group_entries(state, workflow, group):
    if state is None or workflow is None or not isinstance(group, dict):
        return []
    group_key = group.get("key", "")
    if not group_key:
        return []
    cache_key = getattr(state, "space_type", "VIEW_3D")
    signature = (
        selected_panel_groups_signature(state, workflow),
        group_key,
    )
    group_cache = SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.setdefault(cache_key, {})
    cached = group_cache.get(group_key)
    if cached is not None and cached.get("signature") == signature:
        return [dict(entry) for entry in cached.get("entries", ())]

    active_panel_id = ""
    if workflow.panels:
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        active_panel_id = workflow.panels[active_index].panel_id

    space_type = getattr(state, "space_type", "VIEW_3D")
    selected_ids = {item.panel_id for item in workflow.panels}
    selected_drawer_ids = {
        panel_drawer_root_id(panel_id, space_type=space_type)
        for panel_id in selected_ids
    }
    selected_lookup_ids = selected_ids.union(selected_drawer_ids)
    entries = []
    panel_ids = list(group.get("panel_ids", ()) or ())
    workflow_indexes = list(group.get("workflow_indexes", ()) or ())
    if not panel_ids:
        seen_panel_ids = set()
        for index, item in enumerate(workflow.panels):
            panel_id = item.panel_id
            if not panel_id or panel_id == "BWFLOW_PT_workflow":
                continue
            if is_builtin_default_panel_id(panel_id, space_type=space_type):
                continue
            if panel_id in seen_panel_ids:
                continue
            seen_panel_ids.add(panel_id)
            if workflow_group_key_for_panel(state, panel_id) != group_key:
                continue
            panel_ids.append(panel_id)
            workflow_indexes.append(index)

    for fallback_pos, panel_id in enumerate(panel_ids):
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            continue
        if is_builtin_default_panel_id(panel_id, space_type=space_type):
            continue
        workflow_index = workflow_indexes[fallback_pos] if fallback_pos < len(workflow_indexes) else workflow_panel_registry_index(state, workflow, panel_id)
        entry = panel_drawer_entry_for_id(
            state,
            panel_id,
            selected_ids=selected_lookup_ids,
            active_panel_id=active_panel_id,
            fallback_index=workflow_index,
        )
        entry["workflow_index"] = workflow_index
        entries.append(entry)

    entries.sort(key=lambda entry: (entry["workflow_index"], entry["title"].casefold(), entry["panel_id"]))
    group_cache[group_key] = {"signature": signature, "entries": tuple(dict(entry) for entry in entries)}
    return entries


def panel_library_group_entries(state, workflow, group):
    if state is None or workflow is None or not isinstance(group, dict):
        return []
    cache_key = getattr(state, "space_type", "VIEW_3D")
    signature = (
        panel_registry_lookup_signature(state),
        workflow_panel_membership_signature(workflow),
        group.get("key", ""),
        tuple(group.get("drawer_ids", ())),
    )
    group_cache = PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.setdefault(cache_key, {})
    cached = group_cache.get(group.get("key", ""))
    if cached is not None and cached.get("signature") == signature:
        return [dict(entry) for entry in cached.get("entries", ())]

    selected_ids = {item.panel_id for item in workflow.panels}
    space_type = getattr(state, "space_type", "VIEW_3D")
    selected_drawer_ids = {panel_drawer_root_id(panel_id, space_type=space_type) for panel_id in selected_ids}
    direct_record_lookup = get_panel_registry_lookup(state)["record_by_id"]
    panel_cache = get_panel_cache(space_type)
    registry = list(getattr(state, "panel_registry", []))
    entries = []

    for drawer_id in group.get("drawer_ids", []):
        record = direct_record_lookup.get(drawer_id)
        if record is None:
            drawer_records = panel_drawer_records(state, drawer_id)
            record = next((item for item in drawer_records if item.discovered), drawer_records[0] if drawer_records else None)
        discovered = bool(record and record.discovered)
        if not discovered:
            discovered = drawer_id in panel_cache or drawer_id in direct_record_lookup
        title = clean_panel_title(record.title, record.panel_id) if record is not None else (drawer_id or "未命名面板")
        entries.append(
            {
                "index": workflow_panel_registry_index(state, workflow, drawer_id),
                "record": record,
                "panel_id": drawer_id,
                "title": title,
                "depth": 0,
                "selected": drawer_id in selected_drawer_ids,
                "discovered": discovered,
                "is_active": False,
                "component_title": title,
            }
        )

    entries.sort(
        key=lambda entry: (
            panel_drawer_default_order_index(
                state,
                entry["panel_id"],
                space_type=space_type,
            ),
            entry["index"],
            entry["title"].casefold(),
            entry["panel_id"],
        )
    )
    group_cache[group.get("key", "")] = {
        "signature": signature,
        "entries": [dict(entry) for entry in entries],
    }
    return entries


def workflow_toggleable_panel_ids(state, panel_ids):
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    return [
        panel_id
        for panel_id in unique_panel_ids(panel_ids)
        if panel_id and not is_builtin_default_panel_id(panel_id, space_type=space_type)
    ]


def workflow_family_drawer_ids(state, workflow, group_key):
    if state is None or workflow is None or not group_key:
        return []
    space_type = getattr(state, "space_type", "VIEW_3D")
    drawer_ids = []
    for item in getattr(workflow, "panels", []):
        panel_id = getattr(item, "panel_id", "")
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            continue
        if workflow_group_key_for_panel(state, panel_id) != group_key:
            continue
        drawer_ids.append(panel_drawer_root_id(panel_id, space_type=space_type) or panel_id)
    return workflow_toggleable_panel_ids(state, drawer_ids)


def workflow_family_order_groups(state, workflow):
    if state is None or workflow is None:
        return []
    space_type = getattr(state, "space_type", "VIEW_3D")
    cache_key = f"{space_type}:{getattr(workflow, 'name', '')}"
    signature = (
        workflow_panel_membership_signature(workflow),
        panel_registry_lookup_signature(state),
    )
    cached = WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return [
            {
                "key": group.get("key", ""),
                "title": group.get("title", ""),
                "ids": list(group.get("ids", ())),
                "first_index": group.get("first_index", 0),
            }
            for group in cached.get("groups", ())
        ]

    groups = []
    group_map = {}
    for index, item in enumerate(getattr(workflow, "panels", [])):
        panel_id = item.panel_id
        if panel_id == "BWFLOW_PT_workflow":
            continue
        if is_builtin_default_panel_id(panel_id, space_type=space_type):
            continue
        family_title = workflow_family_group_title(state, panel_id)
        group_key = workflow_group_key_for_panel(state, panel_id)
        group = group_map.get(group_key)
        if group is None:
            group = {
                "key": group_key,
                "title": family_title or "未分类插件",
                "ids": [],
                "first_index": index,
            }
            group_map[group_key] = group
            groups.append(group)
        if panel_id not in group["ids"]:
            group["ids"].append(panel_id)
    WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE[cache_key] = {
        "signature": signature,
        "groups": tuple(
            {
                "key": group.get("key", ""),
                "title": group.get("title", ""),
                "ids": tuple(group.get("ids", ())),
                "first_index": group.get("first_index", 0),
            }
            for group in groups
        ),
    }
    return groups


def panel_drawer_default_order_index(state, drawer_id, space_type=None):
    if not drawer_id:
        return 999999

    target_space = space_type or (getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D")
    baseline_state = PRE_GO_WORKFLOW_STATE or {}
    baseline_orders = baseline_state.get("panel_orders", {})
    baseline_order_indices = baseline_state.get("panel_order_indices", {})
    baseline_bl_orders = baseline_state.get("panel_bl_orders", {})
    baseline_registration_orders = baseline_state.get("panel_registration_orders", {})
    baseline_order = baseline_orders.get(target_space, ())
    baseline_index = baseline_order_indices.get(target_space, {})

    # The drawer itself must win over one of its child panels.  Blender and
    # several add-ons register child classes before their parent, so matching
    # only by root can otherwise move the whole drawer to the wrong position.
    exact_index = baseline_index.get(drawer_id)
    if exact_index is not None:
        # Keep the original Blender ordering key intact.  The compact sidebar
        # uses the same class order, while the registry index can be affected
        # by GoWorkflow's later unregister/register pass.
        return (
            int(baseline_bl_orders.get(target_space, {}).get(drawer_id, 0) or 0) * 1000000
            + int(baseline_registration_orders.get(target_space, {}).get(drawer_id, exact_index))
        )

    # A workflow may contain a root ID that was not directly discoverable at
    # startup (dynamic panels are the common case).  Use the first original
    # registration position of its descendants only as a fallback.
    if baseline_order:
        descendant_indices = [
            baseline_index.get(panel_id)
            for panel_id in baseline_order
            if panel_drawer_root_id(panel_id, space_type=target_space) == drawer_id
        ]
        descendant_indices = [index for index in descendant_indices if index is not None]
        if descendant_indices:
            return min(descendant_indices)

    for index, panel_id in enumerate(get_panel_cache(target_space).keys()):
        if panel_id == drawer_id:
            return index
    for index, panel_id in enumerate(get_panel_cache(target_space).keys()):
        if panel_drawer_root_id(panel_id, space_type=target_space) == drawer_id:
            return index

    registration_order = panel_registration_order_map(space_type=target_space)
    registry = get_panel_registry(target_space)
    for index, panel_id in enumerate(registry.keys()):
        if panel_id == drawer_id:
            return 100000 + registration_order.get(panel_id, index)
    for index, panel_id in enumerate(registry.keys()):
        if panel_drawer_root_id(panel_id, space_type=target_space) == drawer_id:
            return 100000 + registration_order.get(panel_id, index)

    for index, record in enumerate(getattr(state, "panel_registry", [])):
        record_id = getattr(record, "panel_id", "")
        if not record_id:
            continue
        if record_id == drawer_id:
            return 200000 + index
    for index, record in enumerate(getattr(state, "panel_registry", [])):
        record_id = getattr(record, "panel_id", "")
        if record_id and panel_drawer_root_id(record_id, space_type=target_space) == drawer_id:
            return 200000 + index
    return 999999


def workflow_family_group_title(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return "Go工作流"
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    drawer_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
    title = panel_drawer_title(state, drawer_id) if state is not None else drawer_id
    record = panel_drawer_record(state, drawer_id) if state is not None else None
    source_family = panel_source_module_family(record)
    if source_family == "addon" and record is not None:
        plugin_title = panel_plugin_title(state, drawer_id)
        if is_usable_family_label(plugin_title):
            return plugin_title
    normalized_title = normalized_panel_match_text(title)
    normalized_id = normalized_panel_match_text(drawer_id)
    looks_like_internal_id = (
        not title
        or normalized_title == normalized_id
        or "_pt_" in normalized_title
        or normalized_title.startswith("bc_")
        or normalized_title.startswith("uvpm")
    )
    if looks_like_internal_id and record is not None:
        family_title = panel_family_title(state, record)
        if is_usable_family_label(family_title):
            return family_title
    return title or drawer_id


def workflow_group_key_for_panel(state, panel_id):
    return panel_library_group_key_for_panel(state, panel_id)


def panel_library_group_key_for_panel(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return ""
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    drawer_id = panel_drawer_root_id(panel_id, space_type=space_type) or panel_id
    record = panel_drawer_record(state, drawer_id) if state is not None else None
    plugin_key = panel_plugin_key_for_record(record) or infer_plugin_key_from_panel_id(drawer_id)
    source_family = panel_source_module_family(record)
    return f"plugin_group:{panel_family_key(plugin_key)}:{panel_component_key(source_family)}"


def panel_source_module_family(record):
    source_module = str(getattr(record, "source_module", "") or "").strip()
    if re.search(r"(?:^|\.)module_[a-z0-9_]+$", source_module, flags=re.IGNORECASE):
        return panel_component_key(source_module.rsplit(".", 1)[-1])
    return "addon"


def workflow_family_member_indices(state, workflow, group_key=""):
    if state is None or workflow is None:
        return []
    indices = []
    for index, item in enumerate(getattr(workflow, "panels", [])):
        panel_id = getattr(item, "panel_id", "")
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            continue
        if group_key and workflow_group_key_for_panel(state, panel_id) != group_key:
            continue
        indices.append(index)
    return indices


def workflow_auto_tag_panel_ids(state, workflow):
    if state is None or workflow is None:
        return []
    workflow_tags = set(parse_tags(workflow.tag_filter))
    if not workflow_tags:
        return []

    panel_ids = []
    space_type = getattr(state, "space_type", "VIEW_3D")
    for record in state.panel_registry:
        record_tags = set(parse_tags(record.tags))
        if workflow_tags.intersection(record_tags):
            panel_ids.append(panel_drawer_root_id(record.panel_id, space_type=space_type))
    return unique_panel_ids(panel_ids)


def workflow_explicit_panel_ids(workflow):
    if workflow is None:
        return []
    return unique_panel_ids([item.panel_id for item in workflow.panels if item.panel_id != "BWFLOW_PT_workflow"])


def workflow_missing_panel_ids(state, workflow):
    if state is None or workflow is None:
        return []

    space_type = getattr(state, "space_type", "VIEW_3D")
    signature = (
        workflow_panel_membership_signature(workflow),
        panel_registry_lookup_signature(state),
        len(get_panel_registry(space_type)),
        len(get_panel_cache(space_type)),
        tuple(payload.get("panel_id", "") for payload in imported_workflow_panel_matches(state, workflow)),
    )
    cache_key = f"{space_type}:{getattr(workflow, 'name', '')}"
    cached = WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return list(cached.get("missing_ids", ()))

    missing_ids = []
    for panel_id in workflow_explicit_panel_ids(workflow):
        drawer_id = panel_drawer_root_id(panel_id, space_type=space_type)
        if panel_drawer_discovered(state, drawer_id):
            continue
        missing_ids.append(drawer_id or panel_id)
    for payload in imported_workflow_missing_panel_matches(state, workflow):
        panel_id = payload.get("panel_id", "")
        if panel_id:
            missing_ids.append(panel_id)
    result = unique_panel_ids(missing_ids)
    WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE[cache_key] = {
        "signature": signature,
        "missing_ids": tuple(result),
    }
    return result


def workflow_missing_records(state, workflow):
    if bool(getattr(workflow, "missing_warning_dismissed", False)):
        return []
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    signature = (
        tuple(workflow_missing_panel_ids(state, workflow)),
        tuple(payload.get("panel_id", "") for payload in imported_workflow_panel_matches(state, workflow)),
    )
    cache_key = f"{space_type}:{getattr(workflow, 'name', '')}"
    cached = WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE.get(cache_key)
    if cached is not None and cached.get("signature") == signature:
        return list(cached.get("records", ()))
    match_by_id = imported_panel_match_payload_by_id(state, workflow)
    records = []
    for panel_id in workflow_missing_panel_ids(state, workflow):
        record = panel_drawer_record(state, panel_id) or find_registry_record(state, panel_id)
        if record is None and panel_id in match_by_id:
            record = ImportedMissingPanelRecord(match_by_id[panel_id])
        if record is None:
            record = ImportedMissingPanelRecord({"panel_id": panel_id})
        records.append(record)
    WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE[cache_key] = {
        "signature": signature,
        "records": tuple(records),
    }
    return records


def workflow_has_imported_missing_panel_matches(state, workflow):
    if state is None or workflow is None or getattr(workflow, "is_default", False):
        return False
    if not imported_workflow_panel_matches(state, workflow):
        return False
    return bool(workflow_missing_panel_ids(state, workflow))


def workflow_can_reveal_or_match_missing_panels(state, workflow):
    if state is None or workflow is None or getattr(workflow, "is_default", False):
        return False
    if workflow_has_imported_missing_panel_matches(state, workflow):
        return True
    return bool(getattr(workflow, "missing_warning_dismissed", False)) and bool(workflow_missing_panel_ids(state, workflow))


def workflow_missing_panel_summary(state, workflows, limit=4):
    missing_ids = []
    for workflow in workflows or []:
        if bool(getattr(workflow, "missing_warning_dismissed", False)):
            continue
        missing_ids.extend(workflow_missing_panel_ids(state, workflow))
    missing_ids = unique_panel_ids(missing_ids)
    titles = []
    plugin_hints = []
    for panel_id in missing_ids[: max(0, int(limit or 0))]:
        record = panel_drawer_record(state, panel_id) or find_registry_record(state, panel_id)
        if record is None:
            for workflow in workflows or []:
                payload = imported_panel_match_payload_by_id(state, workflow).get(panel_id)
                if payload:
                    record = ImportedMissingPanelRecord(payload)
                    break
        if record is not None:
            titles.append(clean_panel_title(getattr(record, "title", ""), getattr(record, "panel_id", panel_id)) or panel_id)
            source_module = getattr(record, "source_module", "")
            plugin_key = panel_plugin_key_from_module(source_module)
            if plugin_key:
                plugin_hints.append(plugin_key)
        else:
            titles.append(panel_id)
    suffix = ""
    if titles:
        suffix = "：" + "、".join(titles)
        if len(missing_ids) > len(titles):
            suffix += f" 等 {len(missing_ids)} 个"
    plugin_hints = sorted(set(plugin_hints))
    if plugin_hints:
        suffix += f"；可能缺少插件 {', '.join(plugin_hints[:3])}"
    return len(missing_ids), suffix


def workflow_low_version_plugin_summary(state, workflows, limit=3):
    if state is None:
        return 0, ""
    items = []
    seen = set()
    for workflow in workflows or []:
        for panel_id in workflow_explicit_panel_ids(workflow):
            drawer_id = panel_drawer_root_id(panel_id, space_type=getattr(state, "space_type", "VIEW_3D")) or panel_id
            record = panel_drawer_record(state, drawer_id) or find_registry_record(state, drawer_id)
            if record is None:
                continue
            required = coerce_version_tuple(getattr(record, "addon_version", ""))
            if not required:
                continue
            source_module = getattr(record, "source_module", "")
            current_text = addon_version_from_module_name(source_module)
            current = coerce_version_tuple(current_text)
            if not current or compare_version_tuples(current, required) >= 0:
                continue
            plugin_key = panel_plugin_key_from_module(source_module) or source_module or drawer_id
            key = (plugin_key, current, required)
            if key in seen:
                continue
            seen.add(key)
            items.append(
                f"{plugin_key} {version_tuple_to_text(current)} < {version_tuple_to_text(required)}"
            )
    if not items:
        return 0, ""
    shown = items[: max(0, int(limit or 0))]
    suffix = "；插件版本偏低：" + "、".join(shown)
    if len(items) > len(shown):
        suffix += f" 等 {len(items)} 个"
    return len(items), suffix


def finish_current_space_preset_import(context, state, imported_workflows):
    mark_imported_preset_data_dirty(state, scene=context.scene, context=context)
    schedule_imported_preset_asset_prune(scene=context.scene)
    missing_count, missing_suffix = workflow_missing_panel_summary(state, imported_workflows)
    low_version_count, low_version_suffix = workflow_low_version_plugin_summary(state, imported_workflows)
    return missing_count, missing_suffix, low_version_count, low_version_suffix


def workflow_effective_panel_count(state, workflow):
    return len(workflow_visible_panel_ids(state, workflow))


def append_panel_ids_to_workflow(workflow, panel_ids):
    current_ids = {item.panel_id for item in workflow.panels}
    added = 0
    for panel_id in panel_ids:
        if not panel_id or panel_id in current_ids:
            continue
        item = workflow.panels.add()
        safe_set_rna_text(item, "panel_id", panel_id, max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        current_ids.add(panel_id)
        added += 1
    if workflow.panels:
        workflow.active_panel_index = clamp_index(len(workflow.panels) - 1, len(workflow.panels))
    return added


def all_available_drawer_panel_ids(state):
    if state is None:
        return []
    space_type = getattr(state, "space_type", "VIEW_3D")
    drawer_ids = []
    for record in getattr(state, "panel_registry", []):
        if record.panel_id.startswith("BWFLOW_"):
            continue
        if not record.discovered:
            continue
        if is_builtin_default_panel_record(record):
            continue
        drawer_id = panel_drawer_root_id(record.panel_id, space_type=space_type)
        if drawer_id and panel_drawer_discovered(state, drawer_id):
            drawer_ids.append(drawer_id)
    return unique_panel_ids(drawer_ids)


def create_synced_workflow_for_all_spaces(scene, name):
    workflow_name = unique_workflow_name_across_spaces(scene, name, fallback="新工作流")
    created = []
    global IS_INITIALIZING_ADDON
    previous_initializing = IS_INITIALIZING_ADDON
    IS_INITIALIZING_ADDON = True
    try:
        for space_type in iter_supported_space_types():
            rebuild_panel_cache(scene=scene, space_type=space_type)
            state = get_state(scene=scene, space_type=space_type)
            if state is None:
                continue
            workflow = state.workflows.add()
            workflow.name = workflow_name
            workflow.is_default = False
            workflow.description = ""
            if space_type != "VIEW_3D":
                append_panel_ids_to_workflow(workflow, all_available_drawer_panel_ids(state))
            state.active_workflow_index = len(state.workflows) - 1
            ensure_one_default_workflow(state)
            ensure_go_workflow_panel_entry(state)
            normalize_workflow_active_panel_index(workflow)
            created.append((space_type, workflow))
    finally:
        IS_INITIALIZING_ADDON = previous_initializing
    return created


def related_plugin_panel_ids(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return []
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    root_id = panel_tree_root_id(panel_id, space_type=space_type)
    related = []
    cache = get_panel_cache(space_type)
    registry = get_panel_registry(space_type)
    candidate_ids = unique_panel_ids(list(cache.keys()) + list(registry.keys()) + [panel_id])
    for candidate_id in candidate_ids:
        if panel_tree_root_id(candidate_id, space_type=space_type) == root_id:
            related.append(candidate_id)
    return unique_panel_ids(related or [panel_id])


def panel_tree_workflow_ids(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return []
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    root_id = panel_tree_root_id(panel_id, space_type=space_type)
    return [root_id or panel_id]


def panel_drawer_workflow_ids(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return []
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    return [panel_drawer_root_id(panel_id, space_type=space_type) or panel_id]


def panel_component_workflow_ids(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return []
    record = find_registry_record(state, panel_id) if state is not None else None
    if record is None:
        return panel_tree_workflow_ids(state, panel_id)

    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    family = panel_family_title(state, record)
    component = panel_component_title(state, record, root_id=panel_tree_root_id(panel_id, space_type=space_type))
    family_key = panel_family_key(family)
    component_key = panel_component_key(component)
    root_ids = []
    for candidate in getattr(state, "panel_registry", []):
        if candidate.panel_id == "BWFLOW_PT_workflow":
            continue
        candidate_root = panel_tree_root_id(candidate.panel_id, space_type=space_type)
        if panel_family_key(panel_family_title(state, candidate)) != family_key:
            continue
        if panel_component_key(panel_component_title(state, candidate, root_id=candidate_root)) != component_key:
            continue
        root_ids.append(candidate_root)
    return unique_panel_ids(root_ids or panel_tree_workflow_ids(state, panel_id))


def workflow_panel_order_ids(workflow):
    if workflow is None:
        return []
    return unique_panel_ids([item.panel_id for item in workflow.panels])


def workflow_editable_panel_indices(workflow):
    if workflow is None:
        return []
    return [index for index, item in enumerate(workflow.panels) if item.panel_id != "BWFLOW_PT_workflow"]


def editable_workflow_panel_count(workflow):
    return len(workflow_editable_panel_indices(workflow))


def workflow_panel_group_key(state, panel_id):
    if not panel_id or panel_id == "BWFLOW_PT_workflow":
        return "fixed:go_workflow"
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    drawer_id = panel_drawer_root_id(panel_id, space_type=space_type)
    if drawer_id and drawer_id != panel_id:
        panel_id = drawer_id
    record = find_registry_record(state, panel_id) if state is not None else None
    if record is None:
        return f"panel:{panel_id}"
    return "drawer:{family}:{drawer}".format(
        family=panel_family_key(panel_family_title(state, record)),
        drawer=panel_component_key(panel_drawer_title(state, panel_id)),
    )


def workflow_panel_group_title(state, panel_id):
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    drawer_id = panel_drawer_root_id(panel_id, space_type=space_type)
    if drawer_id:
        panel_id = drawer_id
    record = find_registry_record(state, panel_id) if state is not None else None
    if record is None:
        return panel_id or "缺失面板"
    family_title = panel_family_title(state, record)
    drawer_title = panel_drawer_title(state, panel_id)
    if panel_component_key(family_title) == panel_component_key(drawer_title):
        return family_title
    return f"{family_title} / {drawer_title}"


def workflow_order_groups(state, workflow):
    groups = []
    group_map = {}
    for index, item in enumerate(getattr(workflow, "panels", [])):
        panel_id = item.panel_id
        if panel_id == "BWFLOW_PT_workflow":
            continue
        key = workflow_panel_group_key(state, panel_id)
        group = group_map.get(key)
        if group is None:
            group = {
                "key": key,
                "title": workflow_panel_group_title(state, panel_id),
                "ids": [],
                "first_index": index,
            }
            group_map[key] = group
            groups.append(group)
        drawer_id = panel_drawer_root_id(panel_id, space_type=getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D")
        if drawer_id not in group["ids"]:
            group["ids"].append(drawer_id)
    return groups


def active_workflow_group_key(state, workflow):
    if workflow is None or not workflow.panels:
        return ""
    active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
    panel_id = workflow.panels[active_index].panel_id
    if panel_id == "BWFLOW_PT_workflow":
        normalize_workflow_active_panel_index(workflow)
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        panel_id = workflow.panels[active_index].panel_id if workflow.panels else ""
    return workflow_panel_group_key(state, panel_id) if panel_id else ""


def active_workflow_family_group_key(state, workflow):
    if workflow is None or not workflow.panels:
        return ""
    active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
    panel_id = workflow.panels[active_index].panel_id
    if panel_id == "BWFLOW_PT_workflow":
        normalize_workflow_active_panel_index(workflow)
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        panel_id = workflow.panels[active_index].panel_id if workflow.panels else ""
    return workflow_group_key_for_panel(state, panel_id) if panel_id else ""


def set_active_workflow_panel_by_id(workflow, panel_id):
    for index, item in enumerate(getattr(workflow, "panels", [])):
        if item.panel_id == panel_id:
            workflow.active_panel_index = index
            return True
    normalize_workflow_active_panel_index(workflow)
    return False


def replace_workflow_groups(workflow, groups, active_panel_id=""):
    ordered_ids = []
    for group in groups:
        ordered_ids.extend(group.get("ids", []))
    replace_workflow_panels(workflow, ordered_ids)
    if active_panel_id:
        set_active_workflow_panel_by_id(workflow, active_panel_id)


def mark_panel_order_pending(state, scene=None, context=None):
    if state is None:
        return
    if not workflow_runtime_initialized(state):
        return
    space_type = getattr(state, "space_type", "VIEW_3D")
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:library", None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:selected", None)
    clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, space_type)
    clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, space_type)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    clear_space_prefixed_cache(WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE, space_type)
    PANEL_FILTER_SIGNATURE_BY_SPACE.pop(space_type, None)
    state.panel_order_pending_apply = False
    workflow = get_active_workflow(state)
    if workflow is not None and not workflow.is_default:
        ordered_ids = workflow_ordered_panel_ids(state, workflow)
        apply_panel_order_overrides(ordered_ids, space_type=space_type)
    if scene is not None:
        save_global_workflow_state(scene)
    if not tag_redraw_context_area(context):
        tag_redraw_all(space_type=space_type)


def mark_panel_visibility_pending(state, scene=None, context=None):
    if state is None:
        return
    if not workflow_runtime_initialized(state):
        return
    space_type = getattr(state, "space_type", "VIEW_3D")
    state.panel_visibility_pending_apply = False
    state.panel_order_pending_apply = False
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:library", None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:selected", None)
    clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, space_type)
    clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, space_type)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    clear_space_prefixed_cache(WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE, space_type)
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    apply_panel_visibility_overrides(
        scene=scene,
        space_type=space_type,
        restore_first=False,
        install_poll=True,
        repair_callbacks=False,
    )
    if scene is not None:
        save_global_workflow_state(scene)
    if not tag_redraw_context_area(context):
        tag_redraw_all(space_type=space_type)


def queue_panel_visibility_pending(state, scene=None, context=None):
    """Apply panel visibility after the current UI event has returned."""
    if state is None or not workflow_runtime_initialized(state):
        return
    space_type = getattr(state, "space_type", "VIEW_3D")
    state.panel_visibility_pending_apply = False
    state.panel_order_pending_apply = False
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:library", None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:selected", None)
    PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, space_type)
    clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, space_type)
    clear_space_prefixed_cache(WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE, space_type)
    schedule_deferred_runtime_refresh(
        scene=scene or safe_context_scene(),
        intervals=(0.05,),
        space_type=space_type,
    )
    schedule_global_workflow_state_save(scene=scene or safe_context_scene())
    if not tag_redraw_context_area(context):
        tag_redraw_all(space_type=space_type)


def mark_imported_preset_data_dirty(state, scene=None, context=None):
    if state is None:
        return
    space_type = getattr(state, "space_type", "VIEW_3D")
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:library", None)
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{space_type}:selected", None)
    clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, space_type)
    clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, space_type)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    clear_space_prefixed_cache(WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE, space_type)
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_FILTER_SIGNATURE_BY_SPACE.pop(space_type, None)
    if scene is not None:
        save_global_workflow_state(scene)
    tag_redraw_context_area(context)


def normalize_workflow_active_panel_index(workflow):
    if workflow is None or not workflow.panels:
        return
    current_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
    if workflow.panels[current_index].panel_id != "BWFLOW_PT_workflow":
        workflow.active_panel_index = current_index
        return

    for index, item in enumerate(workflow.panels):
        if item.panel_id != "BWFLOW_PT_workflow":
            workflow.active_panel_index = index
            return

    workflow.active_panel_index = 0


def replace_workflow_panels(workflow, panel_ids):
    clear_collection(workflow.panels)
    ordered_ids = unique_panel_ids(panel_ids)
    if workflow is not None and not workflow.is_default and "BWFLOW_PT_workflow" not in ordered_ids:
        ordered_ids.insert(0, "BWFLOW_PT_workflow")
    for panel_id in ordered_ids:
        item = workflow.panels.add()
        item.panel_id = panel_id
    workflow.active_panel_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
    normalize_workflow_active_panel_index(workflow)


def ensure_go_workflow_panel_entry(state):
    if state is None:
        return
    for workflow in state.workflows:
        if workflow.is_default:
            continue
        has_entry = any(item.panel_id == "BWFLOW_PT_workflow" for item in workflow.panels)
        if not has_entry:
            item = workflow.panels.add()
            item.panel_id = "BWFLOW_PT_workflow"
        normalize_workflow_active_panel_index(workflow)


def purge_builtin_default_panels(state):
    if state is None:
        return

    removed_ids = set()
    for index in range(len(state.panel_registry) - 1, -1, -1):
        record = state.panel_registry[index]
        if not is_builtin_default_panel_record(record):
            continue
        removed_ids.add(record.panel_id)
        state.panel_registry.remove(index)

    if not removed_ids:
        return

    for workflow in state.workflows:
        kept_ids = []
        for item in workflow.panels:
            panel_id = item.panel_id
            if panel_id in removed_ids or is_builtin_default_panel_id(panel_id):
                continue
            kept_ids.append(panel_id)
        replace_workflow_panels(workflow, kept_ids)


def expand_panel_family(panel_ids, space_type=None):
    expanded = set(panel_ids)
    cache = get_panel_cache(space_type)
    changed = True
    while changed:
        changed = False
        for panel_id, cls in cache.items():
            parent_id = getattr(cls, "bl_parent_id", "")
            if panel_id in expanded and parent_id and parent_id not in expanded:
                expanded.add(parent_id)
                changed = True
    return expanded


def compute_allowed_panel_ids(state):
    workflow = get_active_workflow(state)
    if workflow is None or workflow.is_default:
        return None
    return workflow_visibility_data(state, workflow)["allowed_ids"]


def workflow_visibility_data_signature(state, workflow):
    if state is None or workflow is None:
        return ()
    space_type = getattr(state, "space_type", "VIEW_3D")
    registry = get_panel_registry(space_type)
    return (
        panel_registry_lookup_signature(state),
        workflow_panel_membership_signature(workflow),
        getattr(workflow, "tag_filter", ""),
        tuple(registry.keys()),
    )


def workflow_visibility_data(state, workflow):
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    registry = get_panel_registry(space_type)
    if state is None or workflow is None or workflow.is_default:
        return {
            "visible_ids": list(registry.keys()),
            "allowed_ids": None,
            "ordered_ids": list(registry.keys()),
        }

    signature = workflow_visibility_data_signature(state, workflow)
    cached = PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.get(space_type)
    if cached is not None and cached.get("signature") == signature:
        return cached["data"]

    explicit_workflow_ids = [
        panel_id
        for panel_id in workflow_panel_order_ids(workflow)
        if panel_id != "BWFLOW_PT_workflow" and not is_builtin_default_panel_id(panel_id, space_type=space_type)
    ]
    panel_order_ids = unique_panel_ids(
        panel_drawer_root_id(panel_id, space_type=space_type)
        for panel_id in explicit_workflow_ids
    )
    explicit_ids = [panel_id for panel_id in panel_order_ids if panel_id != "BWFLOW_PT_workflow"]
    auto_ids = [panel_id for panel_id in workflow_auto_tag_panel_ids(state, workflow) if panel_id not in explicit_ids]
    visible_ids = explicit_ids + auto_ids
    visible_set = set(visible_ids)
    allowed_for_order = expand_panel_family(panel_descendant_ids(visible_ids, space_type=space_type), space_type=space_type)
    builtin_ids = {
        panel_id
        for panel_id, cls in registry.items()
        if is_builtin_default_panel_id(panel_id, space_type=space_type)
        and getattr(cls, "bl_region_type", None) == "UI"
    }
    allowed_ids = allowed_for_order.union(builtin_ids)

    preferred_by_drawer = {}
    for panel_id in explicit_workflow_ids:
        drawer_id = panel_drawer_root_id(panel_id, space_type=space_type)
        if drawer_id not in visible_set:
            continue
        member_id = ""
        if panel_id in allowed_for_order and panel_id in registry:
            member_id = panel_id
        elif drawer_id in allowed_for_order and drawer_id in registry:
            member_id = drawer_id
        if member_id:
            preferred_by_drawer.setdefault(drawer_id, []).append(member_id)

    lookup = get_panel_registry_lookup(state)
    ordered_drawer_member_ids = []
    for drawer_id in visible_ids:
        preferred_members = preferred_by_drawer.get(drawer_id, [])
        drawer_records = lookup["records_by_drawer"].get(drawer_id, [])
        members = [
            record.panel_id
            for record in drawer_records
            if record.panel_id in allowed_for_order and record.panel_id in registry
        ]
        if not members and drawer_id in allowed_for_order and drawer_id in registry:
            members = [drawer_id]
        members = unique_panel_ids(preferred_members + members)
        if drawer_id in registry and drawer_id not in members:
            members.insert(0, drawer_id)
        ordered_drawer_member_ids.extend(members)

    trailing_ids = [
        panel_id
        for panel_id in registry.keys()
        if panel_id in allowed_for_order and panel_id not in visible_set
    ]
    preferred_ids = [panel_id for panel_id in ordered_drawer_member_ids if panel_id in registry]
    preferred_ids.extend(panel_id for panel_id in trailing_ids if panel_id not in preferred_ids)
    ordered_ids = ordered_panel_ids_for_register(preferred_ids, space_type=space_type)

    data = {
        "visible_ids": visible_ids,
        "allowed_ids": allowed_ids,
        "ordered_ids": ordered_ids,
    }
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE[space_type] = {"signature": signature, "data": data}
    return data


def panel_filter_signature(state):
    workflow = get_active_workflow(state) if state is not None else None
    if workflow is None or workflow.is_default:
        return None
    visibility_data = workflow_visibility_data(state, workflow)
    allowed_ids = visibility_data["allowed_ids"]
    if allowed_ids is None:
        return None
    space_type = getattr(state, "space_type", "VIEW_3D")
    ordered_ids = visibility_data["ordered_ids"]
    registry_ids = tuple(sorted(get_panel_registry(space_type).keys()))
    hidden_ids = tuple(sorted(runtime_hidden_panel_ids(space_type)))
    return (
        tuple(sorted(allowed_ids)),
        tuple(ordered_ids),
        registry_ids,
        hidden_ids,
    )


def workflow_ordered_panel_ids(state, workflow):
    if workflow is None or workflow.is_default:
        return list(get_panel_registry(getattr(state, "space_type", "VIEW_3D")).keys())
    return workflow_visibility_data(state, workflow)["ordered_ids"]


def clear_panel_filter():
    restore_default_n_panel_state(disable_filters=True)


def addon_module_name():
    return __package__ or __name__


def addon_module_candidates():
    candidates = []
    for value in (addon_module_name(), __name__, __package__, "go_workflow"):
        if value and value not in candidates:
            candidates.append(value)
    try:
        for module_name in bpy.context.preferences.addons.keys():
            if module_name not in candidates and module_name.endswith("go_workflow"):
                candidates.append(module_name)
    except Exception:
        pass
    return candidates


def addon_root_dir():
    return os.path.dirname(os.path.abspath(__file__))


def addon_package_dir():
    return os.path.dirname(addon_root_dir())


def addon_uninstall_script_path():
    return os.path.join(tempfile.gettempdir(), "go_workflow_uninstall.cmd")


def write_delayed_uninstall_script():
    package_dir = addon_package_dir()
    script_path = addon_uninstall_script_path()
    blender_pid = os.getpid()
    lines = [
        "@echo off",
        "setlocal enableextensions",
        f"set TARGET={package_dir}",
        f"set BLENDER_PID={blender_pid}",
        ":waitloop",
        "tasklist /FI \"PID eq %BLENDER_PID%\" | find \"%BLENDER_PID%\" >nul",
        "if not errorlevel 1 (",
        "  timeout /t 2 /nobreak >nul",
        "  goto waitloop",
        ")",
        "timeout /t 1 /nobreak >nul",
        "if exist \"%TARGET%\" rmdir /S /Q \"%TARGET%\"",
        "endlocal",
        "del /F /Q \"%~f0\" >nul 2>nul",
    ]
    with open(script_path, "w", encoding="mbcs", errors="replace") as handle:
        handle.write("\r\n".join(lines) + "\r\n")
    return script_path


def launch_delayed_uninstall_script():
    script_path = write_delayed_uninstall_script()
    try:
        subprocess.Popen(
            ["cmd.exe", "/c", "start", "", "/min", script_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return script_path
    except Exception:
        traceback.print_exc()
        return ""


def panel_depth(panel_id, space_type=None):
    depth = 0
    seen = set()
    current_id = panel_id
    registry = get_panel_registry(space_type)
    while current_id and current_id not in seen:
        seen.add(current_id)
        cls = registry.get(current_id)
        parent_id = getattr(cls, "bl_parent_id", "") if cls else ""
        if not parent_id:
            break
        depth += 1
        current_id = parent_id
    return depth


def sorted_panel_ids_for_unregister(panel_ids, space_type=None):
    return sorted(panel_ids, key=lambda panel_id: panel_depth(panel_id, space_type=space_type), reverse=True)


def sorted_panel_ids_for_register(panel_ids, space_type=None):
    return sorted(panel_ids, key=lambda panel_id: panel_depth(panel_id, space_type=space_type))


def is_dynamic_multi_panel_class(cls):
    if cls is None:
        return False
    module_name = str(getattr(cls, "__module__", "") or "").casefold()
    class_name = str(getattr(cls, "__name__", "") or "")
    if "uvpackmaster4" in module_name:
        return True
    return bool(getattr(cls, "PARENT_M_PANEL_ID", ""))


def is_dynamic_multi_panel_id(panel_id, space_type=None):
    cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
    return is_dynamic_multi_panel_class(cls)


def _safe_unregister_panel_class(cls):
    if cls is None:
        return False
    original = getattr(cls, "unregister", None)
    try:
        if callable(original):
            setattr(cls, "unregister", lambda: None)
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False
    finally:
        if callable(original):
            try:
                setattr(cls, "unregister", original)
            except Exception:
                pass


def _safe_register_panel_class(cls):
    if cls is None:
        return False
    original = getattr(cls, "register", None)
    try:
        if callable(original):
            setattr(cls, "register", lambda: None)
        bpy.utils.register_class(cls)
        return True
    except TypeError:
        try:
            bpy.utils.register_class(cls, False)
            return True
        except Exception:
            return False
    except Exception:
        return False
    finally:
        if callable(original):
            try:
                setattr(cls, "register", original)
            except Exception:
                pass


def panel_parent_id_anywhere(panel_id, space_type=None):
    cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
    parent_id = getattr(cls, "bl_parent_id", "") if cls is not None else ""
    return parent_id if parent_id and parent_id != panel_id else ""


def ordered_panel_ids_for_register(panel_ids, space_type=None):
    wanted = set(panel_ids)
    ordered = []
    visiting = set()
    visited = set()

    def visit(panel_id):
        if panel_id in visited or panel_id in visiting:
            return
        visiting.add(panel_id)
        parent_id = panel_parent_id_anywhere(panel_id, space_type=space_type)
        if parent_id in wanted:
            visit(parent_id)
        visiting.remove(panel_id)
        visited.add(panel_id)
        ordered.append(panel_id)

    for panel_id in panel_ids:
        visit(panel_id)
    return ordered


def call_original_panel_poll(panel_id, cls, context):
    original = PANEL_POLL_ORIGINALS.get(panel_id, PANEL_POLL_MISSING)
    if original is PANEL_POLL_MISSING:
        return True
    def report_poll_error(exc):
        if isinstance(exc, TypeError) and "could not find function poll" in str(exc):
            try:
                setattr(cls, "poll", classmethod(default_panel_poll))
            except Exception:
                pass
            return
        key = (panel_id, type(exc).__name__, str(exc))
        if key not in PANEL_POLL_ERROR_KEYS:
            PANEL_POLL_ERROR_KEYS.add(key)
            traceback.print_exc()

    try:
        if isinstance(original, classmethod):
            return bool(original.__func__(cls, context))
        if isinstance(original, staticmethod):
            return bool(original.__func__(context))
        return bool(original(cls, context))
    except TypeError:
        if "could not find function poll" in traceback.format_exc():
            try:
                setattr(cls, "poll", classmethod(default_panel_poll))
            except Exception:
                pass
            return True
        try:
            bound = getattr(original, "__get__", None)
            if callable(bound):
                candidate = bound(cls, type(cls))
                if callable(candidate):
                    try:
                        return bool(candidate(context))
                    except TypeError:
                        pass
            return bool(original(context))
        except Exception as exc:
            report_poll_error(exc)
            return False
    except Exception as exc:
        report_poll_error(exc)
        return False


def bworkflow_panel_poll(cls, context):
    panel_id = getattr(cls, "_bworkflow_poll_panel_id", "") or getattr(cls, "bl_idname", "") or getattr(cls, "__name__", "")
    allowed_ids = ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE.get(getattr(cls, "bl_space_type", "VIEW_3D"))
    if allowed_ids is not None and panel_id not in allowed_ids:
        return False
    return call_original_panel_poll(panel_id, cls, context)


def make_panel_poll_wrapper(_panel_id):
    return classmethod(bworkflow_panel_poll)


def default_panel_poll(cls, _context):
    return True


def _camera_rig_panel_draw_error_is_safe(exc):
    if not isinstance(exc, AttributeError):
        return False
    text = str(exc or "")
    return (
        "'NoneType' object has no attribute 'pose'" in text
        or "'NoneType' object has no attribute 'data'" in text
        or "'NoneType' object has no attribute 'type'" in text
    )


def _safe_panel_draw_wrapper(panel_id, method_name, original):
    def wrapped(self, context):
        if panel_id.startswith("ADD_CAMERA_RIGS_"):
            active_object = getattr(context, "active_object", None)
            if active_object is None:
                view_layer = getattr(context, "view_layer", None)
                layer_objects = getattr(view_layer, "objects", None)
                active_object = getattr(layer_objects, "active", None)
            if active_object is None:
                return None
        try:
            return original(self, context)
        except Exception as exc:
            key = (panel_id, method_name, type(exc).__name__, str(exc))
            if key not in PANEL_DRAW_ERROR_KEYS:
                PANEL_DRAW_ERROR_KEYS.add(key)
                print(
                    f"[GoWorkflow] Isolated panel draw error in {panel_id}.{method_name}: {exc}",
                    file=sys.stderr,
                )
            return None
    wrapped.__name__ = getattr(original, "__name__", method_name)
    wrapped.__doc__ = getattr(original, "__doc__", None)
    return wrapped


def _panel_callback_from_class_dict(cls, name):
    value = cls.__dict__.get(name)
    if isinstance(value, (staticmethod, classmethod)):
        return value.__func__
    return value


def repair_problematic_panel_draw_callbacks(space_type=None):
    repaired = 0
    target_space = str(space_type or "").strip()
    for cls in iter_panel_subclasses(bpy.types.Panel):
        panel_id = str(getattr(cls, "bl_idname", "") or getattr(cls, "__name__", "") or "")
        if target_space and str(getattr(cls, "bl_space_type", "") or "") != target_space:
            continue
        module_name = str(getattr(cls, "__module__", "") or "")
        if not module_name or module_name == __name__ or module_name.startswith(f"{__name__}."):
            continue
        original_draw = _panel_callback_from_class_dict(cls, "draw")
        if callable(original_draw) and panel_id not in PANEL_DRAW_ORIGINALS:
            PANEL_DRAW_ORIGINALS[panel_id] = original_draw
            setattr(cls, "draw", _safe_panel_draw_wrapper(panel_id, "draw", original_draw))
            repaired += 1
        original_draw_header = _panel_callback_from_class_dict(cls, "draw_header")
        if callable(original_draw_header) and panel_id not in PANEL_DRAW_HEADER_ORIGINALS:
            PANEL_DRAW_HEADER_ORIGINALS[panel_id] = original_draw_header
            setattr(cls, "draw_header", _safe_panel_draw_wrapper(panel_id, "draw_header", original_draw_header))
            repaired += 1
    return repaired


def restore_problematic_panel_draw_callbacks(panel_ids=None, space_type=None):
    target_ids = set(panel_ids or set(PANEL_DRAW_ORIGINALS.keys()) | set(PANEL_DRAW_HEADER_ORIGINALS.keys()))
    for panel_id in list(target_ids):
        cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
        if cls is None:
            continue
        original_draw = PANEL_DRAW_ORIGINALS.pop(panel_id, None)
        if original_draw is not None:
            setattr(cls, "draw", original_draw)
        original_draw_header = PANEL_DRAW_HEADER_ORIGINALS.pop(panel_id, None)
        if original_draw_header is not None:
            setattr(cls, "draw_header", original_draw_header)
        for key in list(PANEL_DRAW_ERROR_KEYS):
            if key[0] == panel_id:
                PANEL_DRAW_ERROR_KEYS.discard(key)


def repair_missing_panel_poll_callbacks(space_type=None):
    repaired = 0
    target_space = str(space_type or "").strip()
    for cls in iter_panel_subclasses(bpy.types.Panel):
        panel_id = str(getattr(cls, "bl_idname", "") or getattr(cls, "__name__", "") or "")
        if not panel_id or panel_id.startswith("BWFLOW_"):
            continue
        if target_space and str(getattr(cls, "bl_space_type", "") or "") != target_space:
            continue
        module_name = str(getattr(cls, "__module__", "") or "")
        if module_name == __name__ or module_name.startswith("bl_ui"):
            continue
        cls_dict = getattr(cls, "__dict__", {}) or {}
        force_repair = panel_id in BROKEN_PANEL_POLL_IDS
        if not force_repair and panel_id.startswith("SPIO_"):
            try:
                poll_attr = cls_dict.get("poll")
                if poll_attr is not None:
                    poll_fn = getattr(poll_attr, "__func__", poll_attr)
                    if not callable(poll_fn):
                        force_repair = True
            except Exception:
                force_repair = True
        if force_repair:
            try:
                setattr(cls, "poll", classmethod(default_panel_poll))
                PANEL_POLL_CALLERS.pop(panel_id, None)
                PANEL_POLL_ORIGINALS.pop(panel_id, None)
                PANEL_POLL_TARGETS.pop(panel_id, None)
                try:
                    delattr(cls, "_bworkflow_poll_panel_id")
                except Exception:
                    pass
                repaired += 1
            except Exception:
                pass
            continue
        if "poll" in cls_dict and callable(getattr(cls, "poll", None)):
            continue
        try:
            setattr(cls, "poll", classmethod(default_panel_poll))
            repaired += 1
        except Exception:
            pass
    return repaired


def quarantine_broken_panel_polls(space_type=None):
    repaired = 0
    target_space = str(space_type or "").strip()
    for panel_id in BROKEN_PANEL_POLL_IDS:
        cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
        if cls is None:
            continue
        if target_space and str(getattr(cls, "bl_space_type", "") or "") != target_space:
            continue
        try:
            setattr(cls, "poll", classmethod(default_panel_poll))
            try:
                delattr(cls, "_bworkflow_poll_panel_id")
            except Exception:
                pass
            PANEL_POLL_CALLERS.pop(panel_id, None)
            PANEL_POLL_ORIGINALS.pop(panel_id, None)
            PANEL_POLL_TARGETS.pop(panel_id, None)
            repaired += 1
        except Exception:
            pass
    return repaired


def install_panel_poll_overrides():
    uninstall_panel_poll_overrides()
    repair_missing_panel_poll_callbacks()
    repair_problematic_panel_draw_callbacks()


def ensure_panel_poll_overrides(space_type=None):
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    installed = 0
    for target_space in target_spaces:
        registry = get_panel_registry(target_space)
        for panel_id, cls in list(registry.items()):
            if not panel_id or panel_id.startswith("BWFLOW_"):
                continue
            if panel_id in BROKEN_PANEL_POLL_IDS:
                try:
                    setattr(cls, "poll", classmethod(default_panel_poll))
                    delattr(cls, "_bworkflow_poll_panel_id")
                except Exception:
                    pass
                PANEL_POLL_CALLERS.pop(panel_id, None)
                PANEL_POLL_ORIGINALS.pop(panel_id, None)
                PANEL_POLL_TARGETS.pop(panel_id, None)
                continue
            if panel_id in PANEL_POLL_TARGETS:
                continue
            original = cls.__dict__.get("poll", PANEL_POLL_MISSING)
            PANEL_POLL_ORIGINALS[panel_id] = original
            PANEL_POLL_TARGETS[panel_id] = cls
            PANEL_POLL_CALLERS[panel_id] = True
            try:
                setattr(cls, "_bworkflow_poll_panel_id", panel_id)
                setattr(cls, "poll", make_panel_poll_wrapper(panel_id))
                installed += 1
            except Exception:
                PANEL_POLL_CALLERS.pop(panel_id, None)
                PANEL_POLL_ORIGINALS.pop(panel_id, None)
                PANEL_POLL_TARGETS.pop(panel_id, None)
    return installed


def uninstall_panel_poll_overrides(panel_ids=None):
    target_ids = list(PANEL_POLL_CALLERS.keys()) if panel_ids is None else list(panel_ids)
    for panel_id in target_ids:
        cls = PANEL_POLL_TARGETS.get(panel_id)
        if cls is None or panel_id not in PANEL_POLL_CALLERS:
            continue
        if panel_id in BROKEN_PANEL_POLL_IDS:
            try:
                setattr(cls, "poll", classmethod(default_panel_poll))
                delattr(cls, "_bworkflow_poll_panel_id")
            except Exception:
                pass
            PANEL_POLL_CALLERS.pop(panel_id, None)
            PANEL_POLL_ORIGINALS.pop(panel_id, None)
            PANEL_POLL_TARGETS.pop(panel_id, None)
            continue
        original = PANEL_POLL_ORIGINALS.get(panel_id, PANEL_POLL_MISSING)
        if original is PANEL_POLL_MISSING:
            setattr(cls, "poll", classmethod(default_panel_poll))
        else:
            setattr(cls, "poll", original)
        try:
            delattr(cls, "_bworkflow_poll_panel_id")
        except Exception:
            pass
        PANEL_POLL_CALLERS.pop(panel_id, None)
        PANEL_POLL_ORIGINALS.pop(panel_id, None)
        PANEL_POLL_TARGETS.pop(panel_id, None)
        for key in list(PANEL_POLL_ERROR_KEYS):
            if key[0] == panel_id:
                PANEL_POLL_ERROR_KEYS.discard(key)


def apply_panel_order_overrides(ordered_panel_ids, space_type=None):
    registries = [(space_type, get_panel_registry(space_type))] if space_type else list(iter_registries())
    for target_space, registry in registries:
        ordered_signature = tuple(
            panel_id
            for panel_id in ordered_panel_ids
            if (
                panel_id in registry
                and panel_id not in BROKEN_PANEL_POLL_IDS
                and not is_dynamic_multi_panel_class(registry.get(panel_id))
            )
        )
        previous_signature = PANEL_ORDER_SIGNATURE_BY_SPACE.get(target_space)
        ordered_map = {panel_id: index for index, panel_id in enumerate(ordered_signature)}
        if not ordered_signature:
            continue
        for panel_id in ordered_signature:
            cls = registry.get(panel_id)
            if cls is None:
                continue
            if panel_id not in PANEL_BL_ORDER_ORIGINALS:
                PANEL_BL_ORDER_ORIGINALS[panel_id] = cls.__dict__.get("bl_order", PANEL_BL_ORDER_MISSING)
            cls.bl_order = ordered_map[panel_id] + 100
        if previous_signature != ordered_signature:
            reorder_registered_panels(ordered_signature, space_type=target_space)
        PANEL_ORDER_SIGNATURE_BY_SPACE[target_space] = ordered_signature
    enforce_go_workflow_panel_order()


def enforce_go_workflow_panel_order():
    pinned = (
        BWFLOW_PT_workflow,
        BWFLOW_PT_workflow_image_editor,
        BWFLOW_PT_workflow_node_editor,
    )
    for cls in pinned:
        try:
            cls.bl_order = -1000
        except Exception:
            pass


def clear_panel_order_overrides(panel_ids=None, space_type=None):
    if space_type is None:
        PANEL_ORDER_SIGNATURE_BY_SPACE.clear()
        PANEL_FILTER_SIGNATURE_BY_SPACE.clear()
        PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.clear()
    else:
        PANEL_ORDER_SIGNATURE_BY_SPACE.pop(space_type, None)
        PANEL_FILTER_SIGNATURE_BY_SPACE.pop(space_type, None)
        PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    target_ids = list(PANEL_BL_ORDER_ORIGINALS.keys()) if panel_ids is None else list(panel_ids)
    if space_type is not None and panel_ids is None:
        target_ids = [
            panel_id
            for panel_id in target_ids
            if panel_id in get_panel_registry(space_type) or panel_id in get_panel_cache(space_type)
        ]
    for panel_id in target_ids:
        original = PANEL_BL_ORDER_ORIGINALS.get(panel_id, PANEL_BL_ORDER_MISSING)
        cls = resolve_panel_class(panel_id, space_type=space_type)
        if cls is None:
            continue
        if original is PANEL_BL_ORDER_MISSING:
            try:
                delattr(cls, "bl_order")
            except Exception:
                pass
        else:
            cls.bl_order = original
        PANEL_BL_ORDER_ORIGINALS.pop(panel_id, None)


def restore_panel_registry_order(panel_ids=None, space_type=None):
    if panel_ids is None:
        panel_ids = list(PANEL_BL_ORDER_ORIGINALS.keys())
    if not panel_ids:
        return
    registries = [(space_type, get_panel_registry(space_type))] if space_type else list(iter_registries())
    for target_space, registry in registries:
        if not registry:
            continue
        ordered_ids = [panel_id for panel_id in panel_ids if panel_id in registry]
        if not ordered_ids:
            continue
        for panel_id in ordered_ids:
            cls = registry.get(panel_id)
            if cls is None:
                continue
            original = PANEL_BL_ORDER_ORIGINALS.get(panel_id, PANEL_BL_ORDER_MISSING)
            if original is PANEL_BL_ORDER_MISSING:
                try:
                    delattr(cls, "bl_order")
                except Exception:
                    pass
            else:
                cls.bl_order = original


def poll_override_panel_ids_for_space(space_type):
    panel_ids = []
    for panel_id, cls in list(PANEL_POLL_TARGETS.items()):
        if getattr(cls, "bl_space_type", "VIEW_3D") == space_type:
            panel_ids.append(panel_id)
    return panel_ids


def has_runtime_unregistered_panels(space_type=None):
    if not UNREGISTERED_PANEL_IDS:
        return False
    if space_type is None:
        return True
    for panel_id in UNREGISTERED_PANEL_IDS:
        cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
        if cls is not None and getattr(cls, "bl_space_type", None) == space_type:
            return True
    return False


def restore_space_default_n_panel_state(scene=None, space_type="VIEW_3D", disable_filters=True, sync_registry_after_restore=True):
    quarantine_broken_panel_polls(space_type=space_type)
    if disable_filters:
        ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE.pop(space_type, None)
    PANEL_ORDER_SIGNATURE_BY_SPACE.pop(space_type, None)
    PANEL_FILTER_SIGNATURE_BY_SPACE.pop(space_type, None)
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
    try:
        restore_panel_registry_order(space_type=space_type)
    except Exception:
        traceback.print_exc()
    try:
        uninstall_panel_poll_overrides(poll_override_panel_ids_for_space(space_type))
    except Exception:
        traceback.print_exc()
    quarantine_broken_panel_polls(space_type=space_type)
    try:
        restore_unregistered_panels(space_type=space_type)
    except Exception:
        traceback.print_exc()
    try:
        clear_panel_order_overrides(space_type=space_type)
    except Exception:
        traceback.print_exc()
    PANEL_GROUP_INDEX_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_DRAWER_ROOT_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(space_type, None)
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(space_type, None)
    target_scene = scene or safe_context_scene()
    if sync_registry_after_restore and target_scene is not None:
        try:
            PANEL_CLASS_CACHE_BY_SPACE[space_type] = discover_sidebar_panels(space_type)
            sync_registry(target_scene, space_type=space_type)
        except Exception:
            traceback.print_exc()
    tag_redraw_all()


def switch_state_to_default_workflow(state):
    if state is None or not getattr(state, "workflows", None):
        return False
    ensure_one_default_workflow(state)
    for index, workflow in enumerate(state.workflows):
        if workflow.is_default:
            if state.active_workflow_index != index:
                state.active_workflow_index = index
                return True
            return False
    return False


def switch_all_states_to_default_workflow(scene=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False
    changed = False
    for space_type in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=space_type)
        if switch_state_to_default_workflow(state):
            changed = True
    return changed


def restore_default_n_panel_state(scene=None, disable_filters=True, switch_workflow=True, sync_registry_after_restore=True):
    quarantine_broken_panel_polls()
    if switch_workflow:
        switch_all_states_to_default_workflow(scene=scene)
    if disable_filters:
        ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE.clear()
    PANEL_GROUP_INDEX_CACHE_BY_SPACE.clear()
    PANEL_DRAWER_ROOT_CACHE_BY_SPACE.clear()
    PANEL_ORDER_SIGNATURE_BY_SPACE.clear()
    PANEL_FILTER_SIGNATURE_BY_SPACE.clear()
    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.clear()
    PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.clear()
    PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.clear()
    WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE.clear()
    WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE.clear()
    RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.clear()
    IMPORTED_WORKFLOW_MISSING_MATCH_CACHE.clear()
    SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.clear()
    SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.clear()
    WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE.clear()
    PANEL_GROUP_FILTER_CACHE_BY_SPACE.clear()
    try:
        restore_panel_registry_order()
    except Exception:
        traceback.print_exc()
    for space_type in iter_supported_space_types():
        try:
            restore_space_default_n_panel_state(
                scene=scene,
                space_type=space_type,
                disable_filters=disable_filters,
                sync_registry_after_restore=sync_registry_after_restore,
            )
        except Exception:
            traceback.print_exc()
    tag_redraw_all()


def restore_unregistered_panels(panel_ids=None, space_type=None):
    if panel_ids is None:
        ids_to_restore = set(UNREGISTERED_PANEL_IDS)
    else:
        ids_to_restore = set(panel_ids)
    unresolved_ids = set()
    for panel_id in list(ids_to_restore):
        if resolve_panel_class_anywhere(panel_id, space_type=space_type) is None:
            unresolved_ids.add(panel_id)
    ids_to_restore.difference_update(unresolved_ids)
    UNREGISTERED_PANEL_IDS.difference_update(unresolved_ids)

    ids_to_restore.difference_update(BROKEN_PANEL_POLL_IDS)
    pending_ids = ordered_panel_ids_for_register(ids_to_restore, space_type=space_type)
    for _attempt in range(max(1, len(pending_ids))):
        if not pending_ids:
            break
        still_pending = []
        made_progress = False
        for panel_id in pending_ids:
            cls = resolve_panel_class_anywhere(panel_id, space_type=space_type)
            if cls is None:
                UNREGISTERED_PANEL_IDS.discard(panel_id)
                made_progress = True
                continue
            try:
                if _safe_register_panel_class(cls):
                    UNREGISTERED_PANEL_IDS.discard(panel_id)
                    target_space = getattr(cls, "bl_space_type", space_type or "VIEW_3D")
                    PANEL_ORDER_SIGNATURE_BY_SPACE.pop(target_space, None)
                    PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(target_space, None)
                    RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.pop(target_space, None)
                    made_progress = True
                else:
                    still_pending.append(panel_id)
            except ValueError:
                UNREGISTERED_PANEL_IDS.discard(panel_id)
                made_progress = True
            except RuntimeError:
                still_pending.append(panel_id)
            except Exception:
                still_pending.append(panel_id)
        if still_pending == pending_ids and not made_progress:
            break
        pending_ids = still_pending
    enforce_go_workflow_panel_order()


def unregister_panels(panel_ids, space_type=None):
    for panel_id in sorted_panel_ids_for_unregister(panel_ids, space_type=space_type):
        if panel_id in UNREGISTERED_PANEL_IDS:
            continue
        cls = resolve_panel_class(panel_id, space_type=space_type)
        if cls is None:
            continue
        try:
            if _safe_unregister_panel_class(cls):
                UNREGISTERED_PANEL_IDS.add(panel_id)
                target_space = getattr(cls, "bl_space_type", space_type or "VIEW_3D")
                PANEL_ORDER_SIGNATURE_BY_SPACE.pop(target_space, None)
                PANEL_FILTER_SIGNATURE_BY_SPACE.pop(target_space, None)
                PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(target_space, None)
                RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.pop(target_space, None)
        except Exception:
            pass


def reorder_registered_panels(panel_ids, space_type=None):
    ids_to_reorder = [
        panel_id
        for panel_id in ordered_panel_ids_for_register(panel_ids, space_type=space_type)
        if (
            panel_id not in UNREGISTERED_PANEL_IDS
            and panel_id not in BROKEN_PANEL_POLL_IDS
            and not is_dynamic_multi_panel_id(panel_id, space_type=space_type)
        )
    ]
    for panel_id in reversed(ids_to_reorder):
        cls = resolve_panel_class(panel_id, space_type=space_type)
        if cls is None:
            continue
        try:
            _safe_unregister_panel_class(cls)
        except Exception:
            pass

    for panel_id in ids_to_reorder:
        cls = resolve_panel_class(panel_id, space_type=space_type)
        if cls is None:
            continue
        try:
            _safe_register_panel_class(cls)
        except Exception:
            pass
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    for target_space in target_spaces:
        registry = dict(get_panel_registry(target_space))
        reordered_registry = {}
        for panel_id in ids_to_reorder:
            cls = registry.get(panel_id)
            if cls is not None:
                reordered_registry[panel_id] = cls
        for panel_id, cls in registry.items():
            if panel_id not in reordered_registry:
                reordered_registry[panel_id] = cls
        PANEL_CLASS_REGISTRY_BY_SPACE[target_space] = reordered_registry
    enforce_go_workflow_panel_order()


def apply_panel_visibility_overrides(scene=None, space_type=None, restore_first=True, install_poll=True, repair_callbacks=True):
    if restore_first:
        restore_unregistered_panels(space_type=space_type)

    changed = False
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    for target_space in target_spaces:
        state = get_state(scene=scene, space_type=target_space)
        if state is None:
            continue
        if not workflow_runtime_initialized(state):
            ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE.pop(target_space, None)
            continue
        if repair_callbacks:
            repair_missing_panel_poll_callbacks(space_type=target_space)
            repair_problematic_panel_draw_callbacks(space_type=target_space)
        if install_poll:
            ensure_panel_poll_overrides(space_type=target_space)
        workflow = get_active_workflow(state)
        visibility_data = workflow_visibility_data(state, workflow)
        allowed_ids = visibility_data["allowed_ids"]
        ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE[target_space] = allowed_ids

        registry_ids = set(get_panel_registry(target_space).keys())
        if allowed_ids is None:
            restore_space_default_n_panel_state(scene=scene, space_type=target_space, disable_filters=True)
            changed = True
            continue

        allowed_ids = set(allowed_ids)
        hidden_ids = {
            panel_id
            for panel_id in registry_ids
            if panel_id not in allowed_ids and not panel_id.startswith("BWFLOW_")
        }
        current_signature = (
            len(allowed_ids),
            hash(frozenset(allowed_ids)),
            len(visibility_data["ordered_ids"]),
            hash(tuple(visibility_data["ordered_ids"])),
            panel_registry_lookup_signature(state),
            len(runtime_hidden_panel_ids(target_space)),
        )
        if PANEL_FILTER_SIGNATURE_BY_SPACE.get(target_space) == current_signature:
            continue

        hidden_runtime_ids = runtime_hidden_panel_ids(target_space)
        restore_ids = allowed_ids.intersection(hidden_runtime_ids)
        if restore_ids:
            restore_unregistered_panels(restore_ids, space_type=target_space)
            changed = True
        if install_poll:
            ensure_panel_poll_overrides(space_type=target_space)
        hide_ids = hidden_ids.difference(hidden_runtime_ids)
        if hide_ids:
            unregister_panels(hide_ids, space_type=target_space)
            changed = True

        ordered_ids = visibility_data["ordered_ids"]
        if not getattr(state, "panel_order_pending_apply", False):
            previous_order_signature = PANEL_ORDER_SIGNATURE_BY_SPACE.get(target_space)
            apply_panel_order_overrides(ordered_ids, space_type=target_space)
            if previous_order_signature != PANEL_ORDER_SIGNATURE_BY_SPACE.get(target_space):
                changed = True
        PANEL_FILTER_SIGNATURE_BY_SPACE[target_space] = current_signature
    return changed


def ensure_one_default_workflow(state):
    if state is None or not state.workflows:
        return

    default_indexes = [index for index, workflow in enumerate(state.workflows) if workflow.is_default]
    if not default_indexes:
        state.workflows[0].is_default = True
        default_indexes = [0]

    keep_index = default_indexes[0]
    for index, workflow in enumerate(state.workflows):
        workflow.is_default = index == keep_index
    normalize_workflow_texts(state)


def sync_registry(scene, space_type="VIEW_3D"):
    state = get_state(scene=scene, space_type=space_type)
    if state is None:
        return
    PANEL_GROUP_ICON_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_GROUP_INDEX_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_DRAWER_ROOT_CACHE_BY_SPACE.pop(space_type, None)
    PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.pop(space_type, None)

    discovered = dict(get_panel_registry(space_type))
    existing = {item.panel_id: item for item in state.panel_registry}

    for item in state.panel_registry:
        item.discovered = False

    for panel_id, cls in discovered.items():
        record = existing.get(panel_id)
        if record is None:
            record = state.panel_registry.add()
            record.panel_id = panel_id
        record.title = clean_panel_title(getattr(cls, "bl_label", panel_id), panel_id)
        record.category = panel_display_category(panel_id, cls, space_type=space_type)
        record.source_module = getattr(cls, "__module__", "")
        record.addon_version = max_version_text(getattr(record, "addon_version", ""), addon_version_from_module_name(record.source_module))
        record.discovered = True


def canonicalize_workflow_drawer_ids(state, space_type=None):
    """Collapse generated multi-panel IDs into their host drawer."""
    if state is None:
        return False
    target_space = space_type or getattr(state, "space_type", "VIEW_3D")
    changed = False
    for workflow in getattr(state, "workflows", []):
        old_ids = [getattr(item, "panel_id", "") for item in getattr(workflow, "panels", [])]
        if not old_ids:
            continue
        new_ids = unique_panel_ids(
            panel_drawer_root_id(panel_id, space_type=target_space)
            if panel_id and panel_id != "BWFLOW_PT_workflow"
            else panel_id
            for panel_id in old_ids
        )
        if new_ids == old_ids:
            continue
        active_index = clamp_index(getattr(workflow, "active_panel_index", 0), len(old_ids))
        active_id = old_ids[active_index] if old_ids else ""
        active_id = (
            panel_drawer_root_id(active_id, space_type=target_space)
            if active_id and active_id != "BWFLOW_PT_workflow"
            else active_id
        )
        replace_workflow_panels(workflow, new_ids)
        set_active_workflow_panel_by_id(workflow, active_id)
        changed = True
    return changed


def rebuild_panel_cache(scene=None, space_type=None, restore_first=True, install_poll=True):
    target_scene = scene or safe_context_scene()
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    for target_space in target_spaces:
        state = get_state(scene=target_scene, space_type=target_space)
        runtime_enabled = workflow_runtime_initialized(state)
        if runtime_enabled:
            repair_missing_panel_poll_callbacks(space_type=target_space)
            repair_problematic_panel_draw_callbacks(space_type=target_space)
        if restore_first and has_runtime_unregistered_panels(space_type=target_space):
            restore_unregistered_panels(space_type=target_space)
        PANEL_GROUP_INDEX_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_GROUP_ICON_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_DRAWER_ROOT_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{target_space}:library", None)
        PANEL_GROUP_FILTER_CACHE_BY_SPACE.pop(f"{target_space}:selected", None)
        clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, target_space)
        clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, target_space)
        clear_space_prefixed_cache(IMPORTED_WORKFLOW_MISSING_MATCH_CACHE, target_space)
        RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.pop(target_space, None)
        SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.pop(target_space, None)
        SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.pop(target_space, None)
        clear_space_prefixed_cache(WORKFLOW_FAMILY_ORDER_GROUPS_CACHE_BY_SPACE, target_space)
        PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(target_space, None)
        PANEL_ORDER_SIGNATURE_BY_SPACE.pop(target_space, None)
        PANEL_FILTER_SIGNATURE_BY_SPACE.pop(target_space, None)
        PANEL_CLASS_CACHE_BY_SPACE[target_space] = discover_sidebar_panels(target_space)
        if target_scene is not None:
            sync_registry(target_scene, space_type=target_space)
            if runtime_enabled:
                canonicalize_workflow_drawer_ids(
                    get_state(scene=target_scene, space_type=target_space),
                    space_type=target_space,
                )
    if install_poll:
        for target_space in target_spaces:
            state = get_state(scene=target_scene, space_type=target_space)
            if workflow_runtime_initialized(state):
                ensure_panel_poll_overrides(space_type=target_space)


def rebuild_runtime_panels(scene=None, space_type=None, rebuild_cache=True):
    target_scene = scene or safe_context_scene()
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    if not any(
        workflow_runtime_initialized(get_state(scene=target_scene, space_type=target_space))
        for target_space in target_spaces
    ):
        return False
    changed = False
    if rebuild_cache and has_runtime_unregistered_panels(space_type=space_type):
        restore_unregistered_panels(space_type=space_type)
        changed = True
    if rebuild_cache:
        rebuild_panel_cache(scene=scene, space_type=space_type, restore_first=False, install_poll=True)
        changed = True
    changed = force_reload_script_panels(scene=scene, space_type=space_type, restore_first=False) or changed
    changed = apply_panel_visibility_overrides(
        scene=scene,
        space_type=space_type,
        restore_first=False,
        install_poll=not rebuild_cache,
    ) or changed
    if changed:
        tag_redraw_all(space_type=space_type)
    return changed


def refresh_runtime_overrides(scene=None, space_type=None, restore_first=False, include_script_panels=True):
    rebuild_runtime_panels(scene=scene, space_type=space_type, rebuild_cache=False)


def refresh_runtime(scene=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return

    for target_space in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=target_space)
        if state is None:
            continue
        if not workflow_runtime_initialized(state):
            continue

        if state.settings.auto_sync_registry:
            rebuild_panel_cache(scene=target_scene, space_type=target_space)
        else:
            PANEL_CLASS_CACHE_BY_SPACE[target_space] = discover_sidebar_panels(target_space)
    initialize_all_module_runtime_fields(scene=target_scene)
    rebuild_runtime_panels(scene=target_scene, rebuild_cache=False)


def schedule_deferred_runtime_refresh(scene=None, intervals=None, space_type=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return

    scene_name = getattr(target_scene, "name", "")
    if not scene_name:
        return

    refresh_key = f"{scene_name}:{space_type or '*'}"
    DEFERRED_REFRESH_TOKENS[refresh_key] = time.time()
    if refresh_key in DEFERRED_REFRESH_PENDING_KEYS:
        return

    DEFERRED_REFRESH_PENDING_KEYS.add(refresh_key)
    delays = intervals or DEFERRED_REFRESH_INTERVALS
    delay = min(max(0.01, float(item)) for item in delays)

    def _refresh_once(scene_name=scene_name, target_space_type=space_type, pending_key=refresh_key):
        DEFERRED_REFRESH_PENDING_KEYS.discard(pending_key)
        scene_ref = bpy.data.scenes.get(scene_name)
        if scene_ref is None:
            DEFERRED_REFRESH_TOKENS.pop(pending_key, None)
            return None
        try:
            rebuild_runtime_panels(scene=scene_ref, space_type=target_space_type)
        except Exception:
            traceback.print_exc()
        return None

    try:
        _register_one_shot_timer(_refresh_once, first_interval=delay)
    except Exception:
        DEFERRED_REFRESH_PENDING_KEYS.discard(refresh_key)
        traceback.print_exc()


def schedule_deferred_workflow_switch_refresh(scene=None, space_type="VIEW_3D", delay=0.05):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False
    scene_name = getattr(target_scene, "name", "")
    target_space = str(space_type or "VIEW_3D")
    if not scene_name:
        return False
    refresh_key = f"{scene_name}:{target_space}"
    if refresh_key in DEFERRED_WORKFLOW_SWITCH_PENDING_KEYS:
        return True
    DEFERRED_WORKFLOW_SWITCH_PENDING_KEYS.add(refresh_key)

    def _refresh_once(scene_name=scene_name, target_space_type=target_space, pending_key=refresh_key):
        DEFERRED_WORKFLOW_SWITCH_PENDING_KEYS.discard(pending_key)
        scene_ref = bpy.data.scenes.get(scene_name)
        if scene_ref is None:
            return None
        try:
            state = get_state(scene=scene_ref, space_type=target_space_type)
            if not workflow_runtime_initialized(state):
                return None
            workflow = get_active_workflow(state)
            if workflow is not None and workflow.is_default:
                restore_space_default_n_panel_state(
                    scene=scene_ref,
                    space_type=target_space_type,
                    disable_filters=True,
                    sync_registry_after_restore=False,
                )
            else:
                rebuild_runtime_panels(scene=scene_ref, space_type=target_space_type)
        except Exception:
            traceback.print_exc()
        return None

    try:
        _register_one_shot_timer(_refresh_once, first_interval=max(0.01, float(delay)))
        return True
    except Exception:
        DEFERRED_WORKFLOW_SWITCH_PENDING_KEYS.discard(refresh_key)
        traceback.print_exc()
        return False


def ensure_minimum_setup(scene, restore_global=True, save_state=True):
    created = False
    library_changed = False
    builtin_module_changed = False
    restored_from_global = try_restore_global_workflow_state(scene) if restore_global else False
    for space_type in SUPPORTED_SPACE_TYPES:
        state = get_state(scene=scene, space_type=space_type)
        if state is None:
            continue
        state.space_type = space_type
        library_changed = ensure_builtin_script_library(state) or library_changed
        builtin_module_changed = bool(refresh_builtin_workflow_modules(state)) or builtin_module_changed
        if state.workflows:
            ensure_one_default_workflow(state)
            ensure_go_workflow_panel_entry(state)
            continue

        workflow = state.workflows.add()
        workflow.name = DEFAULT_WORKFLOW_NAME
        workflow.is_default = True
        workflow.description = DEFAULT_WORKFLOW_DESCRIPTION
        state.active_workflow_index = 0
        ensure_go_workflow_panel_entry(state)
        created = True
    if save_state and (created or library_changed or builtin_module_changed):
        save_global_workflow_state(scene)
    return created or restored_from_global or library_changed or builtin_module_changed


def clear_collection(collection):
    while len(collection):
        collection.remove(len(collection) - 1)


def clear_scene_go_workflow_runtime(scene):
    if scene is None:
        return 0
    removed = 0
    for key in list(scene.keys()):
        if not isinstance(key, str) or not key.startswith("_go_workflow_"):
            continue
        try:
            del scene[key]
            removed += 1
        except Exception:
            pass
    return removed


def reset_space_state(state):
    if state is None:
        return
    clear_collection(state.workflows)
    clear_collection(state.panel_registry)
    clear_collection(state.script_library)
    state.active_workflow_index = 0
    state.panel_registry_index = 0
    state.script_library_index = 0
    state.panel_library_last_click_index = -1
    state.panel_library_last_click_time = 0.0
    state.panel_library_last_click_target = ""
    state.panel_group_expanded_keys = ""
    state.selected_group_expanded_keys = ""
    state.module_editor_text = ""
    if state.settings is not None:
        state.settings.runtime_initialized = False
        state.settings.auto_sync_registry = True
        state.settings.show_missing_summary = True
        state.settings.runtime_preview_lines = 3
        state.settings.show_settings = False
        state.settings.ui_tab = "WORKFLOWS"


def unique_script_library_name(state, base_name, exclude_index=None):
    base = normalize_workflow_name(base_name, "脚本模板")
    existing = set()
    for index, item in enumerate(getattr(state, "script_library", [])):
        if exclude_index is not None and index == exclude_index:
            continue
        name = (getattr(item, "name", "") or "").strip()
        if name:
            existing.add(name)
    if base not in existing:
        return base
    suffix = 2
    while True:
        candidate = f"{base} ({suffix})"
        if candidate not in existing:
            return candidate
        suffix += 1


def script_library_item_snapshot(item):
    if item is None:
        return None
    return {
        "name": getattr(item, "name", ""),
        "description": getattr(item, "description", ""),
        "tags": getattr(item, "tags", ""),
        "use_custom_panel": bool(getattr(item, "use_custom_panel", False)),
        "panel_title": getattr(item, "panel_title", ""),
        "panel_description": getattr(item, "panel_description", ""),
        "script_path": getattr(item, "script_path", ""),
        "text_block_name": getattr(item, "text_block_name", ""),
        "script_source": getattr(item, "script_source", ""),
        "config_payload": getattr(item, "config_payload", ""),
        "ai_doc": getattr(item, "ai_doc", ""),
    }


def apply_script_library_item_to_module(module, item):
    if module is None or item is None:
        return
    module.name = normalize_workflow_name(getattr(item, "name", ""), "默认脚本模板")
    module.description = normalize_text_value(getattr(item, "description", ""), "")
    module.use_custom_panel = bool(getattr(item, "use_custom_panel", False))
    module.runtime_panel_expanded = False
    module.runtime_description_expanded = False
    module.panel_title = normalize_text_value(getattr(item, "panel_title", ""), "")
    module.panel_description = normalize_text_value(getattr(item, "panel_description", ""), "")
    # 脚本库是模板仓库，载入到模块后必须绑定到当前工作流自己的 .py，
    # 不能继续指向脚本库原文件，否则后续编辑会反向污染脚本库。
    module.script_path = ""
    # 脚本库是模板仓库，不复用旧 Text 块名，避免跨工作流互相覆盖代码。
    module.text_block_name = ""
    module.script_source = getattr(item, "script_source", "")
    module.config_payload = getattr(item, "config_payload", "")
    module.ai_doc = getattr(item, "ai_doc", "")


def script_library_storage_dir():
    return os.path.join(default_module_scripts_dir(), "script_library")


def write_script_library_source_file(item_name, source):
    folder = script_library_storage_dir()
    os.makedirs(folder, exist_ok=True)
    filename = safe_filename_component(item_name or "script", "script") + ".py"
    filepath = os.path.join(folder, filename)
    with open(filepath, "w", encoding="utf-8") as handle:
        handle.write(str(source or ""))
    return filepath


def copy_module_to_script_library_item(item, module):
    if item is None or module is None:
        return
    item.description = normalize_text_value(getattr(module, "description", ""), "")
    item.use_custom_panel = bool(getattr(module, "use_custom_panel", False))
    item.panel_title = normalize_text_value(getattr(module, "panel_title", ""), "")
    item.panel_description = normalize_text_value(getattr(module, "panel_description", ""), "")
    # 脚本库存源码快照，不保留当前模块工作文件路径，避免跨工作流回写污染。
    source = getattr(module, "script_source", "") or ""
    item.script_path = write_script_library_source_file(item.name, source)
    item.text_block_name = ""
    item.script_source = source
    item.config_payload = getattr(module, "config_payload", "")
    item.ai_doc = getattr(module, "ai_doc", "")


def normalized_script_source_for_match(source):
    return re.sub(r"\s+", "", source or "")


def normalized_script_path_for_match(path):
    raw_path = (path or "").strip()
    if not raw_path:
        return ""
    return os.path.normcase(os.path.normpath(bpy.path.abspath(raw_path)))


def workflow_module_matches_script_item(module, item):
    if module is None or item is None:
        return False
    module_source = normalized_script_source_for_match(getattr(module, "script_source", ""))
    item_source = normalized_script_source_for_match(getattr(item, "script_source", ""))
    if module_source and item_source and module_source == item_source:
        return True
    module_path = normalized_script_path_for_match(getattr(module, "script_path", ""))
    item_path = normalized_script_path_for_match(getattr(item, "script_path", ""))
    if module_path and item_path and module_path == item_path:
        return True
    module_name = normalize_workflow_name(getattr(module, "name", ""), "")
    item_name = normalize_workflow_name(getattr(item, "name", ""), "")
    return bool(module_name and item_name and module_name == item_name)


def find_workflow_module_for_script_item(workflow, item):
    if workflow is None or item is None:
        return None, -1
    for index, module in enumerate(getattr(workflow, "modules", [])):
        if workflow_module_matches_script_item(module, item):
            return module, index
    return None, -1


def workflow_module_match_index(workflow, item):
    module, module_index = find_workflow_module_for_script_item(workflow, item)
    return {
        "module": module,
        "module_index": module_index,
        "installed": module is not None,
        "enabled": bool(getattr(module, "enabled", False)) if module is not None else False,
    }


def script_library_workflow_match_index(state, item):
    workflows = list(getattr(state, "workflows", [])) if state is not None else []
    return [workflow_module_match_index(workflow, item) for workflow in workflows]


def add_script_item_to_workflow_module(workflow, item):
    if workflow is None or item is None:
        return None
    module = workflow.modules.add()
    module.name = normalize_workflow_name(getattr(item, "name", ""), "脚本模板")
    module.enabled = True
    apply_script_library_item_to_module(module, item)
    module.script_path = unique_default_module_script_path(workflow, module)
    module.ai_doc = module.ai_doc or build_module_ai_doc(workflow, module)
    workflow.active_module_index = len(workflow.modules) - 1
    return module


def global_workflow_state_path():
    try:
        base_dir = bpy.utils.user_resource("CONFIG")
    except Exception:
        base_dir = ""
    if not base_dir:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, GLOBAL_WORKFLOW_FILENAME)


def serialize_panel_registry(space_state):
    return [
        {
            "panel_id": record.panel_id,
            "title": record.title,
            "category": record.category,
            "tags": record.tags,
            "source_module": record.source_module,
            "addon_version": getattr(record, "addon_version", ""),
        }
        for record in getattr(space_state, "panel_registry", [])
    ]


def panel_registry_payload_for_panel_id(space_state, panel_id):
    if space_state is None or not panel_id:
        return None
    record = panel_drawer_record(space_state, panel_id) or find_registry_record(space_state, panel_id)
    if record is None:
        return None
    return {
        "panel_id": record.panel_id,
        "title": record.title,
        "category": record.category,
        "tags": record.tags,
        "source_module": record.source_module,
        "addon_version": getattr(record, "addon_version", ""),
    }


def collect_workflow_panel_registry_records(space_state, workflows):
    if space_state is None:
        return []
    workflows = [workflow for workflow in (workflows or []) if workflow is not None]
    if not workflows:
        return []
    lookup = {item.panel_id: item for item in getattr(space_state, "panel_registry", []) if getattr(item, "panel_id", "")}
    referenced_ids = set()
    for workflow in workflows:
        for item in getattr(workflow, "panels", []):
            panel_id = getattr(item, "panel_id", "")
            if not panel_id or panel_id == "BWFLOW_PT_workflow":
                continue
            drawer_id = panel_drawer_root_id(panel_id, space_type=getattr(space_state, "space_type", "VIEW_3D")) or panel_id
            referenced_ids.add(panel_id)
            referenced_ids.add(drawer_id)

    records = []
    seen = set()
    for workflow in workflows:
        for item in getattr(workflow, "panels", []):
            panel_id = getattr(item, "panel_id", "")
            if not panel_id or panel_id == "BWFLOW_PT_workflow":
                continue
            drawer_id = panel_drawer_root_id(panel_id, space_type=getattr(space_state, "space_type", "VIEW_3D")) or panel_id
            for candidate_id in (drawer_id, panel_id):
                if not candidate_id or candidate_id in seen:
                    continue
                record = lookup.get(candidate_id)
                if record is None:
                    continue
                seen.add(candidate_id)
                records.append(
                    {
                        "panel_id": record.panel_id,
                        "title": record.title,
                        "category": record.category,
                        "tags": record.tags,
                        "source_module": record.source_module,
                        "addon_version": getattr(record, "addon_version", ""),
                    }
                )
    return records


def serialize_script_library(space_state):
    return [
        {
            "name": item.name,
            "description": item.description,
            "tags": item.tags,
            "use_custom_panel": item.use_custom_panel,
            "panel_title": item.panel_title,
            "panel_description": item.panel_description,
            "script_path": item.script_path,
            "text_block_name": item.text_block_name,
            "script_source": export_script_source_from_item(item),
            "config_payload": getattr(item, "config_payload", ""),
            "ai_doc": item.ai_doc,
        }
        for item in getattr(space_state, "script_library", [])
    ]


def serialize_script_library_items(items):
    serialized = []
    for item in items or []:
        if item is None:
            continue
        serialized.append(
            {
                "name": getattr(item, "name", ""),
                "description": getattr(item, "description", ""),
                "tags": getattr(item, "tags", ""),
                "use_custom_panel": bool(getattr(item, "use_custom_panel", False)),
                "panel_title": getattr(item, "panel_title", ""),
                "panel_description": getattr(item, "panel_description", ""),
                "script_path": getattr(item, "script_path", ""),
                "text_block_name": getattr(item, "text_block_name", ""),
                "script_source": export_script_source_from_item(item),
                "config_payload": getattr(item, "config_payload", ""),
                "ai_doc": getattr(item, "ai_doc", ""),
            }
        )
    return serialized


def export_script_source_from_item(item):
    if item is None:
        return ""
    text_name = str(getattr(item, "text_block_name", "") or "").strip()
    if text_name:
        text_block = bpy.data.texts.get(text_name)
        if text_block is not None:
            try:
                return text_block.as_string().lstrip("\ufeff")
            except Exception:
                traceback.print_exc()
    raw_source = str(getattr(item, "script_source", "") or "")
    if raw_source:
        return raw_source.lstrip("\ufeff")
    raw_path = str(getattr(item, "script_path", "") or "").strip()
    if raw_path:
        try:
            filepath = bpy.path.abspath(raw_path)
            if os.path.isfile(filepath):
                return read_cached_text_file(filepath).lstrip("\ufeff")
        except Exception:
            traceback.print_exc()
    return ""


def sync_script_library_item_source(item):
    if item is None:
        return False
    text_name = (getattr(item, "text_block_name", "") or "").strip()
    if text_name:
        text_block = bpy.data.texts.get(text_name)
        if text_block is not None:
            source = text_block.as_string()
            if source != getattr(item, "script_source", ""):
                item.script_source = source
            return True
    raw_path = (getattr(item, "script_path", "") or "").strip()
    if not raw_path:
        return False
    filepath = bpy.path.abspath(raw_path)
    if not os.path.isfile(filepath):
        return False
    source = read_cached_text_file(filepath)
    if source != getattr(item, "script_source", ""):
        item.script_source = source
    return True


def refresh_script_library_sources(space_state):
    if space_state is None:
        return 0
    refreshed = 0
    for item in getattr(space_state, "script_library", []):
        try:
            updated = sync_script_library_item_source(item)
        except Exception:
            updated = False
        if updated:
            refreshed += 1
    return refreshed


def refresh_script_library_sources_for_workflows(space_state, workflows):
    if space_state is None:
        return 0
    workflow_names = {
        getattr(workflow, "name", "")
        for workflow in (workflows or [])
        if workflow is not None and getattr(workflow, "name", "")
    }
    if not workflow_names:
        return 0
    refreshed = 0
    for item in getattr(space_state, "script_library", []):
        name = getattr(item, "name", "")
        if name not in workflow_names:
            continue
        try:
            updated = sync_script_library_item_source(item)
        except Exception:
            updated = False
        if updated:
            refreshed += 1
    return refreshed


def workflow_related_script_library_items(state, workflows):
    if state is None:
        return []
    workflow_names = {
        getattr(workflow, "name", "")
        for workflow in (workflows or [])
        if workflow is not None and getattr(workflow, "name", "")
    }
    module_names = set()
    for workflow in workflows or []:
        for module in getattr(workflow, "modules", []):
            module_name = getattr(module, "name", "")
            if module_name:
                module_names.add(module_name)
    selected = []
    seen = set()
    for item in getattr(state, "script_library", []):
        name = getattr(item, "name", "")
        if name not in workflow_names and name not in module_names:
            continue
        if script_library_item_has_builtin_tag(item):
            continue
        signature = script_library_signature_from_item(item)
        if signature in seen:
            continue
        seen.add(signature)
        selected.append(item)
    return selected


def panel_match_payload_for_export(state, panel_id):
    if state is None or not panel_id:
        return None
    record = panel_drawer_record(state, panel_id) or find_registry_record(state, panel_id)
    if record is None:
        return None
    source_module = getattr(record, "source_module", "")
    return {
        "panel_id": getattr(record, "panel_id", panel_id),
        "title": clean_panel_title(getattr(record, "title", ""), getattr(record, "panel_id", panel_id)),
        "category": getattr(record, "category", ""),
        "source_module": source_module,
        "addon_version": getattr(record, "addon_version", ""),
        "plugin_key": panel_plugin_key_from_module(source_module) or infer_plugin_key_from_panel_id(panel_id),
        "plugin_title": panel_plugin_title(state, panel_id),
    }


def workflow_panel_match_payloads(state, workflow):
    if state is None or workflow is None:
        return []
    payloads = []
    seen = set()
    for item in getattr(workflow, "panels", []):
        panel_id = getattr(item, "panel_id", "")
        if not panel_id or panel_id == "BWFLOW_PT_workflow" or panel_id in seen:
            continue
        seen.add(panel_id)
        payload = panel_match_payload_for_export(state, panel_id)
        if payload is not None:
            payloads.append(payload)
    return payloads


def workflow_plugin_requirement_payloads(state, workflows):
    if state is None:
        return []
    requirements = {}
    for workflow in workflows or []:
        if workflow is None:
            continue
        for item in getattr(workflow, "panels", []):
            panel_id = getattr(item, "panel_id", "")
            if not panel_id or panel_id == "BWFLOW_PT_workflow":
                continue
            payload = panel_match_payload_for_export(state, panel_id)
            if payload is None:
                continue
            key = payload.get("plugin_key", "") or payload.get("source_module", "") or panel_id
            existing = requirements.get(key, {})
            requirements[key] = {
                "plugin_key": key,
                "plugin_title": payload.get("plugin_title", "") or existing.get("plugin_title", ""),
                "source_module": payload.get("source_module", "") or existing.get("source_module", ""),
                "addon_version": max_version_text(existing.get("addon_version", ""), payload.get("addon_version", "")),
            }
    return list(requirements.values())


def serialize_workflow(workflow, state=None):
    if workflow is None:
        return None
    return {
        "name": workflow.name,
        "is_default": workflow.is_default,
        "description": workflow.description,
        "tag_filter": workflow.tag_filter,
        "missing_warning_dismissed": bool(getattr(workflow, "missing_warning_dismissed", False)),
        "panels": [item.panel_id for item in workflow.panels],
        "panel_matches": workflow_panel_match_payloads(state, workflow),
        "plugin_requirements": workflow_plugin_requirement_payloads(state, [workflow]),
        "modules": [
            {
                "name": module.name,
                "enabled": module.enabled,
                "use_custom_panel": module.use_custom_panel,
                "runtime_panel_expanded": getattr(module, "runtime_panel_expanded", True),
                "runtime_description_expanded": getattr(module, "runtime_description_expanded", False),
                "panel_title": module.panel_title,
                "panel_description": module.panel_description,
                "script_path": module.script_path,
                "description": module.description,
                "text_block_name": module.text_block_name,
                "script_source": export_script_source_from_item(module),
                "config_payload": getattr(module, "config_payload", ""),
                "ai_doc": module.ai_doc,
            }
            for module in workflow.modules
        ],
    }


def serialize_space_settings(space_state):
    return {
        "runtime_initialized": bool(getattr(space_state.settings, "runtime_initialized", False)),
        "auto_sync_registry": space_state.settings.auto_sync_registry,
        "show_missing_summary": space_state.settings.show_missing_summary,
        "runtime_preview_lines": space_state.settings.runtime_preview_lines,
        "show_workflow_description": space_state.settings.show_workflow_description,
        "show_runtime_module_descriptions": space_state.settings.show_runtime_module_descriptions,
        "show_module_ai_doc_preview": space_state.settings.show_module_ai_doc_preview,
        "show_script_library_source_preview": space_state.settings.show_script_library_source_preview,
        "show_script_library_ai_doc_preview": space_state.settings.show_script_library_ai_doc_preview,
        "show_help_text_blocks": space_state.settings.show_help_text_blocks,
    }


def serialize_space_state(space_state):
    if space_state is None:
        return None
    return {
        "label": SPACE_LABELS.get(getattr(space_state, "space_type", ""), getattr(space_state, "space_type", "")),
        "active_workflow_index": space_state.active_workflow_index,
        "settings": serialize_space_settings(space_state),
        "panel_registry": serialize_panel_registry(space_state),
        "script_library": serialize_script_library(space_state),
        "workflows": [
            workflow_payload
            for workflow_payload in (serialize_workflow(workflow, state=space_state) for workflow in space_state.workflows)
            if workflow_payload is not None
        ],
    }


def selected_preset_export_workflows(state):
    if state is None:
        return []
    return [
        workflow
        for workflow in state.workflows
        if bool(getattr(workflow, "preset_export_selected", False))
    ]


def workflow_preset_filename(state, workflows):
    workflows = list(workflows or [])
    if len(workflows) == 1:
        workflow_name = getattr(workflows[0], "name", "") or "workflow"
        return f"{safe_filename_component(workflow_name, 'workflow')}{PRESET_FILE_EXTENSION}"
    space_type = getattr(state, "space_type", "") if state is not None else ""
    space_suffix = safe_filename_component(space_type.lower(), "workflow")
    count = max(1, len(workflows))
    return f"go_workflow_{space_suffix}_{count}_workflows{PRESET_FILE_EXTENSION}"


def normalize_preset_export_filepath(filepath):
    path = bpy.path.abspath(str(filepath or "").strip())
    if not path:
        return path
    lowered = path.lower()
    for suffix in (".goworkflow.zip", ".goworkflow", ".bworkflow", ".zip"):
        if lowered.endswith(suffix):
            path = path[: -len(suffix)]
            lowered = path.lower()
            break
    if not lowered.endswith(PRESET_FILE_EXTENSION):
        path += PRESET_FILE_EXTENSION
    return path


def default_preset_export_path(context, state):
    workflows = selected_preset_export_workflows(state)
    if not workflows:
        workflow = get_active_workflow(state)
        workflows = [workflow] if workflow is not None else []
    filename = workflow_preset_filename(state, workflows)
    try:
        base_dir = bpy.path.abspath("//")
    except Exception:
        base_dir = ""
    if not base_dir:
        base_dir = os.path.expanduser("~")
    return os.path.join(base_dir, filename)


def load_json_payload_file(filepath, max_bytes=None):
    return read_cached_json_file(filepath, max_bytes=max_bytes)


def preset_archive_script_name(kind, index, module_name):
    safe_name = safe_filename_component(module_name or f"{kind}_{index + 1}", f"{kind}_{index + 1}", max_length=48)
    return f"scripts/{kind}_{index + 1:03d}_{safe_name}.py"


def externalize_preset_scripts(payload):
    if not isinstance(payload, dict):
        return payload, {}
    payload = json.loads(json.dumps(payload, ensure_ascii=False))
    assets = {}
    asset_index = 0

    def externalize_module(module, kind):
        nonlocal asset_index
        if not isinstance(module, dict):
            return
        source = str(module.get("script_source", "") or "")
        if not source:
            return
        asset_name = preset_archive_script_name(kind, asset_index, module.get("name", "module"))
        asset_index += 1
        assets[asset_name] = source
        module["script_asset"] = asset_name
        module["script_source"] = ""
        module["text_block_name"] = ""

    def externalize_workflow(workflow):
        if not isinstance(workflow, dict):
            return
        for module in workflow.get("modules", []) or []:
            externalize_module(module, "module")

    if isinstance(payload.get("workflow"), dict):
        externalize_workflow(payload.get("workflow"))
    for space_payload in (payload.get("space_states") or {}).values() if isinstance(payload.get("space_states"), dict) else []:
        if not isinstance(space_payload, dict):
            continue
        for workflow in space_payload.get("workflows", []) or []:
            externalize_workflow(workflow)
        for item in space_payload.get("script_library", []) or []:
            externalize_module(item, "library")
    for item in payload.get("script_library", []) or []:
        externalize_module(item, "library")
    return payload, assets


def write_preset_archive(filepath, payload):
    target_path = normalize_preset_export_filepath(filepath)
    if not target_path:
        raise ValueError("Preset export path is empty")
    folder = os.path.dirname(target_path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    manifest, assets = externalize_preset_scripts(payload)
    with zipfile.ZipFile(target_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        for asset_name, source in assets.items():
            archive.writestr(asset_name, str(source or ""))
    return target_path


def normalize_preset_archive_member_name(name):
    return str(name or "").replace("\\", "/").lstrip("/")


def find_preset_archive_member(names, requested_name):
    requested = normalize_preset_archive_member_name(requested_name)
    if not requested:
        return ""
    normalized_lookup = {}
    for name in names:
        normalized = normalize_preset_archive_member_name(name)
        if name == requested or normalized == requested:
            return name
        normalized_lookup.setdefault(normalized.casefold(), name)
    return normalized_lookup.get(requested.casefold(), "")


def read_preset_archive_text_member(archive, member_name, max_bytes=None, label="archive member"):
    try:
        info = archive.getinfo(member_name)
    except KeyError:
        raise ValueError(f"Preset archive missing {label}: {member_name}")
    if max_bytes is not None and int(getattr(info, "file_size", 0) or 0) > max_bytes:
        raise ValueError(f"Preset {label} is too large: {info.file_size / (1024 * 1024):.1f} MB")
    with archive.open(member_name, "r") as handle:
        return handle.read().decode("utf-8-sig", errors="replace")


def read_preset_archive(filepath, max_bytes=None, hydrate_scripts=True):
    target_path = bpy.path.abspath(str(filepath or "").strip())
    if not target_path:
        raise ValueError("Preset path is empty")
    if not zipfile.is_zipfile(target_path):
        return load_json_payload_file(target_path, max_bytes=max_bytes)
    if max_bytes is not None and os.path.getsize(target_path) > max_bytes:
        raise ValueError("Preset archive is too large")
    with zipfile.ZipFile(target_path, "r") as archive:
        names = archive.namelist()
        manifest_name = find_preset_archive_member(names, "manifest.json")
        if not manifest_name:
            raise ValueError("Preset archive missing manifest.json")
        payload = json.loads(
            read_preset_archive_text_member(
                archive,
                manifest_name,
                max_bytes=MAX_PRESET_MANIFEST_BYTES,
                label="manifest.json",
            )
        )
        if isinstance(payload, dict):
            payload["preset_archive_format"] = "zip"
            payload["preset_archive_path"] = target_path

        def hydrate_module(module):
            if not isinstance(module, dict):
                return
            asset_name = str(module.get("script_asset", "") or "")
            archive_asset_name = find_preset_archive_member(names, asset_name)
            normalized_asset_name = normalize_preset_archive_member_name(archive_asset_name)
            if not archive_asset_name or not normalized_asset_name.startswith("scripts/"):
                return
            module["script_source"] = read_preset_archive_text_member(
                archive,
                archive_asset_name,
                max_bytes=MAX_PRESET_SCRIPT_ASSET_BYTES,
                label="script asset",
            )

        def hydrate_workflow(workflow):
            if not isinstance(workflow, dict):
                return
            for module in workflow.get("modules", []) or []:
                hydrate_module(module)

        if hydrate_scripts:
            if isinstance(payload.get("workflow"), dict):
                hydrate_workflow(payload.get("workflow"))
            for space_payload in (payload.get("space_states") or {}).values() if isinstance(payload.get("space_states"), dict) else []:
                if not isinstance(space_payload, dict):
                    continue
                for workflow in space_payload.get("workflows", []) or []:
                    hydrate_workflow(workflow)
                for item in space_payload.get("script_library", []) or []:
                    hydrate_module(item)
            for item in payload.get("script_library", []) or []:
                hydrate_module(item)
        return payload


def hydrate_preset_payload_scripts_from_archive(payload, filepath):
    if not isinstance(payload, dict):
        return payload
    target_path = bpy.path.abspath(str(filepath or payload.get("preset_archive_path", "") or "").strip())
    if not target_path or not zipfile.is_zipfile(target_path):
        return payload
    with zipfile.ZipFile(target_path, "r") as archive:
        names = archive.namelist()

        def hydrate_module(module):
            if not isinstance(module, dict) or module.get("script_source"):
                return
            asset_name = str(module.get("script_asset", "") or "")
            archive_asset_name = find_preset_archive_member(names, asset_name)
            normalized_asset_name = normalize_preset_archive_member_name(archive_asset_name)
            if not archive_asset_name or not normalized_asset_name.startswith("scripts/"):
                return
            module["script_source"] = read_preset_archive_text_member(
                archive,
                archive_asset_name,
                max_bytes=MAX_PRESET_SCRIPT_ASSET_BYTES,
                label="script asset",
            )

        workflow = payload.get("workflow")
        if isinstance(workflow, dict):
            for module in workflow.get("modules", []) or []:
                hydrate_module(module)
        for item in payload.get("script_library", []) or []:
            hydrate_module(item)
    return payload


def collect_window_layouts(scene=None):
    """Capture lightweight window/screen/area routing metadata for presets."""
    layouts = []
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return layouts
    for window_index, window in enumerate(getattr(window_manager, "windows", [])):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        areas = []
        for area_index, area in enumerate(getattr(screen, "areas", [])):
            area_type = str(getattr(area, "type", "") or "")
            if area_type not in SUPPORTED_SPACE_TYPES:
                continue
            areas.append(
                {
                    "index": area_index,
                    "type": area_type,
                    "ui_type": str(getattr(area, "ui_type", "") or ""),
                    "x": int(getattr(area, "x", 0) or 0),
                    "y": int(getattr(area, "y", 0) or 0),
                    "width": int(getattr(area, "width", 0) or 0),
                    "height": int(getattr(area, "height", 0) or 0),
                }
            )
        if not areas:
            continue
        layouts.append(
            {
                "window_index": window_index,
                "workspace": str(getattr(getattr(window, "workspace", None), "name", "") or ""),
                "screen": str(getattr(screen, "name", "") or ""),
                "areas": areas,
            }
        )
    return layouts


def build_current_workflow_preset_payload(scene, context=None, space_type=None):
    space_type = space_type or current_space_type(context=context)
    state = get_state(context=context, scene=scene, space_type=space_type)
    workflow = get_active_workflow(state)
    workflow_payload = serialize_workflow(workflow, state=state)
    if state is None or workflow_payload is None:
        return None
    related_scripts = workflow_related_script_library_items(state, [workflow] if workflow is not None else [])
    payload = {
        "schema_version": SCHEMA_VERSION,
        "preset_kind": CURRENT_WORKFLOW_PRESET_KIND,
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "space_type": space_type,
        "space_label": SPACE_LABELS.get(space_type, space_type),
        "workflow_name": workflow_payload.get("name", ""),
        "settings": serialize_space_settings(state),
        "panel_registry": collect_workflow_panel_registry_records(state, [workflow]),
        "script_library": serialize_script_library_items(related_scripts),
        "workflow": workflow_payload,
        "window_layouts": collect_window_layouts(scene),
    }
    return sanitize_current_workflow_preset_payload(payload)


def build_selected_workflows_preset_payload(scene, context=None, space_type=None):
    space_type = space_type or current_space_type(context=context)
    state = get_state(context=context, scene=scene, space_type=space_type)
    workflows = selected_preset_export_workflows(state)
    if state is None or not workflows:
        return None

    workflow_payloads = [
        workflow_payload
        for workflow_payload in (serialize_workflow(workflow, state=state) for workflow in workflows)
        if workflow_payload is not None
    ]
    if not workflow_payloads:
        return None
    related_scripts = workflow_related_script_library_items(state, workflows)

    active_workflow = get_active_workflow(state)
    active_name = getattr(active_workflow, "name", "") if active_workflow is not None else ""
    active_workflow_index = 0
    for index, workflow_payload in enumerate(workflow_payloads):
        if workflow_payload.get("name", "") == active_name:
            active_workflow_index = index
            break

    space_payload = sanitize_space_payload(
        {
            "label": SPACE_LABELS.get(space_type, space_type),
            "active_workflow_index": active_workflow_index,
            "settings": serialize_space_settings(state),
            "panel_registry": collect_workflow_panel_registry_records(state, workflows),
            "script_library": serialize_script_library_items(related_scripts),
            "workflows": workflow_payloads,
        }
    )
    if space_payload is None:
        return None

    space_states = {space_type: space_payload}
    selected_names = {
        workflow_payload.get("name", "")
        for workflow_payload in workflow_payloads
        if workflow_payload.get("name", "")
    }
    for target_space in iter_supported_space_types():
        if target_space == space_type:
            continue
        target_state = get_state(scene=scene, space_type=target_space)
        if target_state is None:
            continue
        matching_workflows = [
            workflow
            for workflow in getattr(target_state, "workflows", [])
            if getattr(workflow, "name", "") in selected_names
        ]
        if not matching_workflows:
            continue
        target_payloads = [
            workflow_payload
            for workflow_payload in (
                serialize_workflow(workflow, state=target_state)
                for workflow in matching_workflows
            )
            if workflow_payload is not None
        ]
        if not target_payloads:
            continue
        target_space_payload = sanitize_space_payload(
            {
                "label": SPACE_LABELS.get(target_space, target_space),
                "active_workflow_index": 0,
                "settings": serialize_space_settings(target_state),
                "panel_registry": collect_workflow_panel_registry_records(
                    target_state, matching_workflows
                ),
                "script_library": serialize_script_library_items(
                    workflow_related_script_library_items(target_state, matching_workflows)
                ),
                "workflows": target_payloads,
            }
        )
        if target_space_payload is not None:
            space_states[target_space] = target_space_payload

    return sanitize_full_payload(
        {
            "schema_version": SCHEMA_VERSION,
            "preset_kind": "workflow_collection",
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "space_states": space_states,
            "window_layouts": collect_window_layouts(scene),
        }
    )


def build_full_state_payload(scene):
    payload = {
        "schema_version": SCHEMA_VERSION,
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "space_states": {},
    }
    for space_type in iter_supported_space_types():
        space_state = get_state(scene=scene, space_type=space_type)
        if space_state is None:
            continue
        payload["space_states"][space_type] = serialize_space_state(space_state)
    payload["window_layouts"] = collect_window_layouts(scene)
    return sanitize_full_payload(payload)


def apply_space_state_payload(state, space_payload):
    if state is None or not isinstance(space_payload, dict):
        return
    cleaned_payload = sanitize_space_payload(space_payload)
    if cleaned_payload is None:
        return

    clear_collection(state.workflows)
    clear_collection(state.panel_registry)
    clear_collection(state.script_library)

    settings = cleaned_payload.get("settings", {})
    state.settings.runtime_initialized = coerce_bool_value(settings.get("runtime_initialized", False), False)
    state.settings.auto_sync_registry = coerce_bool_value(settings.get("auto_sync_registry", True), True)
    state.settings.show_missing_summary = coerce_bool_value(settings.get("show_missing_summary", True), True)
    state.settings.runtime_preview_lines = coerce_int_value(settings.get("runtime_preview_lines", 3), 3)
    state.settings.show_workflow_description = coerce_bool_value(settings.get("show_workflow_description", False), False)
    state.settings.show_runtime_module_descriptions = coerce_bool_value(settings.get("show_runtime_module_descriptions", False), False)
    state.settings.show_module_ai_doc_preview = coerce_bool_value(settings.get("show_module_ai_doc_preview", False), False)
    state.settings.show_script_library_source_preview = coerce_bool_value(settings.get("show_script_library_source_preview", False), False)
    state.settings.show_script_library_ai_doc_preview = coerce_bool_value(settings.get("show_script_library_ai_doc_preview", False), False)
    state.settings.show_help_text_blocks = coerce_bool_value(settings.get("show_help_text_blocks", False), False)

    for record_data in cleaned_payload.get("panel_registry", []):
        record = state.panel_registry.add()
        ok = (
            safe_set_rna_text(record, "panel_id", record_data.get("panel_id", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            and safe_set_rna_text(record, "title", record_data.get("title", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            and safe_set_rna_text(record, "category", record_data.get("category", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            and safe_set_rna_text(record, "tags", record_data.get("tags", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            and safe_set_rna_text(record, "source_module", record_data.get("source_module", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            and safe_set_rna_text(record, "addon_version", record_data.get("addon_version", ""), max_chars=32)
        )
        if not ok or not getattr(record, "panel_id", ""):
            try:
                state.panel_registry.remove(len(state.panel_registry) - 1)
            except Exception:
                traceback.print_exc()
            continue
        record.discovered = False

    for script_data in cleaned_payload.get("script_library", []):
        item = state.script_library.add()
        apply_safe_imported_script_library_payload(state, item, script_data)

    for workflow_data in cleaned_payload.get("workflows", []):
        workflow = state.workflows.add()
        workflow.is_default = workflow_data.get("is_default", False)
        safe_set_rna_text(
            workflow,
            "name",
            unique_workflow_name(
            state,
            workflow_data.get("name", ""),
            DEFAULT_WORKFLOW_NAME if workflow.is_default else "自定义工作流",
                exclude_index=len(state.workflows) - 1,
            ),
            fallback=DEFAULT_WORKFLOW_NAME if workflow.is_default else "Imported Workflow",
            max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
        )
        safe_set_rna_text(
            workflow,
            "description",
            normalize_workflow_description(workflow_data.get("description", ""), ""),
            max_chars=MAX_RNA_SHORT_TEXT_CHARS,
        )
        safe_set_rna_text(
            workflow,
            "tag_filter",
            workflow_data.get("tag_filter", ""),
            max_chars=MAX_RNA_SHORT_TEXT_CHARS,
        )
        workflow.missing_warning_dismissed = bool(workflow_data.get("missing_warning_dismissed", False))
        for panel_id in remap_imported_workflow_panel_ids(state, workflow_data):
            item = workflow.panels.add()
            safe_set_rna_text(item, "panel_id", panel_id, max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
        for module_data in workflow_data.get("modules", []):
            module = workflow.modules.add()
            apply_safe_imported_module_payload(workflow, module, module_data)

    ensure_one_default_workflow(state)
    ensure_go_workflow_panel_entry(state)
    ensure_builtin_script_library(state)
    state.active_workflow_index = clamp_index(cleaned_payload.get("active_workflow_index", 0), len(state.workflows))


def merge_panel_registry_payload(state, panel_records):
    if state is None:
        return 0
    existing = {item.panel_id: item for item in state.panel_registry if item.panel_id}
    added = 0
    for record_data in panel_records or []:
        if not isinstance(record_data, dict):
            continue
        panel_id = (record_data.get("panel_id", "") or "").strip()
        if not panel_id:
            continue
        record = existing.get(panel_id)
        if record is None:
            record = state.panel_registry.add()
            safe_set_rna_text(record, "panel_id", panel_id, max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
            record.discovered = False
            existing[panel_id] = record
            added += 1
        if not record.title:
            safe_set_rna_text(
                record,
                "title",
                clean_panel_title(record_data.get("title", ""), panel_id),
                max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
            )
        if not record.category:
            safe_set_rna_text(
                record,
                "category",
                normalize_text_value(record_data.get("category", ""), ""),
                max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
            )
    return added


def normalized_panel_match_text(value):
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def panel_match_payload_from_record(state, record):
    if record is None:
        return None
    panel_id = getattr(record, "panel_id", "")
    source_module = getattr(record, "source_module", "")
    return {
        "panel_id": panel_id,
        "title": clean_panel_title(getattr(record, "title", ""), panel_id),
        "category": getattr(record, "category", ""),
        "source_module": source_module,
        "addon_version": getattr(record, "addon_version", ""),
        "plugin_key": panel_plugin_key_from_module(source_module) or infer_plugin_key_from_panel_id(panel_id),
        "plugin_title": panel_plugin_title(state, panel_id) if state is not None else "",
    }


def panel_match_payloads_by_id(state, workflow_data):
    payloads = {}
    for item in coerce_list_value((workflow_data or {}).get("panel_matches", [])):
        payload = sanitize_panel_match_payload(item)
        if payload is not None:
            payloads[payload["panel_id"]] = payload
    for item in coerce_list_value((workflow_data or {}).get("panels", [])):
        panel_id = str(item or "").strip()
        if not panel_id or panel_id in payloads:
            continue
        record = find_registry_record(state, panel_id) if state is not None else None
        payload = panel_match_payload_from_record(state, record)
        if payload is not None:
            payloads[panel_id] = payload
    return payloads


def imported_workflow_match_cache_key(state, workflow):
    if state is None or workflow is None:
        return ""
    return f"{getattr(state, 'space_type', 'VIEW_3D')}::{getattr(workflow, 'name', '')}"


def cache_imported_workflow_panel_matches(state, workflow, workflow_data):
    key = imported_workflow_match_cache_key(state, workflow)
    if not key or not isinstance(workflow_data, dict):
        return
    matches = []
    for item in coerce_list_value(workflow_data.get("panel_matches", [])):
        payload = sanitize_panel_match_payload(item)
        if payload is not None:
            matches.append(payload)
    if matches:
        IMPORTED_WORKFLOW_PANEL_MATCH_CACHE[key] = matches
        IMPORTED_WORKFLOW_MISSING_MATCH_CACHE.pop(key, None)


def imported_workflow_panel_matches(state, workflow):
    key = imported_workflow_match_cache_key(state, workflow)
    return IMPORTED_WORKFLOW_PANEL_MATCH_CACHE.get(key, []) if key else []


def imported_workflow_missing_panel_matches(state, workflow):
    key = imported_workflow_match_cache_key(state, workflow)
    matches = imported_workflow_panel_matches(state, workflow)
    space_type = getattr(state, "space_type", "VIEW_3D") if state is not None else "VIEW_3D"
    signature = (
        panel_registry_lookup_signature(state),
        len(get_panel_cache(space_type)),
        len(get_panel_registry(space_type)),
        tuple(
            (
                payload.get("panel_id", ""),
                payload.get("title", ""),
                payload.get("category", ""),
                payload.get("source_module", ""),
                payload.get("plugin_key", ""),
            )
            for payload in matches
            if isinstance(payload, dict)
        ),
    )
    cached = IMPORTED_WORKFLOW_MISSING_MATCH_CACHE.get(key)
    if cached is not None and cached.get("signature") == signature:
        return list(cached.get("matches", ()))
    runtime_ids = runtime_panel_ids_for_space(space_type) if state is not None else set()
    missing = []
    for payload in matches:
        if not isinstance(payload, dict):
            continue
        panel_id = payload.get("panel_id", "")
        matched_id = find_panel_by_name_match(state, payload)
        if matched_id and matched_id in runtime_ids:
            continue
        if panel_id:
            missing.append(payload)
    if key:
        IMPORTED_WORKFLOW_MISSING_MATCH_CACHE[key] = {
            "signature": signature,
            "matches": tuple(missing),
        }
    return missing


class ImportedMissingPanelRecord:
    def __init__(self, payload):
        payload = payload or {}
        self.panel_id = payload.get("panel_id", "")
        self.title = payload.get("title", "") or self.panel_id
        self.category = payload.get("category", "")
        self.tags = ""
        self.source_module = payload.get("source_module", "") or payload.get("plugin_key", "")
        self.addon_version = payload.get("addon_version", "")
        self.discovered = False


def imported_panel_match_payload_by_id(state, workflow):
    return {
        payload.get("panel_id", ""): payload
        for payload in imported_workflow_missing_panel_matches(state, workflow)
        if isinstance(payload, dict) and payload.get("panel_id", "")
    }


def runtime_panel_ids_for_space(space_type):
    return set(get_panel_cache(space_type).keys()) | set(get_panel_registry(space_type).keys())


def panel_match_score(source, candidate):
    if not isinstance(source, dict) or not isinstance(candidate, dict):
        return 0
    source_title = normalized_panel_match_text(source.get("title", ""))
    candidate_title = normalized_panel_match_text(candidate.get("title", ""))
    source_category = normalized_panel_match_text(source.get("category", ""))
    candidate_category = normalized_panel_match_text(candidate.get("category", ""))
    source_module = normalized_panel_match_text(source.get("source_module", ""))
    candidate_module = normalized_panel_match_text(candidate.get("source_module", ""))
    source_plugin = normalized_panel_match_text(source.get("plugin_key", ""))
    candidate_plugin = normalized_panel_match_text(candidate.get("plugin_key", ""))
    source_plugin_title = normalized_panel_match_text(source.get("plugin_title", ""))
    candidate_plugin_title = normalized_panel_match_text(candidate.get("plugin_title", ""))
    source_panel_id = normalized_panel_match_text(source.get("panel_id", ""))
    candidate_panel_id = normalized_panel_match_text(candidate.get("panel_id", ""))

    score = 0
    if source_panel_id and source_panel_id == candidate_panel_id:
        score += 1000
    if source_module and source_module == candidate_module:
        score += 420
    if source_plugin and source_plugin == candidate_plugin:
        score += 360
    if source_plugin_title and source_plugin_title == candidate_plugin_title:
        score += 180
    if source_title and source_title == candidate_title:
        score += 260
    elif source_title and candidate_title and (source_title in candidate_title or candidate_title in source_title):
        score += 120
    if source_category and source_category == candidate_category:
        score += 120
    if score >= 360 and source_title and candidate_title:
        return score
    if source_panel_id and source_panel_id == candidate_panel_id:
        return score
    return 0


def find_panel_by_name_match(state, source_payload):
    if state is None or not isinstance(source_payload, dict):
        return ""
    space_type = getattr(state, "space_type", "VIEW_3D")
    runtime_ids = runtime_panel_ids_for_space(space_type)
    old_id = source_payload.get("panel_id", "")
    if old_id and old_id in runtime_ids:
        return old_id
    drawer_id = panel_drawer_root_id(old_id, space_type=space_type) if old_id else ""
    if drawer_id and drawer_id in runtime_ids:
        return drawer_id
    lookup = get_panel_registry_lookup(state)
    source_module = normalized_panel_match_text(source_payload.get("source_module", ""))
    if source_module:
        candidates = lookup.get("records_by_source_module", {}).get(source_module, [])
        for record in candidates:
            panel_id = getattr(record, "panel_id", "")
            if panel_id and panel_id in runtime_ids:
                return panel_id
    source_plugin = normalized_panel_match_text(source_payload.get("plugin_key", ""))
    if source_plugin:
        candidates = lookup.get("records_by_plugin_key", {}).get(source_plugin, [])
        if len(candidates) == 1:
            panel_id = getattr(candidates[0], "panel_id", "")
            if panel_id and panel_id in runtime_ids:
                return panel_id
    best_id = ""
    best_score = 0
    for record in getattr(state, "panel_registry", []):
        panel_id = getattr(record, "panel_id", "")
        if not panel_id or panel_id == "BWFLOW_PT_workflow" or panel_id not in runtime_ids:
            continue
        candidate = panel_match_payload_from_record(state, record)
        score = panel_match_score(source_payload, candidate)
        if score > best_score:
            best_id = panel_id
            best_score = score
    return best_id if best_score >= 520 else ""


def remap_imported_workflow_panel_ids(state, workflow_data):
    if not isinstance(workflow_data, dict):
        return []
    match_by_id = panel_match_payloads_by_id(state, workflow_data)
    remapped = []
    seen = set()
    for panel_id in unique_panel_ids(workflow_data.get("panels", [])):
        if panel_id == "BWFLOW_PT_workflow":
            target_id = panel_id
        else:
            source_payload = match_by_id.get(panel_id) or {"panel_id": panel_id}
            target_id = find_panel_by_name_match(state, source_payload)
        if target_id and target_id not in seen:
            remapped.append(target_id)
            seen.add(target_id)
    return remapped


def rematch_workflow_panels_by_name(state, workflow):
    if state is None or workflow is None:
        return 0, 0
    runtime_ids = runtime_panel_ids_for_space(getattr(state, "space_type", "VIEW_3D"))
    changed = 0
    missing = 0
    seen = set()
    for item in getattr(workflow, "panels", []):
        panel_id = getattr(item, "panel_id", "")
        if not panel_id or panel_id == "BWFLOW_PT_workflow":
            continue
        if panel_id in runtime_ids:
            seen.add(panel_id)
            continue
        missing += 1
        record = find_registry_record(state, panel_id)
        source_payload = panel_match_payload_from_record(state, record) or {"panel_id": panel_id}
        matched_id = find_panel_by_name_match(state, source_payload)
        if matched_id and matched_id not in seen:
            item.panel_id = matched_id
            seen.add(matched_id)
            changed += 1
    if changed:
        normalize_workflow_active_panel_index(workflow)
        clear_panel_library_click_state(state)
    current_ids = {getattr(item, "panel_id", "") for item in getattr(workflow, "panels", [])}
    for source_payload in imported_workflow_panel_matches(state, workflow):
        matched_id = find_panel_by_name_match(state, source_payload)
        if matched_id and matched_id not in current_ids:
            item = workflow.panels.add()
            item.panel_id = matched_id
            current_ids.add(matched_id)
            changed += 1
    if changed:
        normalize_workflow_active_panel_index(workflow)
        clear_panel_library_click_state(state)
    return changed, missing


def script_library_signature_from_payload(payload):
    return (
        payload.get("description", ""),
        payload.get("tags", ""),
        bool(payload.get("use_custom_panel", False)),
        payload.get("panel_title", ""),
        payload.get("panel_description", ""),
        normalized_script_path_for_match(payload.get("script_path", "")),
        payload.get("text_block_name", ""),
        normalized_script_source_for_match(payload.get("script_source", "")),
        payload.get("config_payload", ""),
        payload.get("ai_doc", ""),
    )


def script_library_signature_from_item(item):
    return script_library_signature_from_payload(script_library_item_snapshot(item) or {})


def merge_script_library_payload(state, script_items):
    if state is None:
        return 0
    existing_signatures = {script_library_signature_from_item(item) for item in state.script_library}
    added = 0
    for script_data in script_items or []:
        payload = sanitize_script_library_payload(script_data)
        if payload is None:
            continue
        signature = script_library_signature_from_payload(payload)
        if signature in existing_signatures:
            continue
        item = state.script_library.add()
        apply_safe_imported_script_library_payload(state, item, payload)
        existing_signatures.add(signature)
        added += 1
    return added


def unique_workflow_name_for_import(state, base_name, exclude_index=None):
    return unique_workflow_name(state, base_name, fallback="导入工作流", exclude_index=exclude_index)


def apply_safe_imported_script_library_payload(state, item, item_data):
    if item is None or not isinstance(item_data, dict):
        return False
    payload = sanitize_script_library_payload(item_data)
    if payload is None:
        return False

    item_name = unique_script_library_name(state, payload.get("name", ""), exclude_index=None) if state is not None else payload.get("name", "")
    safe_set_rna_text(item, "name", item_name, fallback="Imported Script", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
    safe_set_rna_text(item, "description", payload.get("description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    safe_set_rna_text(item, "tags", payload.get("tags", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    item.use_custom_panel = bool(payload.get("use_custom_panel", False))
    safe_set_rna_text(item, "panel_title", payload.get("panel_title", ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
    safe_set_rna_text(item, "panel_description", payload.get("panel_description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    safe_set_rna_text(item, "text_block_name", "", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
    safe_set_rna_text(item, "script_source", "", max_chars=MAX_RNA_SCRIPT_CHARS)
    safe_set_rna_text(item, "config_payload", "", max_chars=MAX_RNA_TEXT_CHARS)
    safe_set_rna_text(item, "ai_doc", "", max_chars=MAX_RNA_TEXT_CHARS)

    source = payload.get("script_source", "")
    source_path = ""
    if source:
        try:
            source_path = write_preset_import_text_asset(None, item.name, "library_script", source, "py")
        except Exception:
            traceback.print_exc()
    safe_set_rna_text(item, "script_path", source_path or payload.get("script_path", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)

    config_payload = payload.get("config_payload", "")
    if config_payload:
        try:
            config_path = write_preset_import_text_asset(None, item.name, "library_config", config_payload, "json")
            safe_set_rna_text(
                item,
                "config_payload",
                import_asset_note("external_config", config_path),
                max_chars=MAX_RNA_TEXT_CHARS,
            )
        except Exception:
            traceback.print_exc()

    ai_doc = payload.get("ai_doc", "")
    if ai_doc:
        try:
            ai_doc_path = write_preset_import_text_asset(None, item.name, "library_ai_doc", ai_doc, "md")
            safe_set_rna_text(
                item,
                "ai_doc",
                import_asset_note("external_ai_doc", ai_doc_path),
                max_chars=MAX_RNA_TEXT_CHARS,
            )
        except Exception:
            traceback.print_exc()

    return True


def apply_safe_imported_module_payload(workflow, module, module_data):
    if workflow is None or module is None or not isinstance(module_data, dict):
        return False

    safe_set_rna_text(
        module,
        "name",
        normalize_workflow_name(coerce_text_value(module_data.get("name", ""), max_chars=MAX_RNA_NAME_CHARS), "Imported Module"),
        fallback="Imported Module",
        max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
    )
    module.enabled = coerce_bool_value(module_data.get("enabled", True), True)
    module.use_custom_panel = coerce_bool_value(module_data.get("use_custom_panel", False), False)
    module.runtime_panel_expanded = coerce_bool_value(
        module_data.get("runtime_panel_expanded", not module_prefers_collapsed_runtime_panel(module_data)),
        not module_prefers_collapsed_runtime_panel(module_data),
    )
    module.runtime_description_expanded = coerce_bool_value(module_data.get("runtime_description_expanded", False), False)
    safe_set_rna_text(
        module,
        "panel_title",
        normalize_text_value(coerce_text_value(module_data.get("panel_title", ""), max_chars=MAX_RNA_NAME_CHARS), ""),
        max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
    )
    safe_set_rna_text(
        module,
        "panel_description",
        normalize_text_value(coerce_text_value(module_data.get("panel_description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        max_chars=MAX_RNA_SHORT_TEXT_CHARS,
    )
    safe_set_rna_text(
        module,
        "description",
        normalize_text_value(coerce_text_value(module_data.get("description", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS), ""),
        max_chars=MAX_RNA_SHORT_TEXT_CHARS,
    )
    safe_set_rna_text(module, "text_block_name", "", max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
    safe_set_rna_text(module, "script_source", "", max_chars=MAX_RNA_SCRIPT_CHARS)
    safe_set_rna_text(module, "config_payload", "", max_chars=MAX_RNA_TEXT_CHARS)
    safe_set_rna_text(module, "ai_doc", "", max_chars=MAX_RNA_TEXT_CHARS)

    source = coerce_text_value(module_data.get("script_source", ""))
    source_path = ""
    if source:
        try:
            source_path = write_preset_import_text_asset(workflow, module.name, "script", source, "py")
        except Exception:
            traceback.print_exc()

    if source_path:
        safe_set_rna_text(module, "script_path", source_path, max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    else:
        safe_set_rna_text(
            module,
            "script_path",
            coerce_text_value(module_data.get("script_path", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS),
            max_chars=MAX_RNA_SHORT_TEXT_CHARS,
        )
        if not module.script_path:
            safe_set_rna_text(
                module,
                "script_path",
                unique_default_module_script_path(workflow, module),
                max_chars=MAX_RNA_SHORT_TEXT_CHARS,
            )

    config_payload = coerce_text_value(module_data.get("config_payload", ""))
    if config_payload:
        try:
            config_path = write_preset_import_text_asset(workflow, module.name, "config", config_payload, "json")
            safe_set_rna_text(
                module,
                "config_payload",
                import_asset_note("external_config", config_path),
                max_chars=MAX_RNA_TEXT_CHARS,
            )
        except Exception:
            traceback.print_exc()

    ai_doc = coerce_text_value(module_data.get("ai_doc", ""))
    if ai_doc:
        try:
            ai_doc_path = write_preset_import_text_asset(workflow, module.name, "ai_doc", ai_doc, "md")
            safe_set_rna_text(
                module,
                "ai_doc",
                import_asset_note("external_ai_doc", ai_doc_path),
                max_chars=MAX_RNA_TEXT_CHARS,
            )
        except Exception:
            traceback.print_exc()

    return True


def apply_module_payload_to_workflow(workflow, module_data):
    module = workflow.modules.add()
    return apply_safe_imported_module_payload(workflow, module, module_data)


def _apply_current_workflow_preset_payload_impl(state, preset_payload, merge_shared=True):
    sanitized = sanitize_current_workflow_preset_payload(preset_payload)
    if state is None or sanitized is None:
        return None

    workflow_data = dict(sanitized.get("workflow", {}))
    imported_name = normalize_workflow_name(workflow_data.get("name", ""), "导入工作流")
    if merge_shared:
        merge_panel_registry_payload(state, sanitized.get("panel_registry", []))

    workflow = state.workflows.add()
    target_index = len(state.workflows) - 1
    safe_set_rna_text(
        workflow,
        "name",
        unique_workflow_name_for_import(state, imported_name, exclude_index=target_index),
        fallback="Imported Workflow",
        max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
    )
    workflow.is_default = False
    safe_set_rna_text(
        workflow,
        "description",
        normalize_workflow_description(workflow_data.get("description", ""), ""),
        max_chars=MAX_RNA_SHORT_TEXT_CHARS,
    )
    safe_set_rna_text(workflow, "tag_filter", workflow_data.get("tag_filter", ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    workflow.missing_warning_dismissed = bool(workflow_data.get("missing_warning_dismissed", False))
    replace_workflow_panels(workflow, remap_imported_workflow_panel_ids(state, workflow_data))
    clear_collection(workflow.modules)
    for module_data in workflow_data.get("modules", []):
        apply_module_payload_to_workflow(workflow, module_data)

    state.active_workflow_index = target_index
    cache_imported_workflow_panel_matches(state, workflow, workflow_data)
    ensure_one_default_workflow(state)
    ensure_go_workflow_panel_entry(state)
    normalize_workflow_active_panel_index(workflow)
    return workflow


def apply_current_workflow_preset_payload(state, preset_payload, merge_shared=True):
    if state is None:
        return None
    workflow_count = len(getattr(state, "workflows", []))
    existing_panel_ids = {
        getattr(record, "panel_id", "")
        for record in getattr(state, "panel_registry", [])
        if getattr(record, "panel_id", "")
    }
    try:
        return _apply_current_workflow_preset_payload_impl(
            state,
            preset_payload,
            merge_shared=merge_shared,
        )
    except Exception:
        traceback.print_exc()
        try:
            while len(state.workflows) > workflow_count:
                state.workflows.remove(len(state.workflows) - 1)
        except Exception:
            traceback.print_exc()
        try:
            for index in range(len(state.panel_registry) - 1, -1, -1):
                record = state.panel_registry[index]
                if getattr(record, "panel_id", "") not in existing_panel_ids:
                    state.panel_registry.remove(index)
        except Exception:
            traceback.print_exc()
        return None


def workflow_entry_is_default(entry):
    workflow = entry.get("workflow", {}) if isinstance(entry, dict) else {}
    return bool(workflow.get("is_default", False))


def direct_import_workflow_entries(entries, preferred_space_type=None):
    entries = [entry for entry in (entries or []) if isinstance(entry, dict)]
    if not entries:
        return []
    non_default = [entry for entry in entries if not workflow_entry_is_default(entry)]
    if preferred_space_type:
        preferred = [entry for entry in non_default if entry.get("space_type", "VIEW_3D") == preferred_space_type]
        if preferred:
            return preferred
    if non_default:
        return non_default
    if preferred_space_type:
        preferred = [entry for entry in entries if entry.get("space_type", "VIEW_3D") == preferred_space_type]
        if preferred:
            return preferred
    return entries


def preset_entry_key(space_type, workflow_index, workflow_name):
    return f"{space_type}:{workflow_index}:{workflow_name}"


def current_workflow_preset_entry(payload):
    sanitized = sanitize_current_workflow_preset_payload(payload)
    if sanitized is None:
        return None
    workflow = sanitized.get("workflow", {})
    space_type = sanitized.get("space_type", "VIEW_3D") or "VIEW_3D"
    return {
        "key": preset_entry_key(space_type, 0, workflow.get("name", "")),
        "space_type": space_type,
        "window_layouts": sanitized.get("window_layouts", []),
        "source_label": sanitized.get("space_label", "") or SPACE_LABELS.get(space_type, space_type),
        "preset_archive_path": sanitized.get("preset_archive_path", ""),
        "workflow_index": 0,
        "workflow": workflow,
        "panel_registry": sanitized.get("panel_registry", []),
        "script_library": sanitized.get("script_library", []),
        "settings": sanitized.get("settings", {}),
    }


def workflow_preset_entries_from_payload(payload, preferred_space_type=None):
    if not isinstance(payload, dict):
        return []
    if is_current_workflow_preset_payload(payload):
        entry = current_workflow_preset_entry(payload)
        return [entry] if entry is not None else []

    entries = []
    space_payloads = payload.get("space_states")
    if isinstance(space_payloads, dict) and space_payloads:
        sanitized_payload = sanitize_full_payload(payload)
        cleaned_spaces = sanitized_payload.get("space_states", {}) if sanitized_payload else {}
        ordered_space_types = []
        if preferred_space_type and preferred_space_type in cleaned_spaces:
            ordered_space_types.append(preferred_space_type)
        ordered_space_types.extend(space_type for space_type in iter_supported_space_types() if space_type not in ordered_space_types)
        ordered_space_types.extend(space_type for space_type in cleaned_spaces.keys() if space_type not in ordered_space_types)
        for space_type in ordered_space_types:
            space_payload = cleaned_spaces.get(space_type)
            if not isinstance(space_payload, dict):
                continue
            workflows = space_payload.get("workflows", [])
            for workflow_index, workflow in enumerate(workflows):
                if not isinstance(workflow, dict):
                    continue
                workflow_name = workflow.get("name", "")
                entries.append(
                    {
                        "key": preset_entry_key(space_type, workflow_index, workflow_name),
                        "space_type": space_type,
                        "window_layouts": sanitized_payload.get("window_layouts", []),
                        "source_label": SPACE_LABELS.get(space_type, space_type),
                        "preset_archive_path": payload.get("preset_archive_path", ""),
                        "workflow_index": workflow_index,
                        "workflow": workflow,
                        "panel_registry": space_payload.get("panel_registry", []),
                        "script_library": space_payload.get("script_library", []),
                        "settings": space_payload.get("settings", {}),
                    }
                )
        return entries

    fallback_space = sanitize_space_payload(
        {
            "active_workflow_index": payload.get("active_workflow_index", 0),
            "settings": payload.get("settings", {}),
            "panel_registry": payload.get("panel_registry", []),
            "script_library": payload.get("script_library", []),
            "workflows": payload.get("workflows", []),
        }
    )
    if fallback_space is None:
        return []
    for workflow_index, workflow in enumerate(fallback_space.get("workflows", [])):
        workflow_name = workflow.get("name", "")
        entries.append(
            {
                "key": preset_entry_key("VIEW_3D", workflow_index, workflow_name),
                "space_type": "VIEW_3D",
                "window_layouts": [],
                "source_label": SPACE_LABELS.get("VIEW_3D", "VIEW_3D"),
                "preset_archive_path": payload.get("preset_archive_path", ""),
                "workflow_index": workflow_index,
                "workflow": workflow,
                "panel_registry": fallback_space.get("panel_registry", []),
                "script_library": fallback_space.get("script_library", []),
                "settings": fallback_space.get("settings", {}),
            }
        )
    return entries


def current_workflow_preset_payload_from_entry(entry):
    if not isinstance(entry, dict):
        return None
    return sanitize_current_workflow_preset_payload(
        {
            "schema_version": SCHEMA_VERSION,
            "preset_kind": CURRENT_WORKFLOW_PRESET_KIND,
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "window_layouts": entry.get("window_layouts", []),
            "space_type": entry.get("space_type", "VIEW_3D"),
            "space_label": entry.get("source_label", ""),
            "preset_archive_path": entry.get("preset_archive_path", ""),
            "workflow_name": (entry.get("workflow") or {}).get("name", ""),
            "settings": entry.get("settings", {}),
            "panel_registry": entry.get("panel_registry", []),
            "script_library": entry.get("script_library", []),
            "workflow": entry.get("workflow", {}),
        }
    )


def attach_panel_matches_from_registry_to_entry(entry):
    if not isinstance(entry, dict):
        return entry
    workflow = entry.get("workflow")
    if not isinstance(workflow, dict):
        return entry
    existing_matches = [
        payload
        for payload in (sanitize_panel_match_payload(item) for item in coerce_list_value(workflow.get("panel_matches", [])))
        if payload is not None
    ]
    if existing_matches:
        workflow["panel_matches"] = existing_matches
        return entry

    registry_by_id = {}
    for record_data in coerce_list_value(entry.get("panel_registry", [])):
        if not isinstance(record_data, dict):
            continue
        panel_id = coerce_text_value(record_data.get("panel_id", ""), max_chars=MAX_RNA_NAME_CHARS).strip()
        if panel_id:
            registry_by_id[panel_id] = record_data

    matches = []
    for panel_id in unique_panel_ids(workflow.get("panels", [])):
        record_data = registry_by_id.get(panel_id)
        if isinstance(record_data, dict):
            payload = sanitize_panel_match_payload(
                {
                    "panel_id": panel_id,
                    "title": record_data.get("title", ""),
                    "category": record_data.get("category", ""),
                    "source_module": record_data.get("source_module", ""),
                    "plugin_key": record_data.get("plugin_key", record_data.get("source_module", "")),
                    "plugin_title": record_data.get("plugin_title", record_data.get("category", "")),
                    "addon_version": record_data.get("addon_version", ""),
                }
            )
        else:
            payload = sanitize_panel_match_payload({"panel_id": panel_id})
        if payload is not None:
            matches.append(payload)
    workflow["panel_matches"] = matches
    return entry


def prepare_safe_preset_entries(entries):
    prepared = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        item = dict(entry)
        workflow = dict(entry.get("workflow", {})) if isinstance(entry.get("workflow"), dict) else {}
        item["workflow"] = workflow
        prepared.append(attach_panel_matches_from_registry_to_entry(item))
    return prepared


def import_single_preset_entry(context, state, entry):
    if state is None or not isinstance(entry, dict):
        return None
    import_key = (
        id(state),
        entry.get("key", ""),
        entry.get("workflow_index", -1),
        entry.get("workflow", {}).get("name", "") if isinstance(entry.get("workflow"), dict) else "",
    )
    if import_key in PRESET_IMPORT_ACTIVE_KEYS:
        print("[Go Workflow] Preset import already in progress; ignored duplicate request.")
        return None
    PRESET_IMPORT_ACTIVE_KEYS.add(import_key)
    # The caller initializes the scene once before importing. Re-running the
    # setup here repeats builtin-module refreshes for every imported entry.
    try:
        workflow_payload = current_workflow_preset_payload_from_entry(entry)
        cache = get_preset_import_cache(state)
        workflow_payload = hydrate_preset_payload_scripts_from_archive(
            workflow_payload,
            cache.get("filepath", "") or entry.get("preset_archive_path", ""),
        )
        global IS_INITIALIZING_ADDON
        previous_initializing = IS_INITIALIZING_ADDON
        IS_INITIALIZING_ADDON = True
        try:
            workflow = apply_current_workflow_preset_payload(state, workflow_payload, merge_shared=False)
        finally:
            IS_INITIALIZING_ADDON = previous_initializing
    finally:
        PRESET_IMPORT_ACTIVE_KEYS.discard(import_key)
    if workflow is not None:
        rebuild_runtime_panels(
            scene=getattr(context, "scene", None),
            space_type=getattr(state, "space_type", "VIEW_3D"),
        )
    return workflow


def import_preset_entry_across_spaces(context, entry):
    """Import one preset entry into its recorded editor-space state."""
    scene = getattr(context, "scene", None)
    if scene is None or not isinstance(entry, dict):
        return []
    imported = []
    target_space = str(entry.get("space_type", "") or "").strip()
    if target_space not in SUPPORTED_SPACE_TYPES:
        target_space = current_space_type(context=context)
    target_state = get_state(scene=scene, space_type=target_space)
    if target_state is None:
        return imported
    ensure_minimum_setup(scene, restore_global=False, save_state=False)
    workflow = import_single_preset_entry(context, target_state, entry)
    if workflow is not None:
        finish_current_space_preset_import(context, target_state, [workflow])
        imported.append((target_space, workflow.name))
    tag_redraw_all()
    return imported


def preset_import_cache_key(state):
    if state is None:
        return ""
    return str(getattr(state, "space_type", "VIEW_3D") or "VIEW_3D")


def set_preset_import_cache(state, filepath, entries, selected_index=0):
    if state is None:
        return
    entries = list(entries or [])
    selected_index = clamp_index(int(selected_index or 0), len(entries)) if entries else 0
    target_scene = safe_context_scene()
    for target_space in iter_supported_space_types():
        key = str(target_space)
        PRESET_IMPORT_ENTRY_CACHE[key] = {
            "filepath": str(filepath or ""),
            "entries": entries,
            "selected_index": selected_index,
        }
        target_state = (
            get_state(scene=target_scene, space_type=target_space)
            if target_scene is not None
            else None
        )
        if target_state is None:
            continue
        try:
            target_state.preset_filepath = str(filepath or "")
            target_state.preset_workflow_index = selected_index
            clear_collection(target_state.preset_workflows)
            populate_preset_workflow_list(
                target_state,
                entries,
                preferred_space_type=target_space,
                sync_cache=False,
            )
        except Exception:
            traceback.print_exc()


def clear_preset_import_cache(state):
    PRESET_IMPORT_ENTRY_CACHE.clear()
    target_scene = safe_context_scene()
    for target_space in iter_supported_space_types():
        target_state = (
            get_state(scene=target_scene, space_type=target_space)
            if target_scene is not None
            else None
        )
        if target_state is None:
            continue
        try:
            target_state.preset_filepath = ""
            target_state.preset_status = ""
            target_state.preset_workflow_index = 0
            clear_collection(target_state.preset_workflows)
        except Exception:
            traceback.print_exc()


def get_preset_import_cache(state):
    return PRESET_IMPORT_ENTRY_CACHE.get(preset_import_cache_key(state), {})


def get_preset_import_entries(state):
    cache = get_preset_import_cache(state)
    entries = cache.get("entries", [])
    return entries if isinstance(entries, list) else []


def preset_import_entry_at(state, index):
    entries = get_preset_import_entries(state)
    if not entries:
        return None
    index = clamp_index(index, len(entries))
    return entries[index]


def preset_import_selected_index(state):
    entries = get_preset_import_entries(state)
    if not entries:
        return -1
    cache = get_preset_import_cache(state)
    return clamp_index(int(cache.get("selected_index", 0) or 0), len(entries))


def set_preset_import_selected_index(state, index):
    cache = get_preset_import_cache(state)
    entries = get_preset_import_entries(state)
    if not cache or not entries:
        return -1
    selected_index = clamp_index(index, len(entries))
    cache["selected_index"] = selected_index
    try:
        state.preset_workflow_index = selected_index
    except Exception:
        pass
    return selected_index


def populate_preset_workflow_list(state, entries, preferred_space_type=None, sync_cache=True):
    if state is None:
        return 0
    selectable_entries = [entry for entry in entries if not workflow_entry_is_default(entry)]
    preferred_entries = [
        entry
        for entry in selectable_entries
        if preferred_space_type and entry.get("space_type", "VIEW_3D") == preferred_space_type
    ]
    default_selected_keys = {
        entry.get("key", "")
        for entry in (preferred_entries if preferred_entries else selectable_entries)
        if entry.get("key", "")
    }
    selected_index = 0
    for index, entry in enumerate(entries):
        entry = entries[index] if index < len(entries) else {}
        if entry.get("key", "") in default_selected_keys:
            selected_index = index
            break
    try:
        state.preset_workflow_index = selected_index
    except Exception:
        pass
    if sync_cache:
        set_preset_import_cache(
            state,
            get_preset_import_cache(state).get("filepath", ""),
            entries,
            selected_index=selected_index,
        )
    return len(entries)


def preset_workflow_selection_counts(state):
    if state is None:
        return 0, 0
    total = len(get_preset_import_entries(state))
    selected = 1 if total else 0
    return selected, total


def save_global_workflow_state_now(scene=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False
    filepath = global_workflow_state_path()
    folder = os.path.dirname(filepath)
    if folder:
        os.makedirs(folder, exist_ok=True)
    payload = build_full_state_payload(target_scene)
    tmp_filepath = filepath + ".tmp"
    backup_filepath = filepath + ".bak"
    serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    with open(tmp_filepath, "w", encoding="utf-8", newline="") as handle:
        handle.write(serialized)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            pass
    if os.path.isfile(filepath):
        try:
            load_json_payload_file(filepath, max_bytes=MAX_GLOBAL_STATE_FILE_BYTES)
            shutil.copy2(filepath, backup_filepath)
        except Exception:
            # Never replace a valid backup with a truncated or malformed file.
            pass
    os.replace(tmp_filepath, filepath)
    return True


def schedule_global_workflow_state_save(scene=None, delay=DEFERRED_SAVE_INTERVAL):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False
    scene_name = getattr(target_scene, "name", "")
    if not scene_name:
        return False
    if scene_name in DEFERRED_SAVE_PENDING_SCENES:
        return True
    DEFERRED_SAVE_PENDING_SCENES.add(scene_name)

    def _save_once(name=scene_name):
        DEFERRED_SAVE_PENDING_SCENES.discard(name)
        scene_ref = bpy.data.scenes.get(name)
        if scene_ref is None:
            return None
        try:
            save_global_workflow_state_now(scene_ref)
        except Exception:
            traceback.print_exc()
        return None

    try:
        _register_one_shot_timer(_save_once, first_interval=max(0.05, float(delay)))
        return True
    except Exception:
        DEFERRED_SAVE_PENDING_SCENES.discard(scene_name)
        traceback.print_exc()
        return False


def save_global_workflow_state(scene=None):
    return schedule_global_workflow_state_save(scene)


def load_global_workflow_state():
    filepath = global_workflow_state_path()
    for candidate in (filepath, filepath + ".bak"):
        if not os.path.isfile(candidate):
            continue
        try:
            payload = load_json_payload_file(candidate, max_bytes=MAX_GLOBAL_STATE_FILE_BYTES)
            cleaned = sanitize_full_payload(payload) if isinstance(payload, dict) else None
            if cleaned is not None:
                return cleaned
        except Exception:
            traceback.print_exc()
    return None


def state_is_auto_default_only(state):
    if state is None or len(getattr(state, "workflows", [])) != 1:
        return False
    workflow = state.workflows[0]
    explicit_panels = [item.panel_id for item in getattr(workflow, "panels", []) if item.panel_id != "BWFLOW_PT_workflow"]
    return (
        bool(getattr(workflow, "is_default", False))
        and (getattr(workflow, "name", "") or "") == DEFAULT_WORKFLOW_NAME
        and not explicit_panels
        and not getattr(workflow, "modules", [])
        and not (getattr(workflow, "tag_filter", "") or "").strip()
    )


def try_restore_global_workflow_state(scene):
    payload = load_global_workflow_state()
    if not payload or scene is None:
        return False
    space_payloads = payload.get("space_states")
    if not isinstance(space_payloads, dict) or not space_payloads:
        return False

    restored = False
    for space_type in iter_supported_space_types():
        state = get_state(scene=scene, space_type=space_type)
        if state is None:
            continue
        if state.workflows and not state_is_auto_default_only(state):
            continue
        space_payload = space_payloads.get(space_type)
        if not isinstance(space_payload, dict):
            continue
        try:
            apply_space_state_payload(state, space_payload)
            restored = True
        except Exception:
            traceback.print_exc()
    return restored


def split_preview_lines(text, limit=6, width=64):
    if not text:
        return []

    max_lines = max(1, int(limit or 1))
    max_width = max(12, int(width or 64))
    lines = []
    for raw_line in str(text).splitlines():
        if len(lines) >= max_lines:
            break
        line = raw_line or " "
        while len(line) > max_width and len(lines) < max_lines:
            lines.append(line[:max_width])
            line = line[max_width:]
        if len(lines) < max_lines:
            lines.append(line)

    return lines


def image_preview_cache_signature(image):
    filepath = str(getattr(image, "filepath", "") or "").strip()
    if filepath:
        try:
            normalized = os.path.normcase(os.path.abspath(filepath))
        except Exception:
            normalized = filepath
        return normalized, (0, 0)
    name = str(getattr(image, "name_full", "") or getattr(image, "name", "") or "")
    return f"memory::{name}", (0, 0)


def cached_image_preview_icon_id(image):
    if image is None:
        return 0
    cache_key, signature = image_preview_cache_signature(image)
    cached = IMAGE_PREVIEW_ICON_CACHE.get(cache_key)
    image_name = str(getattr(image, "name", "") or "")
    image_ptr = 0
    try:
        image_ptr = int(image.as_pointer())
    except Exception:
        image_ptr = 0
    if (
        isinstance(cached, dict)
        and cached.get("signature") == signature
        and cached.get("image_name") == image_name
        and int(cached.get("image_ptr", 0) or 0) == image_ptr
        and int(cached.get("icon_id", 0) or 0) > 0
    ):
        return int(cached.get("icon_id", 0) or 0)
    preview_ensure = getattr(image, "preview_ensure", None)
    if callable(preview_ensure):
        preview_ensure()
    preview = getattr(image, "preview", None)
    icon_id = int(getattr(preview, "icon_id", 0) or 0) if preview is not None else 0
    if icon_id > 0:
        IMAGE_PREVIEW_ICON_CACHE[cache_key] = {
            "signature": signature,
            "image_name": image_name,
            "image_ptr": image_ptr,
            "icon_id": icon_id,
        }
    return icon_id


def draw_folded_text_block(layout, owner, prop_name, title, text, icon="INFO", expanded_limit=6, width=64):
    value = str(text or "").strip()
    if not value:
        return False
    expanded = bool(getattr(owner, prop_name, False)) if owner is not None and hasattr(owner, prop_name) else False
    header = layout.row(align=True)
    if owner is not None and hasattr(owner, prop_name):
        header.prop(
            owner,
            prop_name,
            text="",
            icon="TRIA_DOWN" if expanded else "TRIA_RIGHT",
            emboss=False,
            toggle=True,
        )
    else:
        header.label(text="", icon="TRIA_DOWN" if expanded else "TRIA_RIGHT")
    header.label(text=title, icon=icon)
    limit = expanded_limit if expanded else 1
    for line in split_preview_lines(value, limit=limit, width=width):
        layout.label(text=line)
    return expanded


def compact_inline_text(text, max_chars=UI_LABEL_MAX_CHARS, fallback=""):
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    if not value:
        return fallback
    return value


def compact_multiline_text(text, max_chars, max_lines=None):
    value = str(text or "").strip()
    if not value:
        return ""
    return value


def runtime_numeric_prop_kwargs(**kwargs):
    result = {}
    alias_map = {
        "min": "min",
        "max": "max",
        "soft_min": "soft_min",
        "soft_max": "soft_max",
        "step": "step",
        "precision": "precision",
        "slider": "slider",
    }
    for source_key, target_key in alias_map.items():
        if source_key in kwargs and kwargs[source_key] is not None:
            result[target_key] = kwargs[source_key]
    return result


def finalize_ai_doc(lines):
    text = "\n".join(str(line) for line in lines).strip()
    return text


def module_script_abspath(module):
    raw_path = (module.script_path or "").strip()
    if not raw_path:
        return ""
    return bpy.path.abspath(raw_path)


def legacy_default_module_script_path(workflow_name, module_name):
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bworkflow_modules")
    filename = f"{safe_filename_component(workflow_name, 'workflow')}_{safe_filename_component(module_name, 'module')}.py"
    return os.path.join(base_dir, filename)


def slugify_filename(text, fallback="module"):
    value = re.sub(r"[^0-9A-Za-z_\-]+", "_", text or "")
    value = value.strip("_")
    return value or fallback


WINDOWS_RESERVED_FILENAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}


def safe_filename_component(text, fallback="module", max_length=72):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", text or "")
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"_+", "_", value).strip("._ ")
    if not value:
        value = fallback
    if value.upper() in WINDOWS_RESERVED_FILENAMES:
        value = f"{value}_file"
    return value[:max_length].rstrip("._ ") or fallback


def default_module_scripts_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "go_workflow_modules")


def preset_import_assets_dir():
    return os.path.join(default_module_scripts_dir(), "_imported_presets")


def _same_text_file(filepath, text):
    try:
        with open(filepath, "r", encoding="utf-8") as handle:
            return handle.read() == text
    except Exception:
        return False


def write_preset_import_text_asset(workflow, module_name, suffix, content, extension):
    text = str(content or "").lstrip("\ufeff")
    if not text:
        return ""
    folder = preset_import_assets_dir()
    os.makedirs(folder, exist_ok=True)
    module_part = safe_filename_component(module_name or "module", "module")
    suffix_part = safe_filename_component(suffix or "asset", "asset")
    digest = hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]
    extension = extension.lstrip(".")
    cache_key = (normalized_abs_path(folder), digest, extension)
    cached_path = IMPORTED_PRESET_ASSET_PATH_CACHE.get(cache_key, "")
    if cached_path and os.path.isfile(cached_path):
        return cached_path

    # The readable filename prefix is not the asset identity. Reuse an
    # existing file with the same content even when an imported module has a
    # different unique name.
    try:
        for entry in os.scandir(folder):
            if entry.is_file() and entry.name.endswith(f"_{digest}.{extension}"):
                IMPORTED_PRESET_ASSET_PATH_CACHE[cache_key] = entry.path
                return entry.path
    except OSError:
        pass

    filepath = os.path.join(folder, f"{module_part}_{suffix_part}_{digest}.{extension}")
    if os.path.exists(filepath) and _same_text_file(filepath, text):
        IMPORTED_PRESET_ASSET_PATH_CACHE[cache_key] = filepath
        return filepath
    base, ext = os.path.splitext(filepath)
    counter = 2
    while os.path.exists(filepath):
        if _same_text_file(filepath, text):
            IMPORTED_PRESET_ASSET_PATH_CACHE[cache_key] = filepath
            return filepath
        filepath = f"{base}_{counter}{ext}"
        counter += 1
    with open(filepath, "w", encoding="utf-8") as handle:
        handle.write(text)
    IMPORTED_PRESET_ASSET_PATH_CACHE[cache_key] = filepath
    return filepath


def import_asset_note(label, filepath):
    if not filepath:
        return ""
    basename = os.path.basename(filepath)
    note = f"{label}: {basename}"
    return coerce_text_value(note, max_chars=MAX_PRESET_IMPORT_RNA_TEXT_CHARS)


def _import_asset_note_basename(value):
    text = str(value or "").strip()
    if not text or ":" not in text:
        return ""
    label, basename = text.split(":", 1)
    if not label.strip().startswith("external_"):
        return ""
    return os.path.basename(basename.strip())


def referenced_imported_preset_asset_names(scene=None):
    target_scene = scene or safe_context_scene()
    folder = normalized_abs_path(preset_import_assets_dir())
    names = set()
    if target_scene is None or not folder:
        return names
    for space_type in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=space_type)
        if state is None:
            continue
        containers = list(getattr(state, "script_library", []))
        for workflow in getattr(state, "workflows", []):
            containers.extend(list(getattr(workflow, "modules", [])))
        for item in containers:
            script_path = str(getattr(item, "script_path", "") or "").strip()
            if script_path and normalized_abs_path(os.path.dirname(bpy.path.abspath(script_path))) == folder:
                names.add(os.path.basename(script_path))
            for attr_name in ("config_payload", "ai_doc"):
                basename = _import_asset_note_basename(getattr(item, attr_name, ""))
                if basename:
                    names.add(basename)
    return names


def prune_unreferenced_imported_preset_assets(scene=None, max_delete=80):
    folder = preset_import_assets_dir()
    if not os.path.isdir(folder):
        return 0
    referenced = referenced_imported_preset_asset_names(scene=scene)
    removed = 0
    for entry in sorted(os.scandir(folder), key=lambda item: getattr(item.stat(), "st_mtime", 0.0)):
        if removed >= max(0, int(max_delete or 0)):
            break
        try:
            if not entry.is_file():
                continue
            if entry.name in referenced:
                continue
            os.remove(entry.path)
            removed += 1
        except Exception:
            traceback.print_exc()
    return removed


def schedule_imported_preset_asset_prune(scene=None, delay=0.75):
    target_scene = scene or safe_context_scene()
    scene_name = getattr(target_scene, "name", "") if target_scene is not None else ""
    if not scene_name or scene_name in IMPORTED_PRESET_PRUNE_PENDING_SCENES:
        return False
    IMPORTED_PRESET_PRUNE_PENDING_SCENES.add(scene_name)

    def _prune_once(name=scene_name):
        IMPORTED_PRESET_PRUNE_PENDING_SCENES.discard(name)
        scene_ref = bpy.data.scenes.get(name)
        if scene_ref is None:
            return None
        try:
            prune_unreferenced_imported_preset_assets(scene=scene_ref, max_delete=80)
        except Exception:
            traceback.print_exc()
        return None

    try:
        _register_one_shot_timer(_prune_once, first_interval=max(0.1, float(delay)))
        return True
    except Exception:
        IMPORTED_PRESET_PRUNE_PENDING_SCENES.discard(scene_name)
        return False


def project_root_dir():
    return os.path.dirname(default_module_scripts_dir())


def builtin_special_presets_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "special_presets")


def module_prefers_collapsed_runtime_panel(module_or_data):
    if module_or_data is None:
        return False
    if isinstance(module_or_data, dict):
        script_path = str(module_or_data.get("script_path", "") or "")
        text_block_name = str(module_or_data.get("text_block_name", "") or "")
        panel_title = str(module_or_data.get("panel_title", "") or module_or_data.get("name", "") or "")
    else:
        script_path = str(getattr(module_or_data, "script_path", "") or "")
        text_block_name = str(getattr(module_or_data, "text_block_name", "") or "")
        panel_title = str(getattr(module_or_data, "panel_title", "") or getattr(module_or_data, "name", "") or "")
    script_name = os.path.basename(script_path).casefold()
    text_name = os.path.basename(text_block_name).casefold()
    title_name = panel_title.casefold()
    return (
        script_name == "arkit形态键工作流参考.py".casefold()
        or text_name == "arkit形态键工作流参考.py".casefold()
        or "arkit 形态键工作流参考".casefold() in title_name
    )


BUILTIN_SCRIPT_LIBRARY_TAG = "go_workflow_builtin"
BUILTIN_ARKIT_SYNTHESIS_SCRIPT_NAMES = (
    "ARKit 合成 VRM 基础形态键 - 常规",
    "ARKit 合成 VRM 基础形态键 - 激进",
    "ARKit 合成 MMD 可构成形态键 - 常规",
    "ARKit 合成 MMD 可构成形态键 - 激进",
)


def builtin_scripts_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "builtin_scripts")


def builtin_script_library_manifest_path():
    return os.path.join(builtin_scripts_dir(), "library_manifest.json")


def _file_cache_signature(filepath):
    try:
        stat = os.stat(filepath)
    except OSError:
        return None
    return (int(getattr(stat, "st_mtime_ns", 0)), int(getattr(stat, "st_size", 0)))


def read_cached_text_file(filepath, encodings=("utf-8", "utf-8-sig", "gb18030"), errors=None):
    normalized = os.path.normcase(os.path.abspath(filepath))
    signature = _file_cache_signature(normalized)
    if signature is None:
        raise FileNotFoundError(normalized)
    cached = FILE_TEXT_CACHE.get(normalized)
    if cached is not None and cached.get("signature") == signature:
        return cached.get("data", "")
    last_error = None
    for encoding in encodings:
        try:
            with open(normalized, "r", encoding=encoding, errors=errors) as handle:
                data = handle.read()
            if isinstance(data, str) and data.startswith("\ufeff"):
                data = data.lstrip("\ufeff")
            FILE_TEXT_CACHE[normalized] = {"signature": signature, "data": data}
            return data
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
    if last_error is not None:
        raise last_error
    with open(normalized, "r", encoding="utf-8", errors=errors) as handle:
        data = handle.read()
    if isinstance(data, str) and data.startswith("\ufeff"):
        data = data.lstrip("\ufeff")
    FILE_TEXT_CACHE[normalized] = {"signature": signature, "data": data}
    return data


def read_cached_json_file(filepath, max_bytes=None):
    normalized = os.path.normcase(os.path.abspath(filepath))
    signature = _file_cache_signature(normalized)
    if signature is None:
        raise FileNotFoundError(normalized)
    if max_bytes is not None and signature[1] > max_bytes:
        raise ValueError(f"文件过大，已拒绝读取: {signature[1] / (1024 * 1024):.1f} MB")
    cached = FILE_JSON_CACHE.get(normalized)
    if cached is not None and cached.get("signature") == signature:
        return cached.get("data")
    payload = json.loads(read_cached_text_file(normalized, encodings=("utf-8", "utf-8-sig")))
    FILE_JSON_CACHE[normalized] = {"signature": signature, "data": payload}
    return payload


def builtin_script_library_payloads():
    manifest_path = builtin_script_library_manifest_path()
    if not os.path.isfile(manifest_path):
        return []
    manifest_signature = _file_cache_signature(manifest_path)
    if manifest_signature is None:
        return []
    try:
        entries = read_cached_json_file(manifest_path)
    except Exception:
        traceback.print_exc()
        return []
    if not isinstance(entries, list):
        return []

    base_dir = builtin_scripts_dir()
    file_signatures = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        script_name = (entry.get("script_file", "") or "").strip()
        script_file = os.path.join(base_dir, script_name) if script_name else ""
        file_signatures.append((script_name, _file_cache_signature(script_file) if script_file else None))
    cache_signature = (manifest_signature, tuple(file_signatures))
    cached_payloads = BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE.get("payloads", [])
    if BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE.get("signature") == cache_signature:
        return [dict(payload) for payload in cached_payloads]

    payloads = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        script_name = (entry.get("script_file", "") or "").strip()
        script_file = os.path.join(base_dir, script_name) if script_name else ""
        source = ""
        if script_file and os.path.isfile(script_file):
            try:
                source = read_cached_text_file(script_file)
            except Exception:
                traceback.print_exc()
                continue

        replacements = entry.get("replace", {})
        if isinstance(replacements, dict):
            for old, new in replacements.items():
                source = source.replace(str(old), str(new))

        payload = sanitize_script_library_payload(
            {
                "name": entry.get("name", ""),
                "description": entry.get("description", ""),
                "tags": entry.get("tags", BUILTIN_SCRIPT_LIBRARY_TAG),
                "use_custom_panel": bool(entry.get("use_custom_panel", False)),
                "panel_title": entry.get("panel_title", ""),
                "panel_description": entry.get("panel_description", ""),
                "script_path": script_file if entry.get("script_path_mode") == "builtin" else "",
                "text_block_name": "",
                "script_source": source,
                "config_payload": entry.get("config_payload", ""),
                "ai_doc": entry.get("ai_doc", ""),
            }
        )
        if payload is not None:
            tags = payload.get("tags", "")
            if BUILTIN_SCRIPT_LIBRARY_TAG not in {tag.strip() for tag in tags.split(",")}:
                payload["tags"] = f"{tags},{BUILTIN_SCRIPT_LIBRARY_TAG}" if tags else BUILTIN_SCRIPT_LIBRARY_TAG
            payloads.append(payload)
    BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE["signature"] = cache_signature
    BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE["payloads"] = [dict(payload) for payload in payloads]
    return [dict(payload) for payload in payloads]


def builtin_script_library_payload_by_name(name):
    target = (name or "").strip()
    if not target:
        return None
    for payload in builtin_script_library_payloads():
        if payload.get("name", "") == target:
            return payload
    return None


def script_library_item_has_builtin_tag(item):
    tags = getattr(item, "tags", "") if item is not None else ""
    return BUILTIN_SCRIPT_LIBRARY_TAG in {tag.strip() for tag in (tags or "").split(",")}


def ensure_builtin_script_library(state):
    if state is None:
        return False
    changed = False
    legacy_arkit_names = set()
    current_arkit_names = {payload.get("name", "") for payload in builtin_script_library_payloads()}
    for index in range(len(getattr(state, "script_library", [])) - 1, -1, -1):
        item = state.script_library[index]
        if not script_library_item_has_builtin_tag(item):
            continue
        item_name = getattr(item, "name", "")
        if item_name in legacy_arkit_names and item_name not in current_arkit_names:
            state.script_library.remove(index)
            changed = True
    for payload in builtin_script_library_payloads():
        payload_name = payload.get("name", "")
        item = None
        for candidate in getattr(state, "script_library", []):
            if getattr(candidate, "name", "") == payload_name and script_library_item_has_builtin_tag(candidate):
                item = candidate
                break
        if item is None:
            item = state.script_library.add()
            safe_set_rna_text(
                item,
                "name",
                unique_script_library_name(state, payload_name, exclude_index=len(state.script_library) - 1),
                fallback="Builtin Script",
                max_chars=MAX_RESTORED_PANEL_TEXT_CHARS,
            )
            changed = True

        for attr in (
            "description",
            "tags",
            "use_custom_panel",
            "panel_title",
            "panel_description",
            "script_path",
            "text_block_name",
            "script_source",
            "config_payload",
            "ai_doc",
        ):
            value = payload.get(attr, "")
            if attr == "use_custom_panel":
                value = bool(value)
            if getattr(item, attr) != value:
                if isinstance(value, str):
                    safe_set_rna_text(
                        item,
                        attr,
                        value,
                        max_chars=MAX_RNA_SCRIPT_CHARS if attr == "script_source" else MAX_RNA_TEXT_CHARS if attr in {"config_payload", "ai_doc"} else MAX_RNA_SHORT_TEXT_CHARS,
                    )
                else:
                    setattr(item, attr, value)
                changed = True
    return changed


def special_preset_spec(preset_type):
    if preset_type == SPECIAL_PRESET_ARKIT_52:
        return {
            "preset_type": SPECIAL_PRESET_ARKIT_52,
            "preset_name": "arkit形态键工作流参考",
            "workflow_name": "arkit形态键工作流参考",
            "workflow_description": "用于逐步检查 ARKit / Perfect Sync 52 个表情形态键，支持自动置 1、进入编辑模式与打开参考图。",
            "module_name": "arkit形态键工作流参考",
            "module_description": "按步骤切换 ARKit 52 参考形态键，自动归零其它参考键，并显示当前步骤的注意重点与技巧。",
            "data_file": os.path.join(builtin_special_presets_dir(), "arkit形态键工作流参考.json"),
            "script_file": os.path.join(builtin_special_presets_dir(), "arkit形态键工作流参考.py"),
            "image_folder": os.path.join(builtin_special_presets_dir(), "arkit形态键工作流参考_images"),
            "viewer_script": os.path.join(builtin_special_presets_dir(), "arkit_reference_viewer.ps1"),
            "extra_script_library_names": ("ARKit 形态键合成", "口型生成（Go Workflow 面板版）", "形态键鉴定"),
        }
    return None


def apply_special_preset_to_module(workflow, module, spec):
    if workflow is None or module is None or not isinstance(spec, dict):
        return False
    spec = dict(spec)
    for key in ("module_name", "preset_name"):
        spec[key] = coerce_rna_restore_text(spec.get(key, ""), max_chars=MAX_RESTORED_PANEL_TEXT_CHARS)
    for key in ("workflow_description", "module_description"):
        spec[key] = coerce_rna_restore_text(spec.get(key, ""), max_chars=MAX_RNA_SHORT_TEXT_CHARS)
    module.name = spec.get("module_name", module.name or "特殊预设模块")
    module.enabled = True
    module.use_custom_panel = True
    module.runtime_panel_expanded = False
    module.runtime_description_expanded = False
    module.panel_title = spec.get("preset_name", module.name)
    module.panel_description = spec.get("workflow_description", "")
    module.description = spec.get("module_description", "")
    script_file = spec.get("script_file", "")
    if script_file:
        script_file = coerce_rna_restore_text(script_file, max_chars=MAX_RNA_SHORT_TEXT_CHARS)
        module.script_path = script_file
        try:
            if os.path.isfile(script_file):
                module.script_source = coerce_rna_restore_text(
                    read_cached_text_file(script_file),
                    max_chars=MAX_RNA_SCRIPT_CHARS,
                )
        except Exception:
            traceback.print_exc()
    return True


def apply_module_payload_to_existing_module(module, module_data):
    if module is None or not isinstance(module_data, dict):
        return False
    changed = False
    updates = (
        ("name", normalize_workflow_name(module_data.get("name", ""), getattr(module, "name", "") or "模块")),
        ("enabled", bool(module_data.get("enabled", True))),
        ("use_custom_panel", bool(module_data.get("use_custom_panel", False))),
        ("runtime_panel_expanded", bool(module_data.get("runtime_panel_expanded", not module_prefers_collapsed_runtime_panel(module_data)))),
        ("runtime_description_expanded", bool(module_data.get("runtime_description_expanded", False))),
        ("panel_title", normalize_text_value(module_data.get("panel_title", ""), "")),
        ("panel_description", normalize_text_value(module_data.get("panel_description", ""), "")),
        ("script_path", module_data.get("script_path", "")),
        ("description", normalize_text_value(module_data.get("description", ""), "")),
        ("text_block_name", normalize_text_value(module_data.get("text_block_name", ""), "")),
        ("script_source", module_data.get("script_source", "")),
        ("config_payload", module_data.get("config_payload", "")),
        ("ai_doc", module_data.get("ai_doc", "")),
    )
    for attr, value in updates:
        if getattr(module, attr) != value:
            if isinstance(value, str):
                safe_set_rna_text(
                    module,
                    attr,
                    value,
                    max_chars=MAX_RNA_SCRIPT_CHARS if attr == "script_source" else MAX_RNA_TEXT_CHARS if attr in {"config_payload", "ai_doc"} else MAX_RNA_SHORT_TEXT_CHARS,
                )
            else:
                setattr(module, attr, value)
            changed = True
    return changed


def refresh_builtin_workflow_modules(state):
    if state is None:
        return 0
    changed = 0
    special_spec = special_preset_spec(SPECIAL_PRESET_ARKIT_52)
    builtin_payloads = {payload.get("name", ""): payload for payload in builtin_script_library_payloads()}
    builtin_panel_titles = {
        (payload.get("panel_title", "") or "").strip(): payload
        for payload in builtin_script_library_payloads()
        if (payload.get("panel_title", "") or "").strip()
    }
    preset_script_name = os.path.basename(special_spec.get("script_file", "")) if special_spec else ""
    for workflow in getattr(state, "workflows", []):
        workflow_has_special_preset = False
        existing_module_names = set()
        for module in getattr(workflow, "modules", []):
            module_name = getattr(module, "name", "") or ""
            if module_name:
                existing_module_names.add(module_name)
            panel_title = getattr(module, "panel_title", "") or ""
            script_name = os.path.basename((getattr(module, "script_path", "") or "").strip())
            if special_spec and (
                module_name == special_spec.get("module_name", "")
                or panel_title == special_spec.get("preset_name", "")
                or (preset_script_name and script_name == preset_script_name)
            ):
                workflow_has_special_preset = True
                before = (
                    getattr(module, "script_path", ""),
                    getattr(module, "script_source", ""),
                    getattr(module, "config_payload", ""),
                    getattr(module, "panel_title", ""),
                    getattr(module, "panel_description", ""),
                    getattr(module, "description", ""),
                    getattr(module, "use_custom_panel", False),
                    getattr(module, "runtime_panel_expanded", True),
                    getattr(module, "runtime_description_expanded", False),
                )
                apply_special_preset_to_module(workflow, module, special_spec)
                module.runtime_panel_expanded = False
                module.runtime_description_expanded = False
                after = (
                    getattr(module, "script_path", ""),
                    getattr(module, "script_source", ""),
                    getattr(module, "config_payload", ""),
                    getattr(module, "panel_title", ""),
                    getattr(module, "panel_description", ""),
                    getattr(module, "description", ""),
                    getattr(module, "use_custom_panel", False),
                    getattr(module, "runtime_panel_expanded", True),
                    getattr(module, "runtime_description_expanded", False),
                )
                if before != after:
                    changed += 1
                continue
            payload = builtin_payloads.get(module_name)
            if payload is None:
                payload = builtin_panel_titles.get((panel_title or "").strip())
            if payload is None:
                continue
            payload_data = dict(payload)
            payload_data["enabled"] = getattr(module, "enabled", True)
            payload_data["runtime_panel_expanded"] = False
            payload_data["runtime_description_expanded"] = False
            if apply_module_payload_to_existing_module(module, payload_data):
                changed += 1
        if workflow_has_special_preset and special_spec:
            for script_name in special_spec.get("extra_script_library_names", []):
                if script_name in existing_module_names:
                    continue
                payload = builtin_payloads.get(script_name)
                if payload is None:
                    continue
                module_data = dict(payload)
                module_data["enabled"] = True
                module_data["runtime_panel_expanded"] = False
                module_data["runtime_description_expanded"] = False
                apply_module_payload_to_workflow(workflow, module_data)
                existing_module_names.add(script_name)
                changed += 1
    return changed


def create_special_preset_workflow(scene, preset_type):
    spec = special_preset_spec(preset_type)
    if spec is None:
        return []
    created = create_synced_workflow_for_all_spaces(scene, spec.get("workflow_name", "特殊预设"))
    if not created:
        return []
    for _space_type, workflow in created:
        workflow.description = spec.get("workflow_description", "")
        module = workflow.modules.add()
        apply_special_preset_to_module(workflow, module, spec)
        for script_name in spec.get("extra_script_library_names", []):
            payload = builtin_script_library_payload_by_name(script_name)
            if payload is None:
                continue
            module_data = dict(payload)
            module_data["enabled"] = True
            module_data["runtime_panel_expanded"] = False
            module_data["runtime_description_expanded"] = False
            apply_module_payload_to_workflow(workflow, module_data)
        workflow.active_module_index = 0
    return created


def default_module_script_path(workflow_name, module_name):
    filename = f"{safe_filename_component(workflow_name, 'workflow')}_{safe_filename_component(module_name, 'module')}.py"
    return os.path.join(default_module_scripts_dir(), filename)


def normalized_abs_path(path):
    if not path:
        return ""
    return os.path.normcase(os.path.normpath(bpy.path.abspath(path)))


def is_default_module_script_path(path):
    normalized = normalized_abs_path(path)
    if not normalized:
        return False
    default_dir = normalized_abs_path(default_module_scripts_dir())
    legacy_dir = normalized_abs_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "bworkflow_modules"))
    return os.path.dirname(normalized) in {default_dir, legacy_dir}


def workflow_module_index(workflow, module):
    try:
        for index, item in enumerate(getattr(workflow, "modules", [])):
            if item == module:
                return index
    except Exception:
        pass
    return -1


def unique_default_module_script_path(workflow, module):
    workflow_name = getattr(workflow, "name", "") or "workflow"
    module_name = getattr(module, "name", "") or "module"
    base_name = f"{safe_filename_component(workflow_name, 'workflow')}_{safe_filename_component(module_name, 'module')}"
    base_dir = default_module_scripts_dir()
    used_paths = set()
    for item in getattr(workflow, "modules", []):
        if item == module:
            continue
        used_paths.add(normalized_abs_path(getattr(item, "script_path", "")))

    suffix = 1
    while True:
        suffix_text = "" if suffix == 1 else f"_{suffix}"
        candidate = os.path.join(base_dir, f"{base_name}{suffix_text}.py")
        if normalized_abs_path(candidate) not in used_paths:
            return candidate
        suffix += 1


def module_script_path_conflicts(workflow, module, filepath):
    target = normalized_abs_path(filepath)
    if not target:
        return False
    for item in getattr(workflow, "modules", []):
        if item == module:
            continue
        if normalized_abs_path(getattr(item, "script_path", "")) == target:
            return True
    return False


def ensure_module_script_path_matches_name(workflow, module, force=False):
    current_path = (getattr(module, "script_path", "") or "").strip()
    should_generate = force or not current_path or is_default_module_script_path(current_path)
    if current_path and module_script_path_conflicts(workflow, module, current_path):
        should_generate = True
    if should_generate:
        module.script_path = unique_default_module_script_path(workflow, module)
    return module.script_path


def normalize_module_script_path(workflow, module):
    raw_path = (module.script_path or "").strip()
    if not raw_path:
        module.script_path = unique_default_module_script_path(workflow, module)
        return

    absolute_path = bpy.path.abspath(raw_path)
    legacy_path = legacy_default_module_script_path(workflow.name, module.name)
    if normalized_abs_path(absolute_path) == normalized_abs_path(legacy_path):
        module.script_path = unique_default_module_script_path(workflow, module)


def build_module_ai_doc(workflow, module):
    script_path = module.script_path or unique_default_module_script_path(workflow, module)
    needs_panel = bool(getattr(module, "use_custom_panel", False))
    module_description = compact_multiline_text(
        getattr(module, "description", ""),
        AI_DOC_DESCRIPTION_MAX_CHARS,
        max_lines=12,
    ) or "请根据模块名称和用户补充说明生成具体功能。"
    panel_description = compact_multiline_text(
        getattr(module, "panel_description", ""),
        AI_DOC_DESCRIPTION_MAX_CHARS,
        max_lines=10,
    )
    current_ai_doc = compact_multiline_text(
        getattr(module, "ai_doc", ""),
        AI_DOC_DESCRIPTION_MAX_CHARS * 2,
        max_lines=40,
    )
    has_specific_ai_doc = bool(current_ai_doc) and "Go Workflow 自定义脚本 AI 开发文档" not in current_ai_doc

    lines = [
        "# Go Workflow 自定义脚本 AI 开发文档",
        f"- 模块名称: {module.name}",
        f"- 所属工作流: {workflow.name}",
        f"- 目标 .py 路径: {script_path}",
        f"- 启用自定义脚本面板: {'是' if needs_panel else '否'}",
        "",
        "模块目标:",
        module_description,
    ]
    if panel_description:
        lines.extend(["", "面板目标:", panel_description])
    if has_specific_ai_doc:
        lines.extend(["", "用户补充 AI 说明:", current_ai_doc])

    lines.extend(
        [
            "",
            "必须遵守的脚本接口:",
            "1. 必须定义 run(context, scene, workflow, module)，点击模块运行按钮时调用。",
            "2. 可选定义 draw_panel(layout, context, scene, workflow, module, panel_api, module_state)，只绘制本模块 UI。",
            "3. 可选定义 on_panel_action(action, context, scene, workflow, module, panel_api, module_state)，处理自定义按钮。",
            "4. 成功返回 {'FINISHED'}；用户条件不满足时 raise Exception('给用户看的中文原因') 或返回 {'CANCELLED'}。",
            "5. 不要在导入脚本时执行真实操作；所有写入、导出、删除、bpy.ops 调用放到 run 或 on_panel_action。",
            "",
            "运行环境:",
            "- 脚本全局可直接访问 bpy、context、scene、workflow、module、panel_api、module_state。",
            "- module_state 是当前模块的轻量持久状态字典，适合保存 last_result、debug_log、临时统计和按钮结果。",
            "- module_state 支持 dict 风格访问: module_state['key']、'key' in module_state、len(module_state)、keys/items/values/copy/as_dict/to_dict。",
            "- module_state 支持 get/set/pop/update/clear/append_log，也支持 get_text/get_bool/get_float/get_int/get_enum 与 set_text/set_bool/set_float/set_int/set_enum。",
            "- 用户可编辑参数优先用 panel_api 的 draw_* 与 get_*；运行结果、预览结果、缓存状态优先用 module_state。",
            "- module.config_payload 可保存模块配置，适合 csv/json/列表等可序列化数据。",
            "- draw_panel 绘制期间由 Go Workflow 嵌入到模块区域，不需要注册新的 bpy.types.Panel。",
            "",
            "开发规则:",
            "- 优先使用 Blender 数据 API，例如 bpy.data、对象属性、Modifier/Material/Collection API。",
            "- 必须先校验对象、模式、选择、路径、用户输入；错误提示写清楚用户该怎么修正。",
            "- 批量处理时跳过不适用对象，必要时统计 processed/skipped。",
            "- 不要自动删除用户数据；覆盖、删除、写文件前提供 overwrite/delete_source/confirm 等明确开关。",
            "- draw_panel 只负责 UI 和轻量读取，不创建物体、不切模式、不写文件、不执行耗时扫描。",
            "- 需要 bpy.ops 时先检查 context/mode/active_object，能用数据 API 替代就不要用 bpy.ops。",
            "- 状态提示优先写 module_state.set('last_result', text)，也可用 panel_api.set_status(text)。",
            "",
            "基础脚本骨架:",
            "```python",
            "import bpy",
            "",
            "def _selected(context):",
            "    return list(getattr(context, 'selected_objects', []) or [])",
            "",
            "def _validate(context, scene, workflow, module):",
            "    items = _selected(context)",
            "    if not items:",
            "        raise Exception('请先选择要处理的对象')",
            "    return items",
            "",
            "def run(context, scene, workflow, module):",
            "    items = _validate(context, scene, workflow, module)",
            "    processed = 0",
            "    skipped = 0",
            "    for obj in items:",
            "        if obj is None:",
            "            skipped += 1",
            "            continue",
            "        # TODO: 在这里实现模块功能。",
            "        processed += 1",
            "    module_state.set('last_result', f'已检查 {len(items)} 项，处理 {processed} 项，跳过 {skipped} 项')",
            "    return {'FINISHED'}",
            "```",
        ]
    )
    if needs_panel:
        lines.extend(
            [
                "",
                "自定义脚本面板接口:",
                "- draw_panel 的 layout 是 Blender 原生 UILayout，可直接使用 layout.box/row/column/split/prop/operator/template_list 等。",
                "- 不要注册新的 bpy.types.Panel；Go Workflow 会把 draw_panel 嵌入当前模块区域。",
                "- 优先使用原生 layout.* 组织 UI；panel_api 只作为字段持久化、按钮路由、状态块等辅助。",
                "- on_panel_action 接收 panel_api.draw_button 或原生 bworkflow.module_runtime_action 触发的 action。",
                "- draw_run_button 或 bworkflow.module_run 会调用 run(context, scene, workflow, module)。",
                "- FIELD_WRITE:: 开头的 action 是字段写入回调，通常直接 return {'FINISHED'}。",
                "- 参数字段 key 使用英文，例如 target_object、strength、sample_index；中文只用于 UI label。",
                "- 原生 layout.prop 需要可绑定的数据源，普通运行时参数建议用 panel_api.draw_runtime_prop。",
                "",
                "优先使用的 Blender 原生 UI:",
                "- 布局: layout.box(), layout.row(align=True), layout.column(align=True), layout.split(factor=0.35), layout.separator()。",
                "- 文本: layout.label(text='状态', icon='INFO')。",
                "- 属性: row.prop(data, 'prop_name', text='名称'), row.prop(scene, '[\"custom_key\"]', text='参数'), row.prop_menu_enum(data, 'enum_prop')。",
                "- 搜索: row.prop_search(data, 'object_name', bpy.data, 'objects', text='目标')。",
                "- 操作: row.operator('bworkflow.module_runtime_action', text='预览', icon='VIEWZOOM'), row.operator_menu_enum(...), row.operator_enum(...)。",
                "- 菜单/弹窗: layout.menu(...), layout.menu_contents(...), layout.popover(...)。",
                "- 模板: layout.template_list(...), layout.template_ID(...), layout.template_ID_preview(...), layout.template_search(...), layout.template_icon(...), layout.template_icon_view(...), layout.template_color_picker(...), layout.template_curve_mapping(...), layout.template_preview(...)。",
                "",
                "形态键/Shape Key 必须遵守:",
                "- 活动形态键索引在 Object 上: obj.active_shape_key_index；不要写 obj.data.shape_keys.active_index，Key 数据块没有 active_index。",
                "- 形态键列表在 obj.data.shape_keys.key_blocks；Basis 通常是索引 0，处理非 Basis 时要求 active_shape_key_index > 0。",
                "- 安全访问示例: key_data = getattr(obj.data, 'shape_keys', None); key_blocks = getattr(key_data, 'key_blocks', None); index = getattr(obj, 'active_shape_key_index', -1)。",
                "- 推荐直接用 panel_api.active_shape_key(obj, include_basis=False)、panel_api.shape_key_blocks(obj)、panel_api.valid_shape_key_objects(require_active_non_basis=True)。",
                "",
                "panel_api 辅助接口:",
                "- 原生透传: prop、prop_search、prop_menu_enum、prop_enum、operator、operator_menu_enum、operator_enum、menu、menu_contents、popover、context_pointer_set、split、grid_flow、template_list、template_id、template_id_preview、template_search、template_icon、template_icon_view、template_color_picker、template_curve_mapping、template_preview。",
                "- 未显式列出的 Blender UILayout 方法也可用 panel_api.xxx(layout, ...) 透传，例如 panel_api.template_ID(layout, data, 'prop') 会调用 layout.template_ID(data, 'prop')。",
                "- 布局辅助: box、row、column、separator、label、section、foldout_section、set_enabled、set_alert。",
                "- 字段绘制: draw_runtime_prop、draw_scene_prop、draw_text_input_inline、draw_toggle_inline、draw_float_input_inline、draw_int_input_inline、draw_enum。",
                "- 数值字段 draw_float_input/draw_float_input_inline/draw_int_input/draw_int_input_inline 支持 min、max、soft_min、soft_max、step、precision、slider、factor 等常用参数。",
                "- 数据选择: draw_object_picker_inline、draw_active_object_capture、draw_material_picker、draw_collection_picker、draw_text_block_picker、draw_file_path_input。",
                "- 按钮: draw_button、draw_icon_button、draw_run_button。",
                "- 读取: get_text、get_bool、get_float、get_int、get_enum、get_object、get_material、get_collection、get_text_block。",
                "- 写入: set_text、set_bool、set_float、set_int、set_enum、set_object、set_data_block、clear_value。",
                "- 上下文: active_object()、selected_objects(type=None)、visible_objects(type=None)、selected_mesh_objects(require_shape_keys=False)、shape_key_data(obj=None)、shape_key_blocks(obj=None)、active_shape_key_index(obj=None)、active_shape_key(obj=None, include_basis=True)、valid_shape_key_objects(require_active_non_basis=False)、context_summary()。",
                "",
                "module_state 状态接口:",
                "- 基础: module_state.get(key, default=None)、set(key, value)、pop(key, default=None)、update(dict)、clear()、keys()、items()、values()、copy()、as_dict()、to_dict()。",
                "- 字典访问: module_state['last_result'] = text、text = module_state.get('last_result', '')、'last_result' in module_state。",
                "- 类型读取: get_text(key, default='')、get_bool(key, default=False)、get_float(key, default=0.0)、get_int(key, default=0)、get_enum(key, default='')。",
                "- 类型写入: set_text/set_bool/set_float/set_int/set_enum；日志: append_log(message, key='debug_log', max_items=20)。",
                "- 不要把 module_state 当作 UI 绘制器；绘制控件用 layout 或 panel_api。",
                "",
                "推荐自定义面板骨架，原生 layout 优先:",
                "```python",
                "def draw_panel(layout, context, scene, workflow, module, panel_api, module_state):",
                "    box = layout.box()",
                "    box.label(text=module.panel_title or module.name or '参数', icon='TOOL_SETTINGS')",
                "",
                "    col = box.column(align=True)",
                "    panel_api.draw_runtime_prop(col, 'strength', 1.0, kind='float', label='强度', slider=True)",
                "    panel_api.draw_float_input_inline(col, 'duration_seconds', '时长(秒)', default=2.0, factor=0.28, min=0.1, step=0.1, precision=2)",
                "    panel_api.draw_object_picker_inline(col, 'target_object', '目标对象', factor=0.28, show_active_button=True)",
                "    panel_api.draw_file_path_input(col, 'input_file', '输入文件', default='', factor=0.28, filter_glob='*.json;*.txt')",
                "",
                "    key_obj = panel_api.active_object()",
                "    key_block = panel_api.active_shape_key(key_obj, include_basis=False)",
                "    if key_block is not None:",
                "        col.label(text=f'当前非 Basis 形态键: {key_block.name}', icon='SHAPEKEY_DATA')",
                "",
                "    advanced = panel_api.foldout_section(layout, 'show_advanced', '高级', icon='PREFERENCES', default_open=False)",
                "    if advanced is not None:",
                "        panel_api.draw_int_input_inline(advanced, 'sample_index', '样本序号', default=0, factor=0.28)",
                "        panel_api.draw_note(advanced, '高级参数只在需要时展开，避免 N 面板长期绘制大量文本。')",
                "",
                "    status = module_state.get('last_result', '')",
                "    if status:",
                "        status_box = layout.box()",
                "        status_box.label(text=str(status), icon='INFO')",
                "",
                "    row = layout.row(align=True)",
                "    op = row.operator('bworkflow.module_runtime_action', text='预览', icon='VIEWZOOM')",
                "    op.workflow_name = workflow.name",
                "    op.module_name = module.name",
                "    op.action_name = 'preview'",
                "    panel_api.draw_run_button(row, '运行', icon='PLAY')",
                "",
                "def on_panel_action(action, context, scene, workflow, module, panel_api, module_state):",
                "    if action == 'preview':",
                "        items = _selected(context)",
                "        module_state.set('last_result', f'当前选择 {len(items)} 项')",
                "        return {'FINISHED'}",
                "    if action.startswith('FIELD_WRITE::'):",
                "        return {'FINISHED'}",
                "    return {'CANCELLED'}",
                "```",
            ]
        )
    else:
        lines.extend(
            [
                "",
                "当前模块未启用自定义面板:",
                "- 不需要生成 draw_panel。",
                "- 不需要生成 on_panel_action。",
                "- 不要假设存在专属 UI；把主要逻辑放进 run。",
                "- 如果用户之后启用“需要自定义面板”，再补 draw_panel/on_panel_action。",
            ]
        )
    return finalize_ai_doc(lines)


def ensure_module_script_source(workflow, module):
    normalize_module_script_path(workflow, module)
    return module.script_source


def current_module_script_source(workflow, module, prefer_text_block=True, allow_initialize=True):
    if prefer_text_block:
        text_name = module.text_block_name.strip()
        if text_name:
            text_block = bpy.data.texts.get(text_name)
            if text_block is not None:
                return text_block.as_string().lstrip("\ufeff")
    if module.script_source.strip():
        return module.script_source.lstrip("\ufeff")
    if sync_module_source_from_file(module):
        return module.script_source.lstrip("\ufeff")
    if allow_initialize:
        return ensure_module_script_source(workflow, module).lstrip("\ufeff")
    return ""


def module_state_key(module):
    raw_name = (getattr(module, "name", "") or "").strip()
    return slugify_filename(raw_name, "module")


def workflow_state_key(workflow):
    raw_name = (getattr(workflow, "name", "") or "").strip()
    return slugify_filename(raw_name, "workflow")


def module_scene_prop_key(workflow, module, key, kind="value"):
    workflow_key = workflow_state_key(workflow)[:6]
    module_key = module_state_key(module)[:6]
    kind_key = slugify_filename(kind, "value")[:3]
    field_key = slugify_filename(key, "field")[:12]
    digest_source = "|".join(
        [
            workflow_state_key(workflow),
            module_state_key(module),
            str(kind or "value"),
            str(key or ""),
        ]
    )
    digest = hashlib.sha1(digest_source.encode("utf-8", "ignore")).hexdigest()[:8]
    return "_gwf_{workflow_key}_{module_key}_{kind_key}_{field_key}_{digest}".format(
        workflow_key=workflow_key or "workflow",
        module_key=module_key or "module",
        kind_key=kind_key or "val",
        field_key=field_key or "field",
        digest=digest,
    )


def module_scene_prop_key_legacy(workflow, module, key, kind="value"):
    return "_go_workflow_runtime_{workflow_key}_{module_key}_{kind}_{field_key}".format(
        workflow_key=workflow_state_key(workflow),
        module_key=module_state_key(module),
        kind=slugify_filename(kind, "value"),
        field_key=slugify_filename(key, "field"),
    )


def module_scene_prop_key_usable(prop_key):
    return bool(prop_key) and len(str(prop_key)) <= 63


def module_scene_prop_key_candidates(workflow, module, key, kind="value"):
    candidates = []
    for candidate in (
        module_scene_prop_key(workflow, module, key, kind=kind),
        module_scene_prop_key_legacy(workflow, module, key, kind=kind),
    ):
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    return candidates


def module_runtime_specs_key(workflow, module):
    return "_go_workflow_runtime_specs_{workflow_key}_{module_key}".format(
        workflow_key=workflow_state_key(workflow),
        module_key=module_state_key(module),
    )


def is_blender_id_write_context_error(exc):
    return "Writing to ID classes in this context is not allowed" in str(exc or "")


def normalize_module_field_default(kind, default):
    kind = str(kind or "text")
    if kind == "bool":
        return bool(default)
    if kind == "float":
        try:
            return float(default)
        except Exception:
            return 0.0
    if kind == "int":
        try:
            return int(default)
        except Exception:
            return 0
    if kind == "object":
        return str(default or "")
    return str(default or "")


def ensure_module_runtime_store(scene, workflow, module, allow_writes=True):
    if scene is None:
        return {}
    root_key = "_go_workflow_module_state"
    root_store = scene.get(root_key)
    if not isinstance(root_store, dict):
        root_store = {}
    workflow_key = slugify_filename(getattr(workflow, "name", ""), "workflow")
    workflow_store = root_store.get(workflow_key)
    if not isinstance(workflow_store, dict):
        workflow_store = {}
    module_key = module_state_key(module)
    module_store = workflow_store.get(module_key)
    if not isinstance(module_store, dict):
        module_store = {}
    volatile_key = module_runtime_cleanup_cache_key(scene, workflow, module)
    volatile_store = MODULE_RUNTIME_VOLATILE_STORE.get(volatile_key)
    if isinstance(volatile_store, dict):
        merged = dict(module_store)
        merged.update(volatile_store)
        return merged
    return dict(module_store)


def save_module_runtime_store(scene, workflow, module, module_store):
    if scene is None:
        return
    # AI定位：运行状态只写内存缓存，避免状态提示/分析结果进入 Blender 撤回栈。
    MODULE_RUNTIME_VOLATILE_STORE[module_runtime_cleanup_cache_key(scene, workflow, module)] = dict(module_store or {})


def save_module_runtime_specs(scene, workflow, module, field_specs):
    if scene is None:
        return False
    specs_key = module_runtime_specs_key(workflow, module)
    saved = []
    seen = set()
    for spec in field_specs or []:
        key = str(spec.get("key", "")).strip()
        kind = str(spec.get("kind", "text")).strip() or "text"
        if not key:
            continue
        pair = (key, kind)
        if pair in seen:
            continue
        seen.add(pair)
        saved.append(
            {
                "key": key,
                "kind": kind,
                "default": normalize_module_field_default(kind, spec.get("default")),
                "prop_key": module_scene_prop_key(workflow, module, key, kind=kind),
                "legacy_prop_key": module_scene_prop_key_legacy(workflow, module, key, kind=kind),
            }
        )
    try:
        scene[specs_key] = saved
    except RuntimeError as exc:
        if is_blender_id_write_context_error(exc):
            return False
        raise
    return True


def ensure_module_runtime_scene_defaults(scene, workflow, module, field_specs):
    if scene is None:
        return False
    changed = False
    for spec in field_specs or []:
        prop_key = spec.get("prop_key")
        if not prop_key or not module_scene_prop_key_usable(prop_key) or prop_key in scene:
            continue
        try:
            scene[prop_key] = normalize_module_field_default(spec.get("kind", "text"), spec.get("default"))
            changed = True
        except Exception:
            continue
    return changed


def load_module_runtime_specs(scene, workflow, module):
    if scene is None:
        return []
    specs = scene.get(module_runtime_specs_key(workflow, module), [])
    if not isinstance(specs, (list, tuple)):
        return []
    normalized = []
    seen = set()
    for spec in specs:
        if not isinstance(spec, dict):
            continue
        key = str(spec.get("key", "")).strip()
        kind = str(spec.get("kind", "text")).strip() or "text"
        if not key:
            continue
        pair = (key, kind)
        if pair in seen:
            continue
        seen.add(pair)
        normalized.append(
            {
                "key": key,
                "kind": kind,
                "default": normalize_module_field_default(kind, spec.get("default")),
                "prop_key": module_scene_prop_key(workflow, module, key, kind=kind),
                "legacy_prop_key": module_scene_prop_key_legacy(workflow, module, key, kind=kind),
            }
        )
    return normalized


def migrate_module_runtime_scene_values(scene, workflow, module, field_specs):
    if scene is None:
        return False
    changed = False
    for spec in field_specs or []:
        key = spec.get("key")
        kind = spec.get("kind", "text")
        if not key:
            continue
        candidates = module_scene_prop_key_candidates(workflow, module, key, kind=kind)
        if not candidates:
            continue
        primary_key = candidates[0]
        if not module_scene_prop_key_usable(primary_key):
            continue
        if primary_key in scene:
            continue
        fallback_value = None
        found = False
        for candidate in candidates[1:]:
            if module_scene_prop_key_usable(candidate) and candidate in scene:
                fallback_value = scene.get(candidate)
                found = True
                break
        if not found:
            continue
        try:
            scene[primary_key] = fallback_value
            changed = True
        except Exception:
            continue
    return changed


def sync_module_runtime_field_specs(scene, workflow, module, field_specs):
    field_specs = list(field_specs or [])
    if scene is None or workflow is None or module is None or not field_specs:
        return False
    if not save_module_runtime_specs(scene, workflow, module, field_specs):
        queue_module_runtime_field_specs_sync(scene, workflow, module, field_specs)
        return False
    changed = migrate_module_runtime_scene_values(scene, workflow, module, field_specs)
    changed = ensure_module_runtime_scene_defaults(scene, workflow, module, field_specs) or changed
    return changed


def queue_module_runtime_field_specs_sync(scene, workflow, module, field_specs):
    field_specs = list(field_specs or [])
    if scene is None or workflow is None or module is None or not field_specs:
        return False
    cache_key = module_runtime_cleanup_cache_key(scene, workflow, module)
    queued = MODULE_RUNTIME_FIELD_SYNC_QUEUE.get(cache_key)
    if not isinstance(queued, dict):
        queued = {
            "scene_pointer": cache_key[0],
            "workflow_name": getattr(workflow, "name", ""),
            "module_name": getattr(module, "name", ""),
            "field_specs": [],
        }
        MODULE_RUNTIME_FIELD_SYNC_QUEUE[cache_key] = queued
    queued_specs = queued.setdefault("field_specs", [])
    seen = {
        (str(spec.get("key", "")).strip(), str(spec.get("kind", "text")).strip() or "text")
        for spec in queued_specs
        if isinstance(spec, dict)
    }
    for spec in field_specs:
        if not isinstance(spec, dict):
            continue
        key = str(spec.get("key", "")).strip()
        kind = str(spec.get("kind", "text")).strip() or "text"
        if not key or (key, kind) in seen:
            continue
        seen.add((key, kind))
        queued_specs.append(dict(spec))
    schedule_module_runtime_field_specs_sync()
    return True


def resolve_module_runtime_sync_target(payload):
    scene_pointer = str((payload or {}).get("scene_pointer", ""))
    workflow_name = str((payload or {}).get("workflow_name", ""))
    module_name = str((payload or {}).get("module_name", ""))
    for scene in iter_available_scenes():
        try:
            if str(scene.as_pointer()) != scene_pointer:
                continue
        except Exception:
            continue
        for space_type in iter_supported_space_types():
            state = get_state(scene=scene, space_type=space_type)
            if state is None:
                continue
            for workflow in getattr(state, "workflows", ()):
                if getattr(workflow, "name", "") != workflow_name:
                    continue
                for module in getattr(workflow, "modules", ()):
                    if getattr(module, "name", "") == module_name:
                        return scene, workflow, module
    return None, None, None


def drain_module_runtime_field_specs_sync_queue():
    global MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE
    MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = False
    pending = list(MODULE_RUNTIME_FIELD_SYNC_QUEUE.items())
    MODULE_RUNTIME_FIELD_SYNC_QUEUE.clear()
    changed = False
    retry = False
    for cache_key, payload in pending:
        scene, workflow, module = resolve_module_runtime_sync_target(payload)
        field_specs = payload.get("field_specs", []) if isinstance(payload, dict) else []
        if scene is None or workflow is None or module is None:
            continue
        try:
            changed = sync_module_runtime_field_specs(scene, workflow, module, field_specs) or changed
        except RuntimeError as exc:
            if "Writing to ID classes in this context is not allowed" in str(exc):
                MODULE_RUNTIME_FIELD_SYNC_QUEUE[cache_key] = payload
                retry = True
                continue
            traceback.print_exc()
        except Exception:
            traceback.print_exc()
    if changed:
        tag_redraw_all()
    if retry or MODULE_RUNTIME_FIELD_SYNC_QUEUE:
        schedule_module_runtime_field_specs_sync(first_interval=0.25)
    return None


def schedule_module_runtime_field_specs_sync(first_interval=0.1):
    global MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE
    if MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE:
        return False
    MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = True
    try:
        _register_one_shot_timer(drain_module_runtime_field_specs_sync_queue, first_interval=first_interval)
        return True
    except Exception:
        MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = False
        return False


def module_runtime_field_scene_value(scene, workflow, module, key, kind, default=None):
    if scene is None:
        return default, ""
    for prop_key in module_scene_prop_key_candidates(workflow, module, key, kind=kind):
        if not module_scene_prop_key_usable(prop_key):
            continue
        if prop_key in scene:
            return scene.get(prop_key, default), prop_key
    return default, ""


def merge_module_runtime_store(scene, workflow, module, module_store):
    existing = ensure_module_runtime_store(scene, workflow, module, allow_writes=False)
    merged = dict(existing or {})
    merged.update(dict(module_store or {}))
    save_module_runtime_store(scene, workflow, module, merged)
    return merged


class CachedModuleStateProxy:
    __slots__ = ("_data",)

    def __init__(self, initial):
        self._data = dict(initial or {})

    def get(self, key, default=None):
        return self._data.get(key, default)

    def __contains__(self, key):
        return key in self._data

    def __getitem__(self, key):
        return self._data[key]

    def __setitem__(self, key, value):
        self._data[key] = value

    def __delitem__(self, key):
        del self._data[key]

    def __len__(self):
        return len(self._data)

    def values(self):
        return self._data.values()

    def copy(self):
        return dict(self._data)

    def as_dict(self):
        return dict(self._data)

    def set(self, key, value):
        self._data[key] = value
        return value

    def has(self, key):
        return key in self._data

    def get_value(self, key, default=None):
        return self.get(key, default)

    def set_value(self, key, value):
        return self.set(key, value)

    def get_text(self, key, default=""):
        return str(self.get(key, default))

    def set_text(self, key, value):
        return self.set(key, str(value))

    def get_bool(self, key, default=False):
        value = self.get(key, default)
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on", "是", "开", "启用"}
        return bool(value)

    def set_bool(self, key, value):
        return self.set(key, bool(value))

    def get_float(self, key, default=0.0):
        try:
            return float(self.get(key, default))
        except Exception:
            return float(default)

    def set_float(self, key, value):
        try:
            value = float(value)
        except Exception:
            value = 0.0
        return self.set(key, value)

    def get_int(self, key, default=0):
        try:
            return int(self.get(key, default))
        except Exception:
            return int(default)

    def set_int(self, key, value):
        try:
            value = int(value)
        except Exception:
            value = 0
        return self.set(key, value)

    def get_enum(self, key, default=""):
        return str(self.get(key, default))

    def set_enum(self, key, value):
        return self.set(key, str(value))

    def pop(self, key, default=None):
        return self._data.pop(key, default)

    def update(self, values=None, **kwargs):
        if isinstance(values, dict):
            self._data.update(values)
        elif values is not None:
            try:
                self._data.update(dict(values))
            except Exception:
                pass
        if kwargs:
            self._data.update(kwargs)
        return dict(self._data)

    def clear(self):
        self._data.clear()

    def keys(self):
        return self._data.keys()

    def items(self):
        return self._data.items()

    def append_log(self, message, key="debug_log", max_items=20):
        items = self._data.get(key)
        if not isinstance(items, list):
            items = []
        items.append(str(message))
        if max_items and len(items) > max_items:
            items = items[-max_items:]
        self._data[key] = items
        return items

    def to_dict(self):
        return dict(self._data)


class CachedModulePanelAPI:
    __slots__ = (
        "context",
        "scene",
        "state",
        "workflow",
        "module",
        "allow_writes",
        "field_specs",
        "workflow_name",
        "module_name",
        "module_index",
        "space_type",
    )

    def __init__(self, ctx, scn, store_proxy, workflow, module, allow_writes=True, field_specs=None):
        self.context = ctx
        self.scene = scn
        self.state = store_proxy
        self.workflow = workflow
        self.module = module
        self.allow_writes = allow_writes
        self.field_specs = field_specs if field_specs is not None else []
        self.workflow_name = getattr(workflow, "name", "")
        self.module_name = getattr(module, "name", "")
        self.module_index = -1
        self.space_type = current_space_type(context=ctx)
        try:
            for item_index, item in enumerate(getattr(workflow, "modules", [])):
                if item == module:
                    self.module_index = item_index
                    break
        except Exception:
            self.module_index = -1

    def _prop_key(self, key, kind="value"):
        return module_scene_prop_key(self.workflow, self.module, key, kind=kind)

    def _prop_path(self, key, kind="value"):
        return f'["{self._prop_key(key, kind=kind)}"]'

    def _data_kind(self, collection_name):
        return f"datablock_{slugify_filename(collection_name, 'data')}"

    def compact_text(self, text, max_chars=UI_LABEL_MAX_CHARS, fallback=""):
        return compact_inline_text(text, max_chars=max_chars, fallback=fallback)

    def plain_text(self, text, fallback=""):
        value = str(text if text is not None else fallback)
        return value if value else str(fallback or "")

    def _remember_field(self, key, default, kind="value"):
        self.field_specs.append(
            {
                "key": key,
                "kind": kind,
                "default": default,
                "prop_key": self._prop_key(key, kind=kind),
            }
        )

    def _ensure_scene_value(self, key, default, kind="value"):
        prop_key = self._prop_key(key, kind=kind)
        self._remember_field(key, default, kind=kind)
        # AI定位：绘制阶段只登记字段，不主动写 Scene，避免打开面板污染 Blender 撤回栈。
        return prop_key

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)

        def layout_passthrough(layout, *args, **kwargs):
            method = getattr(layout, name, None)
            if method is None:
                raise AttributeError(name)
            try:
                return method(*args, **kwargs)
            except TypeError:
                safe_kwargs = dict(kwargs)
                if safe_kwargs.get("icon") == "NONE":
                    safe_kwargs.pop("icon", None)
                if safe_kwargs != kwargs:
                    return method(*args, **safe_kwargs)
                raise

        return layout_passthrough

    def box(self, layout):
        return layout.box()

    def row(self, layout, align=True):
        return layout.row(align=align)

    def column(self, layout, align=True):
        return layout.column(align=align)

    def separator(self, layout):
        layout.separator()

    def label(self, layout, text, icon="NONE"):
        layout.label(text=self.plain_text(text), icon=icon)

    def section(self, layout, title, icon="NONE", enabled=True, description=""):
        box = layout.box()
        try:
            box.enabled = bool(enabled)
        except Exception:
            pass
        if title:
            box.label(text=self.plain_text(title), icon=icon)
        if description:
            self.draw_note(box, description, icon="NONE")
        return box

    def set_enabled(self, layout, enabled=True):
        try:
            layout.enabled = bool(enabled)
        except Exception:
            pass
        return layout

    def set_alert(self, layout, enabled=True):
        try:
            layout.alert = bool(enabled)
        except Exception:
            pass
        return layout

    def draw_note(self, layout, text, icon="INFO", limit=4, width=48):
        for line in split_preview_lines(str(text or ""), limit=limit, width=width):
            layout.label(text=self.plain_text(line), icon=icon)
            icon = "NONE"

    def draw_key_value(self, layout, label, value, icon="NONE", value_icon="NONE"):
        row = layout.row(align=True)
        row.label(text=self.compact_text(label), icon=icon)
        row.label(text=self.compact_text(value, max_chars=UI_BUTTON_MAX_CHARS, fallback="-"), icon=value_icon)
        return row

    def draw_status_block(self, layout, title="状态", lines=None, icon="INFO", enabled=True):
        box = self.section(layout, title, icon=icon, enabled=enabled)
        for line in lines or []:
            if isinstance(line, dict):
                self.draw_key_value(
                    box,
                    line.get("label", ""),
                    line.get("value", ""),
                    icon=line.get("icon", "NONE"),
                    value_icon=line.get("value_icon", "NONE"),
                )
            else:
                box.label(text=self.plain_text(line), icon="NONE")
        return box

    def draw_image_preview(self, layout, image=None, label="", scale=8.0, fallback=""):
        if label:
            layout.label(text=self.plain_text(label), icon="IMAGE_REFERENCE")
        if image is None:
            if fallback:
                layout.label(text=self.plain_text(fallback), icon="INFO")
            return False
        try:
            icon_id = cached_image_preview_icon_id(image)
            if icon_id:
                layout.template_icon(icon_value=icon_id, scale=max(1.0, float(scale)))
                return True
        except Exception:
            pass
        fallback_name = getattr(image, "name", "") or fallback
        if fallback_name:
            layout.label(text=self.plain_text(fallback_name), icon="FILE_IMAGE")
        return False

    def prop(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.prop(data, prop_name, **kwargs)
        except TypeError:
            safe_kwargs = dict(kwargs)
            if safe_kwargs.get("icon") == "NONE":
                safe_kwargs.pop("icon", None)
            try:
                return layout.prop(data, prop_name, **safe_kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def prop_search(self, layout, data, prop_name, search_data, search_prop, **kwargs):
        if layout is None or data is None or search_data is None or not prop_name or not search_prop:
            return None
        try:
            return layout.prop_search(data, prop_name, search_data, search_prop, **kwargs)
        except TypeError:
            safe_kwargs = dict(kwargs)
            if safe_kwargs.get("icon") == "NONE":
                safe_kwargs.pop("icon", None)
            try:
                return layout.prop_search(data, prop_name, search_data, search_prop, **safe_kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def operator(self, layout, operator_id, text=None, icon="NONE", **properties):
        if layout is None or not operator_id:
            return None
        kwargs = {}
        if text is not None:
            kwargs["text"] = self.compact_text(text, max_chars=UI_BUTTON_MAX_CHARS)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            op = layout.operator(str(operator_id), **kwargs)
        except Exception:
            return None
        for key, value in properties.items():
            try:
                setattr(op, key, value)
            except Exception:
                pass
        return op

    def menu(self, layout, menu_id, text=None, icon="NONE"):
        if layout is None or not menu_id:
            return None
        kwargs = {}
        if text is not None:
            kwargs["text"] = self.compact_text(text, max_chars=UI_BUTTON_MAX_CHARS)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            return layout.menu(str(menu_id), **kwargs)
        except Exception:
            return None

    def operator_menu_enum(self, layout, operator_id, prop_name, text=None, icon="NONE"):
        if layout is None or not operator_id or not prop_name:
            return None
        kwargs = {}
        if text is not None:
            kwargs["text"] = self.compact_text(text, max_chars=UI_BUTTON_MAX_CHARS)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            return layout.operator_menu_enum(str(operator_id), str(prop_name), **kwargs)
        except Exception:
            return None

    def operator_enum(self, layout, operator_id, prop_name):
        if layout is None or not operator_id or not prop_name:
            return None
        try:
            return layout.operator_enum(str(operator_id), str(prop_name))
        except Exception:
            return None

    def prop_menu_enum(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.prop_menu_enum(data, prop_name, **kwargs)
        except TypeError:
            safe_kwargs = dict(kwargs)
            if safe_kwargs.get("icon") == "NONE":
                safe_kwargs.pop("icon", None)
            try:
                return layout.prop_menu_enum(data, prop_name, **safe_kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def prop_enum(self, layout, data, prop_name, value, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.prop_enum(data, prop_name, value, **kwargs)
        except TypeError:
            safe_kwargs = dict(kwargs)
            if safe_kwargs.get("icon") == "NONE":
                safe_kwargs.pop("icon", None)
            try:
                return layout.prop_enum(data, prop_name, value, **safe_kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def popover(self, layout, panel_id, text=None, icon="NONE"):
        if layout is None or not panel_id:
            return None
        kwargs = {}
        if text is not None:
            kwargs["text"] = self.compact_text(text, max_chars=UI_BUTTON_MAX_CHARS)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            return layout.popover(str(panel_id), **kwargs)
        except Exception:
            return None

    def menu_contents(self, layout, menu_id):
        if layout is None or not menu_id:
            return None
        try:
            return layout.menu_contents(str(menu_id))
        except Exception:
            return None

    def context_pointer_set(self, layout, name, data):
        if layout is None or not name:
            return None
        try:
            return layout.context_pointer_set(str(name), data)
        except Exception:
            return None

    def split(self, layout, factor=0.5, align=False):
        if layout is None:
            return None
        try:
            return layout.split(factor=max(0.0, min(1.0, float(factor))), align=bool(align))
        except Exception:
            return None

    def grid_flow(self, layout, **kwargs):
        if layout is None:
            return None
        try:
            return layout.grid_flow(**kwargs)
        except Exception:
            return None

    def template_list(self, layout, *args, **kwargs):
        if layout is None:
            return None
        try:
            return layout.template_list(*args, **kwargs)
        except Exception:
            return None

    def template_id(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.template_ID(data, prop_name, **kwargs)
        except Exception:
            return None

    def template_icon(self, layout, icon_value=0, scale=1.0):
        if layout is None:
            return None
        try:
            return layout.template_icon(icon_value=int(icon_value or 0), scale=max(1.0, float(scale)))
        except Exception:
            return None

    def template_id_preview(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.template_ID_preview(data, prop_name, **kwargs)
        except Exception:
            return None

    def template_search(self, layout, data, prop_name, search_data, search_prop, **kwargs):
        if layout is None or data is None or search_data is None or not prop_name or not search_prop:
            return None
        try:
            return layout.template_search(data, prop_name, search_data, search_prop, **kwargs)
        except Exception:
            return None

    def template_icon_view(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.template_icon_view(data, prop_name, **kwargs)
        except Exception:
            return None

    def template_color_picker(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.template_color_picker(data, prop_name, **kwargs)
        except Exception:
            return None

    def template_curve_mapping(self, layout, data, prop_name, **kwargs):
        if layout is None or data is None or not prop_name:
            return None
        try:
            return layout.template_curve_mapping(data, prop_name, **kwargs)
        except Exception:
            return None

    def template_preview(self, layout, id_data, **kwargs):
        if layout is None or id_data is None:
            return None
        try:
            return layout.template_preview(id_data, **kwargs)
        except Exception:
            return None

    def draw_prop(self, layout, data, prop_name, label=None, icon="NONE", slider=False, expand=False, toggle=-1, emboss=True):
        if data is None or not prop_name:
            return None
        kwargs = {"text": "" if label is None else self.compact_text(label), "slider": slider, "expand": expand, "emboss": emboss}
        if toggle in {0, 1}:
            kwargs["toggle"] = bool(toggle)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            return layout.prop(data, prop_name, **kwargs)
        except TypeError:
            kwargs.pop("icon", None)
            kwargs.pop("toggle", None)
            try:
                return layout.prop(data, prop_name, **kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def draw_scene_prop(self, layout, prop_name, label=None, icon="NONE", slider=False, expand=False, toggle=-1, emboss=True):
        return self.draw_prop(
            layout,
            self.scene,
            prop_name,
            label=label,
            icon=icon,
            slider=slider,
            expand=expand,
            toggle=toggle,
            emboss=emboss,
        )

    def draw_runtime_prop(self, layout, key, default=None, kind="value", label=None, icon="NONE", slider=False, expand=False, toggle=-1, emboss=True):
        prop_key = self._ensure_scene_value(key, default, kind=kind)
        if self.scene is None or not prop_key:
            return None
        kwargs = {
            "text": "" if label is None else self.compact_text(label),
            "slider": slider,
            "expand": expand,
            "emboss": emboss,
        }
        if toggle in {0, 1}:
            kwargs["toggle"] = bool(toggle)
        if icon != "NONE":
            kwargs["icon"] = icon
        try:
            return layout.prop(self.scene, f'["{prop_key}"]', **kwargs)
        except TypeError:
            kwargs.pop("icon", None)
            kwargs.pop("toggle", None)
            try:
                return layout.prop(self.scene, f'["{prop_key}"]', **kwargs)
            except Exception:
                return None
        except Exception:
            return None

    def split_field(self, layout, label="", factor=0.34, align=True):
        split = layout.split(factor=max(0.1, min(0.9, float(factor))), align=align)
        left = split.row(align=align)
        right = split.row(align=align)
        if label:
            left.label(text=self.compact_text(label))
        return left, right

    def foldout_section(self, layout, key, title, icon="NONE", default_open=True, enabled=True):
        prop_key = self._ensure_scene_value(key, bool(default_open), kind="bool")
        is_open = bool(module_runtime_field_value(self.scene, self.workflow, self.module, key, "bool", bool(default_open)))
        box = layout.box()
        try:
            box.enabled = bool(enabled)
        except Exception:
            pass
        header = box.row(align=True)
        if self.scene is not None and module_scene_prop_key_usable(prop_key) and (prop_key in self.scene or self.allow_writes):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = bool(default_open)
                header.prop(
                    self.scene,
                    f'["{prop_key}"]',
                    text=self.plain_text(title),
                    icon="TRIA_DOWN" if bool(self.scene.get(prop_key, default_open)) else "TRIA_RIGHT",
                    emboss=False,
                    toggle=False,
                )
                is_open = bool(self.scene.get(prop_key, default_open))
                if self.allow_writes:
                    self.state.set(key, is_open)
            except Exception:
                header.label(text=self.plain_text(title), icon=icon)
        else:
            header.label(text=self.plain_text(title), icon=icon)
        if icon != "NONE":
            header.label(text="", icon=icon)
        content = box.column(align=True)
        try:
            content.enabled = bool(enabled)
        except Exception:
            pass
        if not is_open:
            return None
        return content

    def draw_button(self, layout, action, label=None, icon="NONE", tooltip=""):
        op = layout.operator(
            "bworkflow.module_runtime_action",
            text=self.compact_text(label or action, max_chars=UI_BUTTON_MAX_CHARS),
            icon=icon,
        )
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.action_name = str(action)
        op.tooltip_text = str(tooltip or "")
        return op

    def draw_icon_button(self, layout, action, icon="NONE", tooltip=""):
        op = layout.operator(
            "bworkflow.module_runtime_action",
            text="",
            icon=icon,
            emboss=True,
        )
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.action_name = str(action)
        op.tooltip_text = str(tooltip or "")
        return op

    def draw_run_button(self, layout, label="运行模块", icon="PLAY"):
        op = layout.operator(
            "bworkflow.module_run",
            text=self.compact_text(label, max_chars=UI_BUTTON_MAX_CHARS),
            icon=icon,
        )
        op.module_index = self.module_index
        return op

    def get_value(self, key, default=None, kind="text"):
        kind = str(kind or "text")
        if kind == "bool":
            return self.get_bool(key, bool(default))
        if kind == "float":
            return self.get_float(key, 0.0 if default is None else default)
        if kind == "int":
            return self.get_int(key, 0 if default is None else default)
        if kind == "object":
            return self.get_object(key, default)
        if kind == "enum":
            return self.get_enum(key, default)
        return self.get_text(key, "" if default is None else default)

    def set_value(self, key, value, kind="text"):
        kind = str(kind or "text")
        if kind == "bool":
            return self.set_bool(key, value)
        if kind == "float":
            return self.set_float(key, value)
        if kind == "int":
            return self.set_int(key, value)
        if kind == "object":
            return self.set_object(key, value)
        if kind == "enum":
            return self.set_enum(key, value)
        return self.set_text(key, value)

    def clear_value(self, key, kind=None):
        kinds = [kind] if kind else ["text", "bool", "float", "int", "object", "enum", "value"]
        for item_kind in kinds:
            prop_key = self._prop_key(key, kind=item_kind)
            if (
                self.scene is not None
                and self.allow_writes
                and module_scene_prop_key_usable(prop_key)
                and prop_key in self.scene
            ):
                try:
                    del self.scene[prop_key]
                except Exception:
                    pass
        if self.allow_writes:
            self.state.pop(key, None)
        return None

    def get_object(self, key, default=None):
        scene_name = ""
        if self.scene is not None:
            scene_name, _scene_prop_key = module_runtime_field_scene_value(
                self.scene, self.workflow, self.module, key, "object", ""
            )
        name = scene_name or self.state.get(key, "")
        if not name:
            return default
        return bpy.data.objects.get(name, default)

    def set_object(self, key, obj):
        name = getattr(obj, "name", "") if obj is not None else ""
        self._remember_field(key, name, kind="object")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="object")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = name
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, name)
        return obj

    def get_text(self, key, default=""):
        self._remember_field(key, str(default), kind="text")
        scene_value, scene_prop_key = module_runtime_field_scene_value(
            self.scene, self.workflow, self.module, key, "text", self.state.get(key, default)
        )
        if scene_prop_key:
            return str(scene_value)
        return str(self.state.get(key, default))

    def set_text(self, key, value):
        text_value = str(value)
        self._remember_field(key, text_value, kind="text")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="text")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = text_value
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, text_value)
        return text_value

    def get_bool(self, key, default=False):
        self._remember_field(key, bool(default), kind="bool")
        scene_value, scene_prop_key = module_runtime_field_scene_value(
            self.scene, self.workflow, self.module, key, "bool", self.state.get(key, default)
        )
        if scene_prop_key:
            return bool(scene_value)
        return bool(self.state.get(key, default))

    def set_bool(self, key, value):
        bool_value = bool(value)
        self._remember_field(key, bool_value, kind="bool")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="bool")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = bool_value
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, bool_value)
        return bool_value

    def get_float(self, key, default=0.0):
        try:
            self._remember_field(key, float(default), kind="float")
            scene_value, scene_prop_key = module_runtime_field_scene_value(
                self.scene, self.workflow, self.module, key, "float", self.state.get(key, default)
            )
            if scene_prop_key:
                return float(scene_value)
            return float(self.state.get(key, default))
        except Exception:
            return float(default)

    def set_float(self, key, value):
        float_value = float(value)
        self._remember_field(key, float_value, kind="float")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="float")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = float_value
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, float_value)
        return float_value

    def get_int(self, key, default=0):
        try:
            self._remember_field(key, int(default), kind="int")
            scene_value, scene_prop_key = module_runtime_field_scene_value(
                self.scene, self.workflow, self.module, key, "int", self.state.get(key, default)
            )
            if scene_prop_key:
                return int(scene_value)
            return int(self.state.get(key, default))
        except Exception:
            return int(default)

    def set_int(self, key, value):
        int_value = int(value)
        self._remember_field(key, int_value, kind="int")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="int")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = int_value
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, int_value)
        return int_value

    def get_enum(self, key, default=""):
        default_value = str(default or "")
        self._remember_field(key, default_value, kind="enum")
        scene_value, scene_prop_key = module_runtime_field_scene_value(
            self.scene, self.workflow, self.module, key, "enum", self.state.get(key, default_value)
        )
        if scene_prop_key:
            return str(scene_value)
        return str(self.state.get(key, default_value))

    def set_enum(self, key, value):
        text_value = str(value or "")
        self._remember_field(key, text_value, kind="enum")
        if self.scene is not None and self.allow_writes:
            prop_key = self._prop_key(key, kind="enum")
            if module_scene_prop_key_usable(prop_key):
                try:
                    self.scene[prop_key] = text_value
                except Exception:
                    pass
        if self.allow_writes:
            self.state.set(key, text_value)
        return text_value

    def data_collection(self, collection_name):
        return getattr(bpy.data, str(collection_name or ""), None)

    def get_data_block(self, key, collection_name="objects", default=None):
        kind = self._data_kind(collection_name)
        default_name = getattr(default, "name", "") if default is not None else ""
        self._remember_field(key, default_name, kind=kind)
        scene_value, scene_prop_key = module_runtime_field_scene_value(
            self.scene, self.workflow, self.module, key, kind, self.state.get(key, default_name)
        )
        if scene_prop_key:
            name = str(scene_value or "")
        else:
            name = str(self.state.get(key, default_name) or "")
        collection = self.data_collection(collection_name)
        if collection is None or not name:
            return default
        try:
            return collection.get(name) or default
        except Exception:
            return default

    def set_data_block(self, key, data_block, collection_name="objects"):
        kind = self._data_kind(collection_name)
        name = getattr(data_block, "name", "") if data_block is not None else ""
        self._remember_field(key, name, kind=kind)
        if self.scene is not None and self.allow_writes:
            self.scene[self._prop_key(key, kind=kind)] = name
        if self.allow_writes:
            self.state.set(key, name)
        return data_block

    def get_material(self, key, default=None):
        return self.get_data_block(key, "materials", default=default)

    def get_collection(self, key, default=None):
        return self.get_data_block(key, "collections", default=default)

    def get_text_block(self, key, default=None):
        return self.get_data_block(key, "texts", default=default)

    def set_status(self, text, level="INFO"):
        value = self.compact_text(text, max_chars=96)
        if self.allow_writes:
            self.state.set("last_status", value)
            self.state.set("last_status_level", str(level or "INFO"))
        return value

    def get_status(self, default=""):
        return str(self.state.get("last_status", default) or "")

    def draw_status(self, layout, default="", icon=None):
        status = self.get_status(default)
        if not status:
            return
        level = str(self.state.get("last_status_level", "INFO") or "INFO").upper()
        icon_name = icon or {"ERROR": "ERROR", "WARNING": "ERROR", "OK": "CHECKMARK"}.get(level, "INFO")
        self.draw_note(layout, status, icon=icon_name, limit=3)

    def log(self, message, key="debug_log", max_items=8, print_to_console=True):
        text = self.compact_text(message, max_chars=160)
        if print_to_console:
            print(f"[GoWorkflow:{self.module_name}] {text}")
        if self.allow_writes:
            return self.state.append_log(text, key=key, max_items=max_items)
        return []

    def draw_log(self, layout, key="debug_log", limit=6):
        entries = self.state.get(key, [])
        if not isinstance(entries, (list, tuple)) or not entries:
            return
        for entry in list(entries)[-limit:]:
            layout.label(text=self.compact_text(entry), icon="CONSOLE")

    def active_object(self):
        return getattr(self.context, "object", None)

    def selected_objects(self, type=None):
        items = list(getattr(self.context, "selected_objects", []) or [])
        if type:
            items = [obj for obj in items if getattr(obj, "type", None) == type]
        return items

    def visible_objects(self, type=None):
        items = list(getattr(self.context, "visible_objects", []) or [])
        if type:
            items = [obj for obj in items if getattr(obj, "type", None) == type]
        return items

    def selected_mesh_objects(self, require_shape_keys=False):
        items = self.selected_objects(type="MESH")
        if require_shape_keys:
            items = [obj for obj in items if self.shape_key_blocks(obj)]
        return items

    def shape_key_data(self, obj=None):
        obj = obj or self.active_object()
        data = getattr(obj, "data", None)
        return getattr(data, "shape_keys", None)

    def shape_key_blocks(self, obj=None):
        key_data = self.shape_key_data(obj)
        return getattr(key_data, "key_blocks", None)

    def active_shape_key_index(self, obj=None):
        obj = obj or self.active_object()
        try:
            return int(getattr(obj, "active_shape_key_index", -1))
        except Exception:
            return -1

    def active_shape_key(self, obj=None, include_basis=True):
        obj = obj or self.active_object()
        key_blocks = self.shape_key_blocks(obj)
        index = self.active_shape_key_index(obj)
        if not key_blocks or index < 0:
            return None
        if not include_basis and index <= 0:
            return None
        try:
            if index < len(key_blocks):
                return key_blocks[index]
        except Exception:
            return None
        return None

    def valid_shape_key_objects(self, require_active_non_basis=False):
        items = self.selected_mesh_objects(require_shape_keys=True)
        if require_active_non_basis:
            items = [obj for obj in items if self.active_shape_key(obj, include_basis=False) is not None]
        return items

    def context_summary(self):
        active = self.active_object()
        return {
            "mode": getattr(self.context, "mode", ""),
            "scene": getattr(getattr(self.context, "scene", None), "name", ""),
            "active_object": getattr(active, "name", ""),
            "active_type": getattr(active, "type", ""),
            "selected_count": len(self.selected_objects()),
            "visible_count": len(self.visible_objects()),
        }

    def draw_text_input(self, layout, key, label, default=""):
        default_value = str(default)
        self._ensure_scene_value(key, default_value, kind="text")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "text", default_value) or "")
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        op = row.operator("bworkflow.module_runtime_field_write", text=self.compact_text(value, UI_BUTTON_MAX_CHARS, "编辑"), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "text"
        op.text_value = value

    def draw_text_input_inline(self, layout, key, label, default="", factor=0.34):
        default_value = str(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="text")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "text", default_value) or "")
        _left, right = self.split_field(layout, label, factor=factor)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                right.prop(self.scene, f'["{prop_key}"]', text="")
                if self.allow_writes:
                    self.state.set(key, str(self.scene.get(prop_key, value) or ""))
                return
            except Exception:
                pass
        op = right.operator("bworkflow.module_runtime_field_write", text=self.compact_text(value, UI_BUTTON_MAX_CHARS, ""), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "text"
        op.text_value = value

    def draw_toggle(self, layout, key, label, default=False):
        default_value = bool(default)
        self._ensure_scene_value(key, default_value, kind="bool")
        value = bool(module_runtime_field_value(self.scene, self.workflow, self.module, key, "bool", default_value))
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        op = row.operator("bworkflow.module_runtime_field_write", text="开" if value else "关", depress=value)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "bool"
        op.bool_value = not value

    def draw_toggle_inline(self, layout, key, label, default=False, factor=0.34):
        default_value = bool(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="bool")
        _left, right = self.split_field(layout, label, factor=factor)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = default_value
                right.prop(self.scene, f'["{prop_key}"]', text="")
                if self.allow_writes:
                    self.state.set(key, bool(self.scene.get(prop_key, default_value)))
                return
            except Exception:
                pass
        value = bool(module_runtime_field_value(self.scene, self.workflow, self.module, key, "bool", default_value))
        op = right.operator("bworkflow.module_runtime_field_write", text="", icon="CHECKBOX_HLT" if value else "CHECKBOX_DEHLT", emboss=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "bool"
        op.bool_value = not value
        return op

    def draw_float_input(self, layout, key, label, default=0.0, **kwargs):
        default_value = float(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="float")
        value = float(module_runtime_field_value(self.scene, self.workflow, self.module, key, "float", default_value))
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        prop_kwargs = runtime_numeric_prop_kwargs(**kwargs)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                row.prop(self.scene, f'["{prop_key}"]', text="", **prop_kwargs)
                if self.allow_writes:
                    self.state.set(key, float(self.scene.get(prop_key, value)))
                return
            except Exception:
                pass
        op = row.operator("bworkflow.module_runtime_field_write", text=f"{value:.3f}", translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "float"
        op.float_value = value

    def draw_float_input_inline(self, layout, key, label, default=0.0, factor=0.34, **kwargs):
        default_value = float(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="float")
        value = float(module_runtime_field_value(self.scene, self.workflow, self.module, key, "float", default_value))
        _left, right = self.split_field(layout, label, factor=factor)
        prop_kwargs = runtime_numeric_prop_kwargs(**kwargs)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                right.prop(self.scene, f'["{prop_key}"]', text="", **prop_kwargs)
                if self.allow_writes:
                    self.state.set(key, float(self.scene.get(prop_key, value)))
                return
            except Exception:
                pass
        op = right.operator("bworkflow.module_runtime_field_write", text=f"{value:.3f}", translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "float"
        op.float_value = value
        return op

    def draw_int_input(self, layout, key, label, default=0, **kwargs):
        default_value = int(default)
        self._ensure_scene_value(key, default_value, kind="int")
        value = int(module_runtime_field_value(self.scene, self.workflow, self.module, key, "int", default_value))
        prop_key = self._prop_key(key, kind="int")
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        prop_kwargs = runtime_numeric_prop_kwargs(**kwargs)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                row.prop(self.scene, f'["{prop_key}"]', text="", **prop_kwargs)
                if self.allow_writes:
                    self.state.set(key, int(self.scene.get(prop_key, value)))
                return
            except Exception:
                pass
        op = row.operator("bworkflow.module_runtime_field_write", text=str(value), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "int"
        op.int_value = value

    def draw_int_input_inline(self, layout, key, label, default=0, factor=0.34, **kwargs):
        default_value = int(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="int")
        value = int(module_runtime_field_value(self.scene, self.workflow, self.module, key, "int", default_value))
        _left, right = self.split_field(layout, label, factor=factor)
        prop_kwargs = runtime_numeric_prop_kwargs(**kwargs)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                right.prop(self.scene, f'["{prop_key}"]', text="", **prop_kwargs)
                if self.allow_writes:
                    self.state.set(key, int(self.scene.get(prop_key, value)))
                return
            except Exception:
                pass
        op = right.operator("bworkflow.module_runtime_field_write", text=str(value), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "int"
        op.int_value = value
        return op

    def draw_enum(self, layout, key, label, items, default=None, max_items=8, disabled_items=None, display_value=None):
        normalized = []
        for item in items or []:
            if isinstance(item, str):
                normalized.append((item, item))
            elif isinstance(item, (list, tuple)) and item:
                identifier = str(item[0])
                item_label = str(item[1]) if len(item) > 1 else identifier
                normalized.append((identifier, item_label))
        if not normalized:
            return

        default_value = str(default if default is not None else normalized[0][0])
        identifiers = {identifier for identifier, _label in normalized}
        disabled_identifiers = {str(identifier) for identifier in (disabled_items or [])}
        self._ensure_scene_value(key, default_value, kind="enum")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "enum", default_value) or default_value)
        if value not in identifiers:
            value = default_value
        active_value = str(display_value or value)
        if active_value not in identifiers:
            active_value = value

        layout.label(text=self.compact_text(label))
        row = layout.row(align=True)
        for identifier, item_label in normalized[:max_items]:
            item_row = row.row(align=True)
            item_row.enabled = identifier not in disabled_identifiers
            op = item_row.operator(
                "bworkflow.module_runtime_field_write",
                text=self.compact_text(item_label, max_chars=16),
                depress=identifier == active_value,
                translate=False,
            )
            op.workflow_name = self.workflow_name
            op.module_name = self.module_name
            op.space_type = self.space_type
            op.field_key = key
            op.field_kind = "enum"
            op.text_value = identifier
        if len(normalized) > max_items:
            layout.label(text=f"还有 {len(normalized) - max_items} 项，建议用文本输入。", icon="INFO")

    def draw_object_picker(self, layout, key, label="物体", default=None):
        default_name = getattr(default, "name", "") if default is not None else ""
        self._ensure_scene_value(key, default_name, kind="object")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "object", default_name) or "")
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        op = row.operator("bworkflow.module_runtime_field_write", text=self.compact_text(value, UI_BUTTON_MAX_CHARS, "选择物体"), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "object"
        op.object_name = value

    def draw_object_picker_inline(self, layout, key, label="物体", default=None, factor=0.34, show_active_button=False):
        default_name = getattr(default, "name", "") if default is not None else ""
        prop_key = self._ensure_scene_value(key, default_name, kind="object")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "object", default_name) or "")
        _left, right = self.split_field(layout, label, factor=factor)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                field_row = right.row(align=True)
                field_row.prop(self.scene, f'["{prop_key}"]', text="")
                if show_active_button:
                    self.draw_active_object_capture(field_row, key, "", icon="EYEDROPPER")
                if self.allow_writes:
                    self.state.set(key, str(self.scene.get(prop_key, value) or ""))
                return
            except Exception:
                pass
        field_row = right.row(align=True)
        op = field_row.operator("bworkflow.module_runtime_field_write", text=self.compact_text(value, UI_BUTTON_MAX_CHARS, ""), translate=False)
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "object"
        op.object_name = value
        if show_active_button:
            self.draw_active_object_capture(field_row, key, "", icon="EYEDROPPER")
        return op

    def draw_file_path_input(self, layout, key, label, default="", factor=0.34, filter_glob="*.*", status_prefix="已选择文件"):
        default_value = str(default)
        prop_key = self._ensure_scene_value(key, default_value, kind="text")
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, "text", default_value) or "")
        _left, right = self.split_field(layout, label, factor=factor)
        if self.scene is not None and module_scene_prop_key_usable(prop_key):
            try:
                if prop_key not in self.scene and self.allow_writes:
                    self.scene[prop_key] = value
                field_row = right.row(align=True)
                field_row.prop(self.scene, f'["{prop_key}"]', text="")
                op = field_row.operator("bworkflow.module_pick_file_path", text="", icon="FILE_FOLDER")
                op.workflow_name = self.workflow_name
                op.module_name = self.module_name
                op.space_type = self.space_type
                op.target_text_key = key
                op.filter_glob = str(filter_glob or "*.*")
                op.status_prefix = str(status_prefix or "已选择文件")
                if self.allow_writes:
                    self.state.set(key, str(self.scene.get(prop_key, value) or ""))
                return op
            except Exception:
                pass
        return self.draw_text_input_inline(layout, key, label, default=default, factor=factor)

    def draw_active_object_capture(self, layout, key, label="吸取当前选中", icon="EYEDROPPER"):
        active_name = getattr(getattr(self.context, "object", None), "name", "")
        op = layout.operator(
            "bworkflow.module_runtime_field_write",
            text=self.compact_text(label, UI_BUTTON_MAX_CHARS),
            icon=icon,
        )
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = "object"
        op.object_name = active_name
        return op

    def draw_data_block_picker(self, layout, key, label, collection_name="objects", default=None):
        kind = self._data_kind(collection_name)
        default_name = getattr(default, "name", "") if default is not None else ""
        self._ensure_scene_value(key, default_name, kind=kind)
        value = str(module_runtime_field_value(self.scene, self.workflow, self.module, key, kind, default_name) or "")
        row = layout.row(align=True)
        row.label(text=self.compact_text(label))
        op = row.operator(
            "bworkflow.module_runtime_field_write",
            text=self.compact_text(value, UI_BUTTON_MAX_CHARS, "选择"),
            translate=False,
        )
        op.workflow_name = self.workflow_name
        op.module_name = self.module_name
        op.space_type = self.space_type
        op.field_key = key
        op.field_kind = kind
        op.text_value = value
        op.data_collection = str(collection_name or "")

    def draw_material_picker(self, layout, key, label="材质", default=None):
        return self.draw_data_block_picker(layout, key, label, "materials", default=default)

    def draw_collection_picker(self, layout, key, label="集合", default=None):
        return self.draw_data_block_picker(layout, key, label, "collections", default=default)

    def draw_text_block_picker(self, layout, key, label="文本", default=None):
        return self.draw_data_block_picker(layout, key, label, "texts", default=default)


def module_runtime_context(context, scene, workflow, module, allow_writes=True, field_specs=None):
    module_store = ensure_module_runtime_store(scene, workflow, module, allow_writes=allow_writes)
    proxy = CachedModuleStateProxy(module_store)
    panel_api = CachedModulePanelAPI(
        context,
        scene,
        proxy,
        workflow,
        module,
        allow_writes=allow_writes,
        field_specs=field_specs,
    )
    return proxy, panel_api

def build_module_namespace(context, scene, workflow, module, name, allow_writes=True, field_specs=None):
    module_state, panel_api = module_runtime_context(
        context,
        scene,
        workflow,
        module,
        allow_writes=allow_writes,
        field_specs=field_specs,
    )
    script_path = module_script_abspath(module)
    module_file = script_path if script_path else name
    return {
        "__name__": name,
        "__file__": module_file,
        "bpy": bpy,
        "context": context,
        "scene": scene,
        "workflow": workflow,
        "module": module,
        "module_state": module_state,
        "panel_api": panel_api,
    }


def source_cache_signature(source, name):
    normalized = str(source or "").lstrip("\ufeff")
    return (str(name or ""), hashlib.sha1(normalized.encode("utf-8", errors="replace")).hexdigest())


def text_block_source_payload(text_name, text_block):
    source = text_block.as_string().lstrip("\ufeff")
    content_hash = hashlib.sha1(source.encode("utf-8", errors="replace")).hexdigest()
    token = ("text", str(text_name or ""), len(source), content_hash)
    MODULE_SOURCE_TEXT_CACHE[str(text_name or "")] = {
        "source": source,
        "content_hash": content_hash,
        "token": token,
    }
    return source, content_hash, token


def module_source_fast_token(module):
    text_name = str(getattr(module, "text_block_name", "") or "").strip()
    if text_name:
        text_block = bpy.data.texts.get(text_name)
        if text_block is not None:
            try:
                _source, _content_hash, token = text_block_source_payload(text_name, text_block)
                return token
            except Exception:
                return ("text", text_name, -1)
    filepath = module_script_abspath(module)
    if filepath and os.path.isfile(filepath):
        try:
            stat = os.stat(filepath)
            return ("file", os.path.normcase(os.path.abspath(filepath)), int(stat.st_mtime_ns), int(stat.st_size))
        except Exception:
            return ("file", os.path.normcase(os.path.abspath(filepath)), 0, 0)
    source = str(getattr(module, "script_source", "") or "")
    if source:
        return ("prop", len(source), source[:96], source[-96:])
    return ("empty",)


def get_cached_module_source(module, name):
    """获取模块源代码及其签名，用源码哈希判断 Text Block 是否已经变更。

    每次 draw（滚轮滚动等）都会调用 load_module_namespace。哈希 token
    可以避免 Text Block 行数不变但内容已变时继续复用旧命名空间。
    """
    text_name = str(getattr(module, "text_block_name", "") or "").strip()
    if text_name:
        text_block = bpy.data.texts.get(text_name)
        if text_block is not None:
            try:
                cached = MODULE_SOURCE_TEXT_CACHE.get(text_name)
                source, content_hash, _token = text_block_source_payload(text_name, text_block)
                if cached is not None and cached.get("content_hash") == content_hash:
                    return cached.get("source", source), (str(name or ""), content_hash)
                return source, (str(name or ""), content_hash)
            except Exception:
                pass
    source = str(getattr(module, "script_source", "") or "").lstrip("\ufeff")
    if not source:
        filepath = module_script_abspath(module)
        if filepath and os.path.isfile(filepath):
            try:
                source = read_cached_text_file(filepath).lstrip("\ufeff")
            except Exception:
                source = ""
    signature = source_cache_signature(source, name)
    return source, signature

def cached_module_namespace(scene, workflow, module, name, source_signature=None, source_token=None):
    cache_key = module_runtime_namespace_cache_key(scene, workflow, module, name)
    cached = MODULE_RUNTIME_NAMESPACE_CACHE.get(cache_key)
    if not isinstance(cached, dict):
        return None
    if source_token is not None and cached.get("source_token") == source_token:
        namespace = cached.get("namespace")
        return namespace if isinstance(namespace, dict) else None
    if source_signature is not None and cached.get("source_signature") != source_signature:
        return None
    if source_signature is None and source_token is None:
        return None
    namespace = cached.get("namespace")
    return namespace if isinstance(namespace, dict) else None


def store_module_namespace(scene, workflow, module, name, source_signature, namespace, source_token=None):
    if not isinstance(namespace, dict):
        return None
    MODULE_RUNTIME_NAMESPACE_CACHE[module_runtime_namespace_cache_key(scene, workflow, module, name)] = {
        "source_signature": source_signature,
        "source_token": source_token,
        "namespace": namespace,
    }
    return namespace


def clear_cached_module_namespaces(scene=None, workflow=None, module=None):
    global MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE
    if scene is None and workflow is None and module is None:
        MODULE_RUNTIME_NAMESPACE_CACHE.clear()
        MODULE_SOURCE_TEXT_CACHE.clear()
        MODULE_RUNTIME_FIELD_INIT_CACHE.clear()
        MODULE_RUNTIME_VOLATILE_STORE.clear()
        MODULE_RUNTIME_FIELD_SYNC_QUEUE.clear()
        MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = False
        return 0
    target_prefix = module_runtime_cleanup_cache_key(scene, workflow, module)
    removed = 0
    for key in list(MODULE_RUNTIME_NAMESPACE_CACHE.keys()):
        if tuple(key[:3]) != tuple(target_prefix):
            continue
        MODULE_RUNTIME_NAMESPACE_CACHE.pop(key, None)
        removed += 1
    for key in list(MODULE_RUNTIME_FIELD_INIT_CACHE.keys()):
        if tuple(key[:3]) != tuple(target_prefix):
            continue
        MODULE_RUNTIME_FIELD_INIT_CACHE.pop(key, None)
        removed += 1
    for key in list(MODULE_RUNTIME_VOLATILE_STORE.keys()):
        if tuple(key[:3]) != tuple(target_prefix):
            continue
        MODULE_RUNTIME_VOLATILE_STORE.pop(key, None)
        removed += 1
    for key in list(MODULE_RUNTIME_FIELD_SYNC_QUEUE.keys()):
        if tuple(key[:3]) != tuple(target_prefix):
            continue
        MODULE_RUNTIME_FIELD_SYNC_QUEUE.pop(key, None)
        removed += 1
    return removed


def execute_module_source(source, context, scene, workflow, module, name, allow_writes=True, persist_state=True, field_specs=None):
    source = str(source or "").lstrip("\ufeff")
    source_signature = source_cache_signature(source, name)
    module_state, panel_api = module_runtime_context(
        context,
        scene,
        workflow,
        module,
        allow_writes=allow_writes,
        field_specs=field_specs,
    )
    script_path = module_script_abspath(module)
    module_file = script_path if script_path else name
    namespace = {
        "__name__": name,
        "__file__": module_file,
        "bpy": bpy,
        "context": context,
        "scene": scene,
        "workflow": workflow,
        "module": module,
        "module_state": module_state,
        "panel_api": panel_api,
    }
    exec(compile(source, name, "exec"), namespace, namespace)
    if not allow_writes and not persist_state:
        store_module_namespace(
            scene,
            workflow,
            module,
            name,
            source_signature,
            namespace,
            source_token=module_source_fast_token(module),
        )
    if persist_state:
        merge_module_runtime_store(scene, workflow, module, namespace["module_state"].to_dict())
    cleanup_fn = namespace.get("cleanup_runtime") or namespace.get("cleanup")
    if callable(cleanup_fn):
        cache_module_runtime_cleanup(scene, workflow, module, cleanup_fn, namespace.get("module_state"))
    return namespace


def reuse_cached_module_namespace(cached, context, scene, workflow, module, name, allow_writes=False):
    panel_api = cached.get("panel_api")
    module_state = cached.get("module_state")
    if panel_api is not None:
        panel_api.context = context
        panel_api.scene = scene
        panel_api.workflow = workflow
        panel_api.module = module
        panel_api.allow_writes = allow_writes
        try:
            panel_api.space_type = current_space_type(context=context)
        except Exception:
            pass
        try:
            panel_api.field_specs.clear()
        except Exception:
            panel_api.field_specs = []
    else:
        module_state, panel_api = module_runtime_context(
            context,
            scene,
            workflow,
            module,
            allow_writes=allow_writes,
        )
    script_path = module_script_abspath(module)
    module_file = script_path if script_path else name
    cached["__name__"] = name
    cached["__file__"] = module_file
    cached["bpy"] = bpy
    cached["context"] = context
    cached["scene"] = scene
    cached["workflow"] = workflow
    cached["module"] = module
    cached["module_state"] = module_state
    cached["panel_api"] = panel_api
    return cached


def load_module_namespace(context, scene, workflow, module, name, allow_writes=False, persist_state=False, source_token=None):
    if source_token is None:
        source_token = module_source_fast_token(module)
    if not allow_writes and not persist_state:
        cached = cached_module_namespace(scene, workflow, module, name, source_token=source_token)
        if cached is not None:
            return reuse_cached_module_namespace(cached, context, scene, workflow, module, name, allow_writes=allow_writes)
    source, source_signature = get_cached_module_source(module, name)
    source = source.strip()
    if source:
        if not allow_writes and not persist_state:
            cached = cached_module_namespace(scene, workflow, module, name, source_signature)
            if cached is not None:
                return reuse_cached_module_namespace(cached, context, scene, workflow, module, name, allow_writes=allow_writes)
        return execute_module_source(
            source,
            context,
            scene,
            workflow,
            module,
            name,
            allow_writes=allow_writes,
            persist_state=persist_state,
        )

    filepath = module_script_abspath(module)
    if not filepath or not os.path.isfile(filepath):
        raise FileNotFoundError("自定义模块脚本文件不存在，且当前模板里没有可执行代码。")
    source = read_cached_text_file(filepath)
    source_signature = source_cache_signature(source, filepath)
    if not allow_writes and not persist_state:
        cached = cached_module_namespace(scene, workflow, module, filepath, source_signature)
        if cached is not None:
            panel_api = cached.get("panel_api")
            module_state = cached.get("module_state")
            if panel_api is not None:
                panel_api.context = context
                panel_api.scene = scene
                panel_api.workflow = workflow
                panel_api.module = module
                panel_api.allow_writes = allow_writes
                try:
                    panel_api.space_type = current_space_type(context=context)
                except Exception:
                    pass
                try:
                    panel_api.field_specs.clear()
                except Exception:
                    panel_api.field_specs = []
            else:
                module_state, panel_api = module_runtime_context(
                    context,
                    scene,
                    workflow,
                    module,
                    allow_writes=allow_writes,
                )
            cached["__name__"] = filepath
            cached["__file__"] = filepath
            cached["bpy"] = bpy
            cached["context"] = context
            cached["scene"] = scene
            cached["workflow"] = workflow
            cached["module"] = module
            cached["module_state"] = module_state
            cached["panel_api"] = panel_api
            return cached
    return execute_module_source(
        source,
        context,
        scene,
        workflow,
        module,
        filepath,
        allow_writes=allow_writes,
        persist_state=persist_state,
    )


def drain_validation_timer_callbacks():
    registry_key = "go_workflow.validation_timer_callbacks"
    try:
        registry = bpy.app.driver_namespace.get(registry_key)
    except Exception:
        registry = None
    if not registry:
        return 0
    callbacks = list(registry)
    try:
        registry.clear()
    except Exception:
        pass
    removed = 0
    for callback in callbacks:
        try:
            bpy.app.timers.unregister(callback)
        except Exception:
            pass
        removed += 1
    try:
        bpy.app.driver_namespace.pop(registry_key, None)
    except Exception:
        pass
    return removed


def cleanup_module_runtimes(context=None):
    context = context or getattr(bpy, "context", None)
    try:
        drain_validation_timer_callbacks()
    except Exception:
        traceback.print_exc()
    scenes = list(iter_available_scenes())
    seen = set()
    for scene in scenes:
        if scene is None:
            continue
        for space_type in iter_supported_space_types():
            state = get_state(scene=scene, space_type=space_type)
            if state is None:
                continue
            for workflow in state.workflows:
                for module in workflow.modules:
                    key = (str(getattr(scene, "as_pointer", lambda: 0)() if scene is not None else 0), workflow.name, module.name)
                    if key in seen:
                        continue
                    source = current_module_script_source(workflow, module, prefer_text_block=True, allow_initialize=False).strip()
                    if "cleanup_runtime" not in source and "_VALIDATION_TIMER_STATE" not in source:
                        continue
                    seen.add(key)
                    try:
                        cached_cleanup = pop_module_runtime_cleanup(scene, workflow, module)
                        clear_cached_module_namespaces(scene, workflow, module)
                        if cached_cleanup is not None:
                            cleanup_fn = cached_cleanup.get("cleanup_runtime")
                            module_state = cached_cleanup.get("module_state")
                        else:
                            namespace = load_module_namespace(
                                context,
                                scene,
                                workflow,
                                module,
                                "__go_workflow_cleanup__",
                                allow_writes=True,
                                persist_state=False,
                            )
                            cleanup_fn = namespace.get("cleanup_runtime") or namespace.get("cleanup")
                            module_state = namespace.get("module_state")
                        if callable(cleanup_fn):
                            cleanup_fn(scene=scene, workflow=workflow, module=module, module_state=module_state)
                    except Exception:
                        traceback.print_exc()
    try:
        drain_validation_timer_callbacks()
    except Exception:
        traceback.print_exc()


def module_text_block_name(workflow, module):
    if module.text_block_name.strip():
        return module.text_block_name
    index = workflow_module_index(workflow, module)
    suffix = "" if index < 0 else f"_{index + 1:02d}"
    return (
        "Go工作流_"
        f"{safe_filename_component(workflow.name, 'workflow')}_"
        f"{safe_filename_component(module.name, 'module')}{suffix}.py"
    )


def module_description_text_block_name(workflow, module):
    index = workflow_module_index(workflow, module)
    suffix = "" if index < 0 else f"_{index + 1:02d}"
    return (
        "Go工作流说明_"
        f"{safe_filename_component(workflow.name, 'workflow')}_"
        f"{safe_filename_component(module.name, 'module')}{suffix}.txt"
    )


def find_text_block_for_filepath(filepath):
    target = normalized_abs_path(filepath)
    if not target:
        return None
    for text_block in bpy.data.texts:
        try:
            if normalized_abs_path(getattr(text_block, "filepath", "") or "") == target:
                return text_block
        except Exception:
            pass
    return None


def load_module_script_text_block_from_file(workflow, module, filepath, source):
    folder = os.path.dirname(filepath)
    if folder:
        os.makedirs(folder, exist_ok=True)
    if not os.path.isfile(filepath):
        with open(filepath, "w", encoding="utf-8") as handle:
            handle.write(source)

    text_block = find_text_block_for_filepath(filepath)
    if text_block is None:
        text_block = bpy.data.texts.load(filepath)
    try:
        text_block.name = module_text_block_name(workflow, module)
    except Exception:
        pass
    try:
        text_block.filepath = filepath
    except Exception:
        pass

    desired = source
    try:
        disk_source = read_cached_text_file(filepath)
        if disk_source != desired:
            with open(filepath, "w", encoding="utf-8") as handle:
                handle.write(desired)
    except Exception:
        pass
    if text_block.as_string() != desired:
        text_block.clear()
        text_block.write(desired)
    return text_block


def ensure_module_text_block(workflow, module):
    text_name = module_text_block_name(workflow, module)
    source = ensure_module_script_source(workflow, module)
    filepath = module_script_abspath(module)
    if filepath and filepath.lower().endswith(".py"):
        try:
            text_block = load_module_script_text_block_from_file(workflow, module, filepath, source)
            module.text_block_name = text_block.name
            return text_block
        except Exception:
            traceback.print_exc()

    text_block = bpy.data.texts.get(text_name)
    if text_block is None:
        text_block = bpy.data.texts.new(text_name)
    existing = text_block.as_string()
    if existing != source:
        text_block.clear()
        text_block.write(source)
    module.text_block_name = text_block.name
    return text_block


def ensure_module_description_text_block(workflow, module):
    text_name = module_description_text_block_name(workflow, module)
    text_block = bpy.data.texts.get(text_name)
    if text_block is None:
        text_block = bpy.data.texts.new(text_name)
    existing = text_block.as_string()
    desired = module.description or ""
    if existing != desired:
        text_block.clear()
        text_block.write(desired)
    return text_block


def sync_module_description_from_text_block(workflow, module):
    text_block = bpy.data.texts.get(module_description_text_block_name(workflow, module))
    if text_block is None:
        return False
    module.description = text_block.as_string()
    return True


def sync_module_source_from_text_block(module):
    text_name = module.text_block_name.strip()
    if not text_name:
        return False
    text_block = bpy.data.texts.get(text_name)
    if text_block is None:
        return False
    module.script_source = text_block.as_string()
    return True


def sync_module_source_from_file(module):
    raw_path = (getattr(module, "script_path", "") or "").strip()
    if not raw_path:
        return False
    filepath = bpy.path.abspath(raw_path)
    if not filepath or not os.path.isfile(filepath):
        return False
    try:
        module.script_source = read_cached_text_file(filepath)
        return True
    except Exception:
        return False


def apply_module_script_source_update(context, workflow, module, source, sync_text_block=True, refresh_runtime=True):
    state = get_state(context=context)
    module.script_source = str(source or "").lstrip("\ufeff")
    if state is not None:
        state.module_editor_text = module.script_source

    old_text_name = str(getattr(module, "text_block_name", "") or "").strip()
    if old_text_name:
        MODULE_SOURCE_TEXT_CACHE.pop(old_text_name, None)

    text_block = None
    if sync_text_block:
        text_block = ensure_module_text_block(workflow, module)
        MODULE_SOURCE_TEXT_CACHE.pop(getattr(text_block, "name", ""), None)

    clear_cached_module_namespaces(getattr(context, "scene", None), workflow, module)
    if refresh_runtime:
        initialize_module_runtime_fields(context.scene, workflow, module, context=context)
        rebuild_runtime_panels(scene=context.scene, rebuild_cache=False)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.1, 0.35))
        tag_redraw_all()
    save_global_workflow_state(context.scene)
    return text_block


def sync_all_module_sources_from_text_blocks(scene=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False

    changed = False
    for space_type in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=space_type)
        if state is None:
            continue
        for workflow in state.workflows:
            for module in workflow.modules:
                if sync_module_source_from_text_block(module):
                    changed = True
    return changed


def sync_all_module_descriptions_from_text_blocks(scene=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False

    changed = False
    for space_type in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=space_type)
        if state is None:
            continue
        for workflow in state.workflows:
            for module in workflow.modules:
                if sync_module_description_from_text_block(workflow, module):
                    changed = True
    return changed


def module_has_custom_panel_source(module):
    source = (module.script_source or "").strip()
    if not source:
        return False
    return bool(re.search(r"^\s*def\s+draw_panel\s*\(", source, flags=re.MULTILINE))


def module_needs_runtime_panel(module):
    if module is None or not module.enabled:
        return False
    return bool(module.use_custom_panel)


def initialize_module_runtime_fields(scene, workflow, module, context=None, source_token=None, defer_sync=False):
    if scene is None or workflow is None or module is None:
        return False

    cache_key = module_runtime_cleanup_cache_key(scene, workflow, module)
    if source_token is None:
        source_token = module_source_fast_token(module)
    cached = MODULE_RUNTIME_FIELD_INIT_CACHE.get(cache_key)
    if isinstance(cached, dict) and cached.get("source_token") == source_token:
        cached_specs = cached.get("field_specs")
        if not cached_specs:
            cached_specs = load_module_runtime_specs(scene, workflow, module)
        if defer_sync:
            return queue_module_runtime_field_specs_sync(scene, workflow, module, cached_specs)
        return sync_module_runtime_field_specs(scene, workflow, module, cached_specs)

    source, source_signature = get_cached_module_source(module, "__go_workflow_init__")
    source = source.strip()
    if not source:
        return False

    if isinstance(cached, dict) and cached.get("source_signature") == source_signature:
        cached["source_token"] = source_token
        return False

    field_specs = []
    try:
        execute_module_source(
            source,
            context or bpy.context,
            scene,
            workflow,
            module,
            "__go_workflow_init__",
            allow_writes=False,
            persist_state=False,
            field_specs=field_specs,
        )
    except Exception:
        return False
    MODULE_RUNTIME_NAMESPACE_CACHE.pop(module_runtime_namespace_cache_key(scene, workflow, module, "__go_workflow_init__"), None)

    if defer_sync:
        changed = queue_module_runtime_field_specs_sync(scene, workflow, module, field_specs)
    else:
        changed = sync_module_runtime_field_specs(scene, workflow, module, field_specs)
    MODULE_RUNTIME_FIELD_INIT_CACHE[cache_key] = {
        "source_signature": source_signature,
        "source_token": source_token,
        "field_specs": list(field_specs),
    }
    return changed


def initialize_all_module_runtime_fields(scene=None, context=None):
    target_scene = scene or safe_context_scene()
    if target_scene is None:
        return False

    changed = False
    for space_type in iter_supported_space_types():
        state = get_state(scene=target_scene, space_type=space_type)
        workflow = get_active_workflow(state)
        if workflow is None:
            continue
        for module in workflow.modules:
            if not module_needs_runtime_panel(module):
                continue
            sync_module_source_from_text_block(module)
            if initialize_module_runtime_fields(target_scene, workflow, module, context=context):
                changed = True
    return changed


def module_runtime_field_value(scene, workflow, module, key, kind, default=None):
    scene_value, scene_prop_key = module_runtime_field_scene_value(scene, workflow, module, key, kind, default)
    if scene_prop_key:
        return scene_value

    module_store = ensure_module_runtime_store(scene, workflow, module, allow_writes=False)
    if kind == "object":
        return str(module_store.get(key, default or ""))
    return module_store.get(key, default)


def callable_accepts_panel_api(callback):
    try:
        signature = inspect.signature(callback)
    except Exception:
        return False
    positional_count = 0
    for parameter in signature.parameters.values():
        if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
            return True
        if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD):
            positional_count += 1
    return positional_count >= 7


class BWFLOW_OT_module_runtime_field_write(Operator):
    bl_idname = "bworkflow.module_runtime_field_write"
    bl_label = "写入自定义字段"
    bl_description = "为自定义脚本模块写入一个运行时字段值"
    bl_options = {"REGISTER", "UNDO"}

    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    space_type: StringProperty(default="")
    field_key: StringProperty(default="")
    field_kind: StringProperty(default="text")
    text_value: StringProperty(default="")
    bool_value: BoolProperty(default=False)
    float_value: FloatProperty(default=0.0)
    int_value: IntProperty(default=0)
    object_name: StringProperty(default="")
    data_collection: StringProperty(default="")
    read_from_scene: BoolProperty(default=False)

    def invoke(self, context, event):
        field_kind = (self.field_kind or "text").strip()
        if field_kind in {"bool", "enum"}:
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        field_kind = (self.field_kind or "text").strip()
        if field_kind == "float":
            layout.prop(self, "float_value", text=self.field_key or "数值")
        elif field_kind == "int":
            layout.prop(self, "int_value", text=self.field_key or "整数")
        elif field_kind == "object":
            layout.prop_search(self, "object_name", bpy.data, "objects", text=self.field_key or "物体")
        elif field_kind.startswith("datablock_"):
            collection_name = (self.data_collection or field_kind.removeprefix("datablock_") or "").strip()
            if collection_name and hasattr(bpy.data, collection_name):
                try:
                    layout.prop_search(self, "text_value", bpy.data, collection_name, text=self.field_key or "数据块")
                except Exception:
                    layout.prop(self, "text_value", text=self.field_key or "数据块")
            else:
                layout.prop(self, "text_value", text=self.field_key or "数据块")
        else:
            layout.prop(self, "text_value", text=self.field_key or "内容")

    def execute(self, context):
        scene = context.scene
        if scene is None:
            return {"CANCELLED"}

        target_workflow, target_module = resolve_workflow_module(
            scene,
            self.workflow_name,
            self.module_name,
            space_type=self.space_type or current_space_type(context=context),
        )

        if target_workflow is None or target_module is None:
            return {"CANCELLED"}

        field_kind = (self.field_kind or "text").strip()
        prop_keys = module_scene_prop_key_candidates(target_workflow, target_module, self.field_key, kind=field_kind)
        prop_key = prop_keys[0] if prop_keys else ""
        module_store = ensure_module_runtime_store(scene, target_workflow, target_module, allow_writes=True)

        if self.read_from_scene:
            raw_scene_value, found_prop_key = module_runtime_field_scene_value(
                scene, target_workflow, target_module, self.field_key, field_kind, None
            )
        else:
            raw_scene_value, found_prop_key = (None, "")
        if self.read_from_scene and found_prop_key:
            if field_kind == "float":
                value = float(raw_scene_value)
            elif field_kind == "int":
                value = int(raw_scene_value)
            elif field_kind == "bool":
                value = bool(raw_scene_value)
            elif field_kind == "object":
                value = str(raw_scene_value or "")
            else:
                value = str(raw_scene_value or "")
        elif field_kind == "bool":
            value = bool(self.bool_value)
        elif field_kind == "float":
            value = float(self.float_value)
        elif field_kind == "int":
            value = int(self.int_value)
        elif field_kind == "object":
            value = str(self.object_name or "")
        else:
            value = str(self.text_value or "")

        if module_scene_prop_key_usable(prop_key):
            try:
                scene[prop_key] = value
            except Exception:
                pass
        module_store[self.field_key] = value
        merge_module_runtime_store(scene, target_workflow, target_module, module_store)
        try:
            namespace = load_module_namespace(
                context,
                scene,
                target_workflow,
                target_module,
                "__go_workflow_runtime_field_write__",
                allow_writes=True,
                persist_state=False,
            )
            action_fn = namespace.get("on_panel_action")
            if callable(action_fn):
                result = action_fn(
                    f"FIELD_WRITE::{self.field_key}",
                    context,
                    scene,
                    target_workflow,
                    target_module,
                    namespace.get("panel_api"),
                    namespace.get("module_state"),
                )
                if namespace.get("module_state") is not None and hasattr(namespace["module_state"], "to_dict"):
                    merge_module_runtime_store(scene, target_workflow, target_module, namespace["module_state"].to_dict())
                if isinstance(result, set) and "CANCELLED" in result:
                    return result
        except BaseException:
            traceback.print_exc()
        tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_module_runtime_action(Operator):
    bl_idname = "bworkflow.module_runtime_action"
    bl_label = "执行自定义面板动作"
    bl_description = "执行自定义脚本面板里的按钮动作"
    bl_options = {"REGISTER", "UNDO"}

    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    space_type: StringProperty(default="")
    action_name: StringProperty(default="")
    tooltip_text: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        text = getattr(properties, "tooltip_text", "") or ""
        return text or cls.bl_description

    def execute(self, context):
        scene = context.scene
        if scene is None:
            return {"CANCELLED"}

        target_workflow, target_module = resolve_workflow_module(
            scene,
            self.workflow_name,
            self.module_name,
            space_type=self.space_type or current_space_type(context=context),
        )

        if target_workflow is None or target_module is None:
            self.report({"ERROR"}, "找不到目标工作流或模块")
            return {"CANCELLED"}

        try:
            namespace = load_module_namespace(
                context,
                scene,
                target_workflow,
                target_module,
                "__go_workflow_action__",
                allow_writes=True,
                persist_state=False,
            )
            action_fn = namespace.get("on_panel_action")
            if not callable(action_fn):
                self.report({"WARNING"}, "脚本没有定义 on_panel_action(...)")
                return {"CANCELLED"}
            result = action_fn(
                self.action_name,
                context,
                scene,
                target_workflow,
                target_module,
                namespace.get("panel_api"),
                namespace.get("module_state"),
            )
            module_state = namespace.get("module_state")
            if module_state is not None and hasattr(module_state, "to_dict"):
                merge_module_runtime_store(scene, target_workflow, target_module, module_state.to_dict())
            tag_redraw_all()
            if isinstance(result, set):
                return result
            return {"FINISHED"}
        except BaseException as exc:
            traceback.print_exc()
            self.report({"ERROR"}, f"自定义面板动作失败: {exc}")
            return {"CANCELLED"}


class BWFLOW_OT_copy_runtime_error(Operator):
    bl_idname = "bworkflow.copy_runtime_error"
    bl_label = "复制错误"
    bl_description = "把当前自定义面板错误复制到系统剪贴板"

    error_text: StringProperty(default="")

    def execute(self, context):
        text = str(self.error_text or "").strip()
        if not text:
            self.report({"WARNING"}, "当前没有可复制的错误文本")
            return {"CANCELLED"}
        context.window_manager.clipboard = text
        self.report({"INFO"}, "错误文本已复制到剪贴板")
        return {"FINISHED"}


class BWFLOW_OT_open_runtime_error_report(Operator):
    bl_idname = "bworkflow.open_runtime_error_report"
    bl_label = "打开错误报告"
    bl_description = "把当前自定义面板错误写入临时文本块，方便在文本编辑器中框选复制"

    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    error_text: StringProperty(default="")

    def execute(self, context):
        error_text = str(self.error_text or "").strip()
        if not error_text:
            self.report({"WARNING"}, "当前没有可打开的错误文本")
            return {"CANCELLED"}
        title = f"Go工作流错误_{safe_filename_component(self.workflow_name or 'workflow', 'workflow')}_{safe_filename_component(self.module_name or 'module', 'module')}.txt"
        body = "\n".join(
            [
                f"工作流: {self.workflow_name}",
                f"模块: {self.module_name}",
                "",
                "错误报告:",
                error_text,
            ]
        )
        text_block = ensure_runtime_report_text_block(title, body)
        scripting_workspace = find_workspace_by_name("Scripting")
        activate_text_editor_for_text(context, text_block, workspace=scripting_workspace)
        self.report({"INFO"}, "已打开错误报告文本，可直接框选复制")
        return {"FINISHED"}


def draw_module_runtime_panel(card, context, workflow, module):
    try:
        source_token = module_source_fast_token(module)
        # 原生 layout.prop(...) 依赖 scene 上已经存在对应的运行时字段。
        # 面板绘制阶段仍保持模块自身 allow_writes=False，但先由宿主补齐字段初始化。
        try:
            initialize_module_runtime_fields(
                context.scene,
                workflow,
                module,
                context=context,
                source_token=source_token,
                defer_sync=True,
            )
        except Exception:
            pass
        result = load_module_namespace(context, context.scene, workflow, module, "__go_workflow_panel__", source_token=source_token)
        draw_fn = result.get("draw_panel")
        if callable(draw_fn):
            panel_api = result.get("panel_api")
            module_state = result.get("module_state")
            if callable_accepts_panel_api(draw_fn):
                draw_fn(
                    card,
                    context,
                    context.scene,
                    workflow,
                    module,
                    panel_api,
                    module_state,
                )
            else:
                draw_fn(card, context, context.scene, workflow, module)
            if panel_api is not None:
                queue_module_runtime_field_specs_sync(
                    context.scene,
                    workflow,
                    module,
                    getattr(panel_api, "field_specs", ()),
                )
            return
        card.label(text="脚本里没有 draw_panel(...)，当前模块不显示自定义面板。", icon="INFO")
    except BaseException as exc:
        traceback.print_exc()
        card.alert = True
        card.label(text=f"自定义面板绘制失败: {exc}", icon="ERROR")
        actions = card.row(align=True)
        copy_op = actions.operator("bworkflow.copy_runtime_error", text="复制错误", icon="COPYDOWN")
        copy_op.error_text = f"自定义面板绘制失败: {exc}"
        open_op = actions.operator("bworkflow.open_runtime_error_report", text="打开错误报告", icon="TEXT")
        open_op.workflow_name = getattr(workflow, "name", "")
        open_op.module_name = getattr(module, "name", "")
        open_op.error_text = f"自定义面板绘制失败: {exc}"


def find_workspace_by_name(name):
    try:
        return bpy.data.workspaces.get(name)
    except Exception:
        return None


def startup_blend_candidates():
    candidates = []
    for resource_type in ("USER", "LOCAL", "SYSTEM"):
        try:
            path = bpy.utils.user_resource("CONFIG", path="startup.blend") if resource_type == "USER" else os.path.join(bpy.utils.resource_path(resource_type), "startup.blend")
            if path and path not in candidates:
                candidates.append(path)
        except Exception:
            pass
    return [path for path in candidates if os.path.isfile(path)]


def ensure_scripting_workspace(context=None):
    workspace = find_workspace_by_name("Scripting")
    if workspace is not None:
        return workspace

    window = getattr(context or bpy.context, "window", None)
    for filepath in startup_blend_candidates():
        try:
            if window is not None:
                with (context or bpy.context).temp_override(window=window):
                    bpy.ops.workspace.append_activate(idname="Scripting", filepath=filepath)
            else:
                bpy.ops.workspace.append_activate(idname="Scripting", filepath=filepath)
        except Exception:
            continue
        workspace = find_workspace_by_name("Scripting")
        if workspace is not None:
            return workspace
    return find_workspace_by_name("Scripting")


def assign_text_to_screen(screen, text_block):
    if screen is None:
        return False

    for area in screen.areas:
        if area.type == "TEXT_EDITOR":
            try:
                area.spaces.active.text = text_block
                area.tag_redraw()
                return True
            except Exception:
                traceback.print_exc()
    return False


def assign_text_to_converted_area(screen, text_block, preferred_area=None):
    if screen is None or text_block is None:
        return False
    candidates = []
    preferred_area_in_screen = preferred_area is not None and any(area == preferred_area for area in screen.areas)
    if preferred_area_in_screen and getattr(preferred_area, "type", None) not in {"TOPBAR", "STATUSBAR"}:
        candidates.append(preferred_area)
    for area in screen.areas:
        if area not in candidates and area.type not in {"TOPBAR", "STATUSBAR"}:
            candidates.append(area)
    candidates.sort(key=lambda area: (0 if area is preferred_area else 1, -(area.width * area.height)))
    for area in candidates:
        try:
            area.type = "TEXT_EDITOR"
            area.spaces.active.text = text_block
            area.tag_redraw()
            return True
        except Exception:
            traceback.print_exc()
    return False


def iter_window_screens():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return []
    result = []
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is not None:
            result.append((window, screen))
    return result


def find_window_for_workspace(workspace):
    if workspace is None:
        return None
    for window, _screen in iter_window_screens():
        if getattr(window, "workspace", None) == workspace:
            return window
    return None


def activate_text_editor_for_text(context, text_block, workspace=None):
    if workspace is not None:
        workspace_window = find_window_for_workspace(workspace)
        if workspace_window is not None and assign_text_to_screen(getattr(workspace_window, "screen", None), text_block):
            return "workspace_window"

    window = getattr(context, "window", None)
    if workspace is not None:
        if window is None:
            return None
        previous_workspace = getattr(window, "workspace", None)
        if previous_workspace != workspace:
            try:
                window.workspace = workspace
            except Exception:
                return None
        try:
            with context.temp_override(window=window, screen=window.screen):
                if assign_text_to_screen(window.screen, text_block):
                    return "scripting_workspace"
        except Exception:
            traceback.print_exc()
        if assign_text_to_screen(window.screen, text_block):
            return "scripting_workspace"
        return None

    if window is not None and assign_text_to_screen(window.screen, text_block):
        return "current_window"
    return None


def ensure_runtime_report_text_block(name, content):
    text_name = str(name or "Go工作流_错误报告.txt")
    text_block = bpy.data.texts.get(text_name)
    if text_block is None:
        text_block = bpy.data.texts.new(text_name)
    desired = str(content or "")
    if text_block.as_string() != desired:
        text_block.clear()
        text_block.write(desired)
    return text_block


def open_path_in_file_explorer(path):
    target_path = (path or "").strip()
    if not target_path:
        raise ValueError("当前路径为空")

    normalized = bpy.path.abspath(target_path)
    if os.path.isfile(normalized):
        folder = os.path.dirname(normalized)
        if os.name == "nt":
            subprocess.Popen(["explorer", "/select,", normalized])
            return normalized
        target_path = folder
    elif not os.path.isdir(normalized):
        folder = os.path.dirname(normalized)
        if folder and os.path.isdir(folder):
            normalized = folder
        else:
            raise FileNotFoundError(f"路径不存在: {normalized}")

    if os.name == "nt":
        os.startfile(normalized)
    else:
        subprocess.Popen([normalized])
    return normalized


def write_module_source_file(workflow, module, script_source=None):
    ensure_module_script_path_matches_name(workflow, module)
    if not module.script_path.strip():
        module.script_path = unique_default_module_script_path(workflow, module)

    filepath = module_script_abspath(module)
    if not filepath.lower().endswith(".py"):
        raise ValueError("脚本模板目前只支持写入 .py 文件")

    source = script_source if script_source is not None else ensure_module_script_source(workflow, module)
    folder = os.path.dirname(filepath)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as handle:
        handle.write(source)
    return filepath


def write_json_payload_file(filepath, payload):
    target_path = bpy.path.abspath(str(filepath or "").strip())
    if not target_path:
        raise ValueError("导出路径为空")
    folder = os.path.dirname(target_path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(target_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    return target_path


def open_module_script_directory(workflow, module):
    ensure_module_script_path_matches_name(workflow, module)
    filepath = module_script_abspath(module)
    folder = filepath if os.path.isdir(filepath) else os.path.dirname(filepath)
    if not folder:
        folder = default_module_scripts_dir()
    os.makedirs(folder, exist_ok=True)
    if os.name == "nt":
        os.startfile(folder)
    else:
        subprocess.Popen([folder])
    return folder


def force_reload_script_panels(scene=None, space_type=None, restore_first=True):
    initialize_all_module_runtime_fields(scene=scene)
    changed = False
    target_spaces = (space_type,) if space_type else iter_supported_space_types()
    for target_space in target_spaces:
        state = get_state(scene=scene, space_type=target_space)
        if state is None:
            continue
        workflow = get_active_workflow(state)
        if workflow is None or workflow.is_default:
            clear_panel_order_overrides(space_type=target_space)
            continue
        ordered_ids = workflow_ordered_panel_ids(state, workflow)

        if restore_first:
            restore_unregistered_panels(space_type=target_space)
            changed = True
        if getattr(state, "panel_order_pending_apply", False):
            continue
        previous_order_signature = PANEL_ORDER_SIGNATURE_BY_SPACE.get(target_space)
        apply_panel_order_overrides(ordered_ids, space_type=target_space)
        if previous_order_signature != PANEL_ORDER_SIGNATURE_BY_SPACE.get(target_space):
            changed = True
    return changed


def on_workflow_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    state = get_state(context=context)
    if state is None:
        return
    clamped = clamp_index(state.active_workflow_index, len(state.workflows))
    if clamped != state.active_workflow_index:
        state.active_workflow_index = clamped
        return
    ensure_one_default_workflow(state)
    schedule_deferred_workflow_switch_refresh(
        scene=getattr(context, "scene", None),
        space_type=getattr(state, "space_type", current_space_type(context=context)),
    )
    tag_redraw_context_area(context)


def on_workflow_name_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    tag_redraw_all()


def on_module_name_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    scene = getattr(context, "scene", None) or safe_context_scene()
    if scene is None:
        tag_redraw_all()
        return
    for space_type in iter_supported_space_types():
        state = get_state(scene=scene, space_type=space_type)
        if state is None:
            continue
        for workflow in state.workflows:
            for module in workflow.modules:
                if module != self:
                    continue
                ensure_module_script_path_matches_name(workflow, module)
                save_global_workflow_state(scene)
                tag_redraw_all()
                return
    tag_redraw_all()


def on_module_runtime_panel_expanded_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    try:
        scene = getattr(context, "scene", None)
        if scene is not None and not bool(getattr(self, "runtime_panel_expanded", True)):
            for space_type in iter_supported_space_types():
                state = get_state(scene=scene, space_type=space_type)
                if state is None:
                    continue
                for workflow in state.workflows:
                    for module in workflow.modules:
                        if module != self:
                            continue
                        script_source = str(getattr(module, "script_source", "") or "").strip()
                        script_path = str(getattr(module, "script_path", "") or "").strip()
                        script_file_exists = bool(
                            script_path
                            and os.path.isfile(bpy.path.abspath(script_path))
                        )
                        if not script_source and not script_file_exists:
                            break
                        namespace = load_module_namespace(
                            context,
                            scene,
                            workflow,
                            module,
                            "__go_workflow_panel_collapse__",
                            allow_writes=True,
                            persist_state=False,
                        )
                        cleanup_fn = namespace.get("on_panel_collapse")
                        if callable(cleanup_fn):
                            cleanup_fn(scene=scene, workflow=workflow, module=module, module_state=namespace.get("module_state"))
                        break
                    else:
                        continue
                    break
        save_global_workflow_state(scene)
    except Exception:
        traceback.print_exc()
    tag_redraw_all()


def on_filter_config_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    try:
        scene = context.scene
    except Exception:
        scene = safe_context_scene()
    if scene is not None:
        rebuild_runtime_panels(scene=scene)
        schedule_deferred_runtime_refresh(scene=scene, intervals=(0.25,))


def on_ui_text_fold_changed(self, context):
    if IS_INITIALIZING_ADDON:
        return
    try:
        save_global_workflow_state(getattr(context, "scene", None))
    except Exception:
        traceback.print_exc()
    tag_redraw_all()


class BWFLOW_PG_PanelRecord(PropertyGroup):
    panel_id: StringProperty()
    title: StringProperty()
    category: StringProperty()
    tags: StringProperty(
        name="面板标签",
        default="",
        description="用英文逗号分隔，例如 model,uv,render",
        update=on_filter_config_changed,
    )
    source_module: StringProperty()
    addon_version: StringProperty(default="")
    discovered: BoolProperty(default=False)


class BWFLOW_PG_ScriptLibraryItem(PropertyGroup):
    name: StringProperty(
        name="脚本名称",
        default="新脚本",
        description="脚本库里显示的名称",
    )
    description: StringProperty(
        name="脚本说明",
        default="",
        description="脚本库条目的用途说明",
    )
    tags: StringProperty(
        name="脚本标签",
        default="",
        description="用英文逗号分隔，方便按主题检索",
    )
    use_custom_panel: BoolProperty(
        name="需要自定义面板",
        default=False,
        description="从脚本库载入后是否在 Go工作流 主面板显示自定义 UI",
    )
    panel_title: StringProperty(
        name="面板标题",
        default="",
        description="脚本库条目对应的自定义面板标题",
    )
    panel_description: StringProperty(
        name="面板说明",
        default="",
        description="脚本库条目对应的自定义面板说明",
    )
    script_path: StringProperty(
        name="脚本路径",
        default="",
        description="脚本文件路径，便于回到原始文件",
        subtype="FILE_PATH",
    )
    text_block_name: StringProperty(
        name="文本块名称",
        default="",
        description="关联的 Blender 文本块名称",
    )
    script_source: StringProperty(
        name="脚本源码",
        default="",
        description="可复用的脚本源码内容",
    )
    config_payload: StringProperty(
        name="模块配置",
        default="",
        description="随脚本条目一起保存的附加配置文本，例如 csv 或 json",
    )
    ai_doc: StringProperty(
        name="AI 文档",
        default="",
        description="脚本相关的说明文档，便于下次继续开发",
    )


class BWFLOW_PG_WorkflowPanel(PropertyGroup):
    panel_id: StringProperty()


class BWFLOW_PG_WorkflowModule(PropertyGroup):
    name: StringProperty(name="模块名称", default="新模块", update=on_module_name_changed)
    enabled: BoolProperty(name="启用", default=True)
    use_custom_panel: BoolProperty(
        name="需要自定义面板",
        default=False,
        description="启用后，会在 Go工作流 主面板里为这个模块预留一个自定义操作区域",
    )
    runtime_panel_expanded: BoolProperty(
        name="展开自定义面板",
        default=True,
        description="控制 Go工作流 主面板中当前模块的自定义 UI 是否展开",
        update=on_module_runtime_panel_expanded_changed,
    )
    runtime_description_expanded: BoolProperty(
        name="展开模块说明",
        default=False,
        description="控制 Go工作流 主面板中当前模块说明是否展开",
    )
    panel_title: StringProperty(
        name="面板标题",
        default="",
        description="仅在需要自定义面板时使用，留空则使用模块名称",
    )
    panel_description: StringProperty(
        name="面板说明",
        default="",
        description="仅在需要自定义面板时使用，用于描述这个模块面板放什么内容",
    )
    script_path: StringProperty(
        name="脚本路径",
        default="",
        description="用于挂载 Blender Python 脚本模板或实际执行脚本",
        subtype="FILE_PATH",
    )
    description: StringProperty(
        name="模块说明",
        default="",
        description="记录该模块用途、输入输出约定或批处理说明",
    )
    text_block_name: StringProperty(
        name="文本编辑器名称",
        default="",
        description="绑定到当前模块的 Blender 文本数据块名称",
    )
    script_source: StringProperty(
        name="脚本源码",
        default="",
        description="用于在插件内部直接编辑并写入 .py 文件的源代码文本",
    )
    config_payload: StringProperty(
        name="模块配置",
        default="",
        description="随工作流模块一起导出的附加配置文本，例如 csv 或 json",
    )
    ai_doc: StringProperty(
        name="AI 文档",
        default="",
        description="提供给你自己的 AI 用于继续开发这个模块",
    )


class BWFLOW_PG_PresetWorkflowItem(PropertyGroup):
    selected: BoolProperty(name="导入", default=True)
    name: StringProperty(default="")
    source_space_type: StringProperty(default="VIEW_3D")
    source_label: StringProperty(default="")
    source_key: StringProperty(default="")
    panel_count: IntProperty(default=0)
    module_count: IntProperty(default=0)
    is_default: BoolProperty(default=False)


class BWFLOW_PG_Workflow(PropertyGroup):
    name: StringProperty(name="名称", default="新工作流", update=on_workflow_name_changed)
    is_default: BoolProperty(default=False)
    preset_export_selected: BoolProperty(name="导出", default=True)
    description: StringProperty(
        name="工作流说明",
        default="",
        description="仅用于记录用途与说明，不影响工作流切换逻辑",
    )
    tag_filter: StringProperty(
        name="按标签自动加入",
        default="",
        description="用英文逗号分隔；带这些标签的面板会自动加入该工作流显示结果",
        update=on_filter_config_changed,
    )
    missing_warning_dismissed: BoolProperty(default=False)
    panels: CollectionProperty(type=BWFLOW_PG_WorkflowPanel)
    active_panel_index: IntProperty(default=0)
    modules: CollectionProperty(type=BWFLOW_PG_WorkflowModule)
    active_module_index: IntProperty(default=0)


class BWFLOW_PG_Settings(PropertyGroup):
    runtime_initialized: BoolProperty(
        name="Go工作流已初始化",
        default=False,
    )
    auto_sync_registry: BoolProperty(
        name="刷新时同步面板库",
        default=True,
    )
    show_missing_summary: BoolProperty(
        name="显示缺失面板摘要",
        default=True,
    )
    runtime_preview_lines: IntProperty(
        name="说明预览行数",
        default=3,
        min=1,
        max=12,
    )
    show_workflow_description: BoolProperty(
        name="展开工作流说明",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_runtime_module_descriptions: BoolProperty(
        name="展开主面板模块说明",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_module_ai_doc_preview: BoolProperty(
        name="展开 AI 文档预览",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_script_library_source_preview: BoolProperty(
        name="展开脚本库源码预览",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_script_library_ai_doc_preview: BoolProperty(
        name="展开脚本库 AI 文档预览",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_help_text_blocks: BoolProperty(
        name="展开帮助说明",
        default=False,
        update=on_ui_text_fold_changed,
    )
    show_settings: BoolProperty(
        name="显示设置",
        default=False,
    )
    ui_tab: EnumProperty(
        name="设置页签",
        items=SETTINGS_TABS,
        default="WORKFLOWS",
    )
    auto_gc_enabled: BoolProperty(
        name="自动定时释放内存",
        description="面板滚动后定期调用 gc.collect() 回收不再使用的对象",
        default=False,
    )
    auto_gc_interval: IntProperty(
        name="自动释放间隔（秒）",
        description="两次自动内存回收之间的最小间隔",
        default=15,
        min=5,
        max=120,
    )


class BWFLOW_PG_State(PropertyGroup):
    space_type: StringProperty(default="VIEW_3D")
    workflows: CollectionProperty(type=BWFLOW_PG_Workflow)
    active_workflow_index: IntProperty(default=0, update=on_workflow_changed)
    panel_registry: CollectionProperty(type=BWFLOW_PG_PanelRecord)
    panel_registry_index: IntProperty(default=0)
    script_library: CollectionProperty(type=BWFLOW_PG_ScriptLibraryItem)
    script_library_index: IntProperty(default=0)
    panel_library_last_click_index: IntProperty(default=-1)
    panel_library_last_click_time: FloatProperty(default=0.0)
    panel_library_last_click_target: StringProperty(default="")
    panel_group_expanded_keys: StringProperty(default="")
    selected_group_expanded_keys: StringProperty(default="")
    panel_group_filter_text: StringProperty(default="")
    selected_panel_group_filter_text: StringProperty(default="")
    panel_group_page: IntProperty(default=0, min=0)
    selected_panel_group_page: IntProperty(default=0, min=0)
    panel_order_pending_apply: BoolProperty(default=False)
    panel_visibility_pending_apply: BoolProperty(default=False)
    preset_filepath: StringProperty(name="预设文件", default="", subtype="FILE_PATH")
    preset_workflows: CollectionProperty(type=BWFLOW_PG_PresetWorkflowItem)
    preset_workflow_index: IntProperty(default=0)
    preset_status: StringProperty(default="")
    module_editor_text: StringProperty(
        name="模块编辑器文本",
        default="",
        description="用于当前模块脚本内容编辑窗口的临时文本缓存",
    )
    settings: PointerProperty(type=BWFLOW_PG_Settings)


def on_shape_key_inspector_index_changed(self, context):
    items = getattr(self, "bwflow_shape_key_inspector_items", None)
    if items is None:
        return
    index = int(getattr(self, "bwflow_shape_key_inspector_index", -1) or -1)
    if index < 0 or index >= len(items):
        return
    item = items[index]
    object_name = str(getattr(item, "object_name", "") or "")
    key_index = int(getattr(item, "key_index", -1) or -1)
    if not object_name or key_index < 0:
        return
    obj = bpy.data.objects.get(object_name)
    if obj is None or getattr(obj, "type", None) != "MESH":
        return
    key_blocks = getattr(getattr(obj.data, "shape_keys", None), "key_blocks", None)
    if key_blocks is None or key_index >= len(key_blocks):
        return
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        obj.active_shape_key_index = key_index
    except Exception:
        pass


class BWFLOW_PG_ShapeKeyInspectorItem(PropertyGroup):
    object_name: StringProperty(default="")
    key_index: IntProperty(default=-1)
    key_name: StringProperty(default="")
    is_empty: BoolProperty(default=False)
    max_delta: FloatProperty(default=0.0)
    reference_name: StringProperty(default="Basis")


class BWFLOW_UL_workflows(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.name, icon="FILE_FOLDER")
        if item.is_default:
            row.label(text="默认", icon="HOME")
        elif index == data.active_workflow_index:
            row.label(text="当前", icon="RADIOBUT_ON")


class BWFLOW_UL_workflow_panels(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        state = get_state(context=context)
        record = find_registry_record(state, item.panel_id)
        title = clean_panel_title(record.title if record else "", item.panel_id)
        row = layout.row(align=True)
        row.alert = bool(record) and not record.discovered
        row.label(text=f"{index + 1:02d}", icon="SORTSIZE")
        row.label(text=title, icon="PLUGIN" if record and record.discovered else "ERROR")
        if item.panel_id == "BWFLOW_PT_workflow":
            row.label(text="固定保留", icon="PINNED")


class BWFLOW_UL_panel_library(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        workflow = get_active_workflow(data)
        selected_ids = {panel.panel_id for panel in workflow.panels} if workflow is not None else set()
        is_selected = item.panel_id in selected_ids
        plugin_title = panel_plugin_title(data, item.panel_id)
        child_depth = panel_child_depth(item.panel_id, getattr(data, "space_type", "VIEW_3D"))
        row = layout.row(align=True)
        row.alert = not item.discovered
        if index == 0:
            row.label(text=plugin_title, icon="GROUP")
        else:
            items = getattr(data, "panel_registry")
            prev_item = items[index - 1] if index - 1 >= 0 else None
            prev_plugin = panel_plugin_title(data, prev_item.panel_id) if prev_item is not None else ""
            if prev_plugin != plugin_title:
                row.label(text=plugin_title, icon="GROUP")
            else:
                row.label(text="", icon="BLANK1")
        op = row.operator(
            "bworkflow.panel_library_click",
            text=("    " * min(child_depth, 3)) + clean_panel_title(item.title, item.panel_id),
            icon="ERROR" if not item.discovered else ("CHECKBOX_HLT" if is_selected else "CHECKBOX_DEHLT"),
            emboss=False,
        )
        op.index = index

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        flags = [self.bitflag_filter_item] * len(items)
        order = helper.sort_items_by_name(items, "title")
        settings = getattr(data, "settings", None)
        if settings is None:
            return flags, order

        return flags, order


class BWFLOW_UL_workflow_modules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="")
        row.label(text=item.name or f"模块 {index + 1}", icon="CONSOLE")


class BWFLOW_UL_script_library(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.name or f"脚本 {index + 1}", icon="FILE_SCRIPT")
        if item.tags.strip():
            row.label(text=item.tags, icon="ASSET_MANAGER")


class BWFLOW_UL_preset_workflows(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        entry = preset_import_entry_at(data, index)
        workflow = entry.get("workflow", {}) if isinstance(entry, dict) else {}
        name = workflow.get("name", "") or f"Workflow {index + 1}"
        space_type = entry.get("space_type", "VIEW_3D") if isinstance(entry, dict) else "VIEW_3D"
        source_label = entry.get("source_label", "") if isinstance(entry, dict) else ""
        row.label(text=name, icon="HOME" if item.is_default else "FILE_FOLDER")
        row.label(text=source_label or SPACE_LABELS.get(space_type, space_type))
        row.label(text=f"{item.panel_count} 面板")
        row.label(text=f"{item.module_count} 模块")


class BWFLOW_UL_shape_key_inspector_results(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=f"{int(getattr(item, 'key_index', index))}. {getattr(item, 'key_name', '')}", icon="SHAPEKEY_DATA")
        row.label(text=f"{float(getattr(item, 'max_delta', 0.0)):.6g}", icon="DRIVER_DISTANCE")


class BWFLOW_OT_refresh_registry(Operator):
    bl_idname = "bworkflow.refresh_registry"
    bl_label = "刷新面板库"
    bl_description = "恢复并重新扫描当前编辑器的第三方 N 面板"

    def execute(self, context):
        restore_unregistered_panels()
        summary = refresh_all_panel_registries(context.scene)
        workflow = get_active_workflow(get_state(context=context))
        if workflow is not None and workflow.is_default:
            restore_default_n_panel_state(scene=context.scene, disable_filters=True, sync_registry_after_restore=False)
        else:
            rebuild_runtime_panels(scene=context.scene, rebuild_cache=False)
        save_global_workflow_state(context.scene)
        self.report(
            {"INFO"},
            f"面板库已刷新：新增 {summary['added_runtime']}，重复 {summary['removed_duplicates']}，失效 {summary['removed_stale']}，空记录 {summary['removed_empty']}",
        )
        return {"FINISHED"}


class BWFLOW_OT_initialize_defaults(Operator):
    bl_idname = "bworkflow.initialize_defaults"
    bl_label = "初始化默认工作流"
    bl_description = "创建默认工作流并刷新面板过滤"

    @classmethod
    def poll(cls, context):
        return get_state(context=context) is not None

    def execute(self, context):
        space_type = current_space_type(context)
        extend_pre_go_workflow_order_snapshot(space_type=space_type)
        created = ensure_minimum_setup(context.scene, restore_global=False, save_state=False)
        state = get_state(context=context, space_type=space_type)
        if state is not None and state.settings is not None:
            state.settings.runtime_initialized = True
        try:
            rebuild_panel_cache(scene=context.scene, space_type=space_type)
        except Exception:
            traceback.print_exc()
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,), space_type=space_type)
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "默认工作流已初始化" if created else "默认工作流已存在")
        return {"FINISHED"}


class BWFLOW_OT_release_memory(Operator):
    bl_idname = "bworkflow.release_memory"
    bl_label = "释放内存"
    bl_description = "调用 Windows EmptyWorkingSet 释放 Blender 占用的物理内存（与 Mem Reduct 原理相同）"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        result = _empty_working_set()
        if result is not None:
            before, after = result
            dropped = before - after
            if dropped > 0.5:
                self.report({"INFO"}, f"已释放 {dropped:.1f} MB（{before:.0f} → {after:.0f} MB）")
            else:
                self.report({"INFO"}, f"Working Set 已 trim（{before:.0f} → {after:.0f} MB，当前已较紧凑）")
        else:
            self.report({"WARNING"}, "EmptyWorkingSet 调用失败（仅支持 Windows）")
        return {"FINISHED"}


class BWFLOW_OT_reset_all_settings(Operator):
    bl_idname = "bworkflow.reset_all_settings"
    bl_label = "清除所有设置"
    bl_description = "清空所有 Go工作流 设置、工作流、脚本库和缓存，并恢复初始默认状态"

    @classmethod
    def poll(cls, context):
        return get_state(context=context) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        clear_panel_filter()
        uninstall_panel_poll_overrides()
        _cancel_tracked_one_shot_timers()

        scenes = list(iter_available_scenes())
        for scene in scenes:
            restore_default_n_panel_state(
                scene=scene,
                disable_filters=True,
                switch_workflow=True,
                sync_registry_after_restore=False,
            )
            clear_scene_go_workflow_runtime(scene)
            for space_type in iter_supported_space_types():
                state = get_state(scene=scene, space_type=space_type)
                if state is not None:
                    reset_space_state(state)
            prune_unreferenced_imported_preset_assets(scene=scene, max_delete=100000)

        filepath = global_workflow_state_path()
        for candidate in (filepath, filepath + ".bak"):
            if os.path.isfile(candidate):
                try:
                    os.remove(candidate)
                except Exception:
                    traceback.print_exc()

        PRESET_IMPORT_ENTRY_CACHE.clear()
        IMPORTED_PRESET_ASSET_PATH_CACHE.clear()
        PANEL_CLASS_CACHE_BY_SPACE.clear()
        PANEL_GROUP_ICON_CACHE_BY_SPACE.clear()
        PANEL_GROUP_INDEX_CACHE_BY_SPACE.clear()
        PANEL_DRAWER_ROOT_CACHE_BY_SPACE.clear()
        PANEL_LIBRARY_GROUPS_CACHE_BY_SPACE.clear()
        PANEL_LIBRARY_GROUP_ENTRY_CACHE_BY_SPACE.clear()
        SELECTED_PANEL_GROUPS_CACHE_BY_SPACE.clear()
        SELECTED_PANEL_GROUP_SUMMARY_CACHE_BY_SPACE.clear()
        PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.clear()
        PANEL_FILTER_SIGNATURE_BY_SPACE.clear()
        PANEL_ORDER_SIGNATURE_BY_SPACE.clear()
        ACTIVE_ALLOWED_PANEL_IDS_BY_SPACE.clear()
        RUNTIME_HIDDEN_PANEL_IDS_CACHE_BY_SPACE.clear()
        clear_pre_go_workflow_state()
        tag_redraw_all()
        self.report({"INFO"}, "已清除所有设置并恢复默认状态")
        return {"FINISHED"}


class BWFLOW_OT_restore_default_n_panels(Operator):
    bl_idname = "bworkflow.restore_default_n_panels"
    bl_label = "恢复默认 N 面板"
    bl_description = "恢复所有被 Go工作流 临时隐藏或排序过的第三方 N 面板"

    disable_addon: BoolProperty(default=False)
    uninstall_addon: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def invoke(self, context, event):
        if self.disable_addon or self.uninstall_addon:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        quarantine_broken_panel_polls()
        scenes = list(iter_available_scenes())
        for scene in scenes:
            restore_default_n_panel_state(scene=scene, disable_filters=True, sync_registry_after_restore=False)
        try:
            refresh_all_panel_registries(context.scene)
        except Exception:
            traceback.print_exc()
        save_global_workflow_state(context.scene)
        tag_redraw_all()

        if self.disable_addon or self.uninstall_addon:
            uninstall_addon = bool(self.uninstall_addon)

            def _disable_addon():
                quarantine_broken_panel_polls()
                for module_name in addon_module_candidates():
                    if uninstall_addon:
                        try:
                            bpy.ops.preferences.addon_remove(module=module_name)
                            return None
                        except Exception:
                            pass
                    try:
                        bpy.ops.preferences.addon_disable(module=module_name)
                        return None
                    except Exception:
                        pass
                print("[Go工作流] 无法通过 Blender Python API 禁用或卸载插件。")
                return None

            try:
                _register_one_shot_timer(_disable_addon, first_interval=0.1)
            except Exception:
                traceback.print_exc()
            if self.uninstall_addon:
                self.report({"INFO"}, "已恢复默认 N 面板，并尝试卸载 Go工作流。若文件未删除，请继续使用 Blender 插件列表卸载。")
            else:
                self.report({"INFO"}, "已恢复默认 N 面板，并准备禁用 Go工作流。文件卸载请继续使用 Blender 插件列表里的卸载按钮。")
        else:
            self.report({"INFO"}, "已恢复默认 N 面板")
        return {"FINISHED"}
def _safe_restore_default_n_panels_execute(self, context):
    quarantine_broken_panel_polls()
    scenes = list(iter_available_scenes())
    for scene in scenes:
        restore_default_n_panel_state(scene=scene, disable_filters=True, sync_registry_after_restore=False)
    try:
        save_global_workflow_state(context.scene)
    except Exception:
        traceback.print_exc()
    tag_redraw_all()

    if self.disable_addon or self.uninstall_addon:
        uninstall_addon = bool(self.uninstall_addon)

        def _disable_addon():
            quarantine_broken_panel_polls()
            for module_name in addon_module_candidates():
                if uninstall_addon:
                    try:
                        bpy.ops.preferences.addon_remove(module=module_name)
                        return None
                    except Exception:
                        pass
                try:
                    bpy.ops.preferences.addon_disable(module=module_name)
                    return None
                except Exception:
                    pass
            print("[GoWorkflow] unable to disable or remove addon via Blender Python API")
            return None

        try:
            _register_one_shot_timer(_disable_addon, first_interval=0.1)
        except Exception:
            traceback.print_exc()
        if uninstall_addon:
            self.report({"INFO"}, "已恢复默认 N 面板，并安排在 Blender 退出后删除插件目录。当前会话先安全禁用，避免闪退。")
        else:
            self.report({"INFO"}, "已恢复默认 N 面板，并准备安全禁用 Go Workflow。")
    else:
        self.report({"INFO"}, "已恢复默认 N 面板")
    return {"FINISHED"}


BWFLOW_OT_restore_default_n_panels.execute = _safe_restore_default_n_panels_execute


class BWFLOW_OT_workflow_activate(Operator):
    bl_idname = "bworkflow.workflow_activate"
    bl_label = "切换工作流"
    bl_description = "切换当前工作流，并按工作流隐藏或显示第三方 N 面板"

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(state.workflows)

    def execute(self, context):
        state = get_state(context=context)
        target_index = clamp_index(self.index, len(state.workflows))
        if target_index == state.active_workflow_index:
            return {"FINISHED"}
        state.active_workflow_index = target_index
        save_global_workflow_state(context.scene)
        return {"FINISHED"}


class BWFLOW_OT_workflow_add(Operator):
    bl_idname = "bworkflow.workflow_add"
    bl_label = "新建工作流"
    bl_description = "创建一个新的工作流"

    name: StringProperty(name="工作流名称", default="新工作流")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "name", text="名称")

    def execute(self, context):
        created = create_synced_workflow_for_all_spaces(context.scene, self.name.strip() or "新工作流")
        if not created:
            self.report({"ERROR"}, "无法创建工作流")
            return {"CANCELLED"}
        rebuild_runtime_panels(scene=context.scene)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        auto_count = sum(1 for space_type, _workflow in created if space_type != "VIEW_3D")
        self.report({"INFO"}, f"已同步新建工作流；{auto_count} 个非 3D 编辑器默认勾选全部面板")
        return {"FINISHED"}


class BWFLOW_OT_workflow_add_special_preset(Operator):
    bl_idname = "bworkflow.workflow_add_special_preset"
    bl_label = "创建特殊预设工作流"
    bl_description = "一键创建带专用模块与本地数据的特殊预设工作流"

    preset_type: StringProperty(default=SPECIAL_PRESET_ARKIT_52)

    def execute(self, context):
        created = create_special_preset_workflow(context.scene, self.preset_type)
        if not created:
            self.report({"ERROR"}, "特殊预设工作流创建失败")
            return {"CANCELLED"}
        rebuild_runtime_panels(scene=context.scene)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        spec = special_preset_spec(self.preset_type) or {}
        self.report({"INFO"}, f"已创建特殊预设工作流: {spec.get('workflow_name', '特殊预设')}")
        return {"FINISHED"}


class BWFLOW_OT_workflow_duplicate(Operator):
    bl_idname = "bworkflow.workflow_duplicate"
    bl_label = "复制工作流"
    bl_description = "复制当前工作流的面板、模块和说明，生成一个新的工作流"

    @classmethod
    def poll(cls, context):
        return get_active_workflow(get_state(context=context)) is not None

    def execute(self, context):
        state = get_state(context=context)
        source = get_active_workflow(state)
        workflow = state.workflows.add()
        workflow.name = unique_workflow_name(
            state,
            f"{normalize_workflow_name(source.name, '工作流')} Copy",
            fallback="复制工作流",
            exclude_index=len(state.workflows) - 1,
        )
        workflow.is_default = False
        workflow.description = source.description
        workflow.tag_filter = source.tag_filter
        workflow.missing_warning_dismissed = bool(getattr(source, "missing_warning_dismissed", False))

        for panel_id in workflow_explicit_panel_ids(source):
            item = workflow.panels.add()
            item.panel_id = panel_id

        for source_module in source.modules:
            module = workflow.modules.add()
            module.name = source_module.name
            module.enabled = source_module.enabled
            module.use_custom_panel = source_module.use_custom_panel
            module.runtime_panel_expanded = getattr(source_module, "runtime_panel_expanded", True)
            module.runtime_description_expanded = getattr(source_module, "runtime_description_expanded", False)
            module.panel_title = source_module.panel_title
            module.panel_description = source_module.panel_description
            module.description = source_module.description
            module.text_block_name = ""
            module.script_source = source_module.script_source
            module.ai_doc = source_module.ai_doc
            module.script_path = unique_default_module_script_path(workflow, module)

        workflow.active_panel_index = clamp_index(source.active_panel_index, len(workflow.panels))
        workflow.active_module_index = clamp_index(source.active_module_index, len(workflow.modules))
        state.active_workflow_index = len(state.workflows) - 1
        ensure_one_default_workflow(state)
        ensure_go_workflow_panel_entry(state)
        rebuild_runtime_panels(scene=context.scene)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "已复制当前工作流")
        return {"FINISHED"}


class BWFLOW_OT_workflow_remove(Operator):
    bl_idname = "bworkflow.workflow_remove"
    bl_label = "删除工作流"
    bl_description = "删除当前工作流，不会卸载任何第三方插件"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and len(state.workflows) > 1

    def execute(self, context):
        state = get_state(context=context)
        old_index = clamp_index(state.active_workflow_index, len(state.workflows))
        state.workflows.remove(old_index)
        state.active_workflow_index = clamp_index(old_index - 1, len(state.workflows))
        ensure_one_default_workflow(state)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.05, 0.25))
        tag_redraw_context_area(context)
        save_global_workflow_state(context.scene)
        prune_unreferenced_imported_preset_assets(scene=context.scene, max_delete=80)
        return {"FINISHED"}


class BWFLOW_OT_workflow_move(Operator):
    bl_idname = "bworkflow.workflow_move"
    bl_label = "移动工作流"
    bl_description = "调整工作流顺序"

    direction: StringProperty()

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and len(state.workflows) > 1

    def execute(self, context):
        state = get_state(context=context)
        old_index = clamp_index(state.active_workflow_index, len(state.workflows))
        new_index = old_index + (-1 if self.direction == "UP" else 1)
        new_index = clamp_index(new_index, len(state.workflows))
        if new_index == old_index:
            return {"CANCELLED"}
        state.workflows.move(old_index, new_index)
        state.active_workflow_index = new_index
        rebuild_runtime_panels(scene=context.scene)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        return {"FINISHED"}


class BWFLOW_OT_workflow_set_default(Operator):
    bl_idname = "bworkflow.workflow_set_default"
    bl_label = "设为默认工作流"
    bl_description = "默认工作流始终显示全部第三方 N 面板"

    @classmethod
    def poll(cls, context):
        return get_active_workflow(get_state(context=context)) is not None

    def execute(self, context):
        state = get_state(context=context)
        active = get_active_workflow(state)
        for workflow in state.workflows:
            workflow.is_default = workflow == active
        restore_default_n_panel_state(scene=context.scene, disable_filters=True, sync_registry_after_restore=False)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "已设为默认工作流")
        return {"FINISHED"}


class BWFLOW_OT_workflow_clear_description(Operator):
    bl_idname = "bworkflow.workflow_clear_description"
    bl_label = "清空工作流说明"
    bl_description = "清空当前工作流说明文本"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.description.strip())

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        workflow.description = ""
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "已清空当前工作流说明")
        return {"FINISHED"}


class BWFLOW_OT_module_add(Operator):
    bl_idname = "bworkflow.module_add"
    bl_label = "新增模块"
    bl_description = "为当前工作流新增一个脚本模块模板"

    name: StringProperty(name="模块名称", default="新模块")

    @classmethod
    def poll(cls, context):
        return get_active_workflow(get_state(context=context)) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "name", text="名称")

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules.add()
        module.name = self.name.strip() or "新模块"
        module.enabled = True
        module.use_custom_panel = False
        module.runtime_panel_expanded = True
        module.runtime_description_expanded = False
        module.panel_title = ""
        module.panel_description = ""
        module.script_path = unique_default_module_script_path(workflow, module)
        module.description = "在这里写这个模块要执行的批处理目标，例如整理材质、批量命名、渲染前检查等。"
        module.script_source = ""
        module.ai_doc = build_module_ai_doc(workflow, module)
        ensure_module_text_block(workflow, module)
        workflow.active_module_index = len(workflow.modules) - 1
        initialize_module_runtime_fields(context.scene, workflow, module, context=context)
        tag_redraw_all()
        schedule_deferred_runtime_refresh(scene=context.scene)
        save_global_workflow_state(context.scene)
        return {"FINISHED"}


class BWFLOW_OT_module_assign_default_path(Operator):
    bl_idname = "bworkflow.module_assign_default_path"
    bl_label = "生成默认路径"
    bl_description = "为当前模块生成默认 .py 脚本路径"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        module.script_path = ensure_module_script_path_matches_name(workflow, module, force=True)
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, f"已按模块名称生成脚本路径: {module.script_path}")
        return {"FINISHED"}


class BWFLOW_OT_module_remove(Operator):
    bl_idname = "bworkflow.module_remove"
    bl_label = "删除模块"
    bl_description = "删除当前工作流里选中的脚本模块"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        index = clamp_index(workflow.active_module_index, len(workflow.modules))
        workflow.modules.remove(index)
        workflow.active_module_index = clamp_index(index - 1, len(workflow.modules))
        save_global_workflow_state(context.scene)
        return {"FINISHED"}


class BWFLOW_OT_module_move(Operator):
    bl_idname = "bworkflow.module_move"
    bl_label = "移动模块"
    bl_description = "调整模块顺序"

    direction: StringProperty()

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and len(workflow.modules) > 1

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        old_index = clamp_index(workflow.active_module_index, len(workflow.modules))
        new_index = old_index + (-1 if self.direction == "UP" else 1)
        new_index = clamp_index(new_index, len(workflow.modules))
        if new_index == old_index:
            return {"CANCELLED"}
        workflow.modules.move(old_index, new_index)
        workflow.active_module_index = new_index
        save_global_workflow_state(context.scene)
        return {"FINISHED"}


class BWFLOW_OT_module_fill_ai_doc(Operator):
    bl_idname = "bworkflow.module_fill_ai_doc"
    bl_label = "生成智能辅助说明"
    bl_description = "为当前模块生成可直接发给智能辅助工具的开发说明"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        module.ai_doc = build_module_ai_doc(workflow, module)
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "智能辅助说明已生成")
        return {"FINISHED"}


class BWFLOW_OT_module_edit_script_source(Operator):
    bl_idname = "bworkflow.module_edit_script_source"
    bl_label = "在文本编辑器中打开"
    bl_description = "把当前模块脚本同步到 Blender 文本编辑器，并在文本编辑器中继续编辑"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        text_block = ensure_module_text_block(workflow, module)

        scripting_workspace = find_workspace_by_name("Scripting")
        if scripting_workspace is not None:
            result = activate_text_editor_for_text(context, text_block, workspace=scripting_workspace)
            if result in {"workspace_window", "scripting_workspace"}:
                self.report({"INFO"}, "已切换到 Scripting 工作区并打开当前模块")
                return {"FINISHED"}

        scripting_workspace = ensure_scripting_workspace(context)
        if scripting_workspace is not None:
            result = activate_text_editor_for_text(context, text_block, workspace=scripting_workspace)
            if result in {"scripting_workspace", "workspace_window"}:
                self.report({"INFO"}, "已创建 Scripting 工作区并打开当前模块")
                return {"FINISHED"}

        self.report({"WARNING"}, "已同步脚本到 Blender 文本数据块；Scripting 工作区没有可用文本编辑器，未改动当前布局")
        return {"FINISHED"}


class BWFLOW_OT_module_open_script_path(Operator):
    bl_idname = "bworkflow.module_open_script_path"
    bl_label = "打开当前路径"
    bl_description = "用 Windows 文件资源管理器打开当前脚本路径或所在文件夹"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        if workflow is None or not workflow.modules:
            return False
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        return bool((module.script_path or "").strip())

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        try:
            opened = open_path_in_file_explorer(module.script_path)
        except Exception as exc:
            self.report({"ERROR"}, f"打开路径失败: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已打开: {opened}")
        return {"FINISHED"}


class BWFLOW_OT_module_open_script_directory(Operator):
    bl_idname = "bworkflow.module_open_script_directory"
    bl_label = "打开脚本目录"
    bl_description = "用 Windows 文件资源管理器打开当前模块 .py 文件所在目录"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        try:
            opened = open_module_script_directory(workflow, module)
        except Exception as exc:
            self.report({"ERROR"}, f"打开脚本目录失败: {exc}")
            return {"CANCELLED"}
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, f"已打开脚本目录: {opened}")
        return {"FINISHED"}


class BWFLOW_OT_module_export_to_default_scripts(Operator):
    bl_idname = "bworkflow.module_export_to_default_scripts"
    bl_label = "导出到公共脚本目录"
    bl_description = "把当前模块脚本写入插件公共脚本目录，便于别的工程直接复用，不用走预设导入导出"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        sync_module_source_from_text_block(module)
        original_path = module.script_path
        try:
            module.script_path = unique_default_module_script_path(workflow, module)
            filepath = write_module_source_file(workflow, module)
        except Exception as exc:
            module.script_path = original_path
            self.report({"ERROR"}, f"导出公共脚本失败: {exc}")
            return {"CANCELLED"}
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, f"已导出到公共脚本目录: {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_module_import_text_file(Operator, ImportHelper):
    bl_idname = "bworkflow.module_import_text_file"
    bl_label = "导入模块文本文件"
    bl_description = "通过 Blender 原生文件浏览器为当前模块导入 csv/txt 文本内容"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv;*.txt", options={"HIDDEN"})
    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    space_type: StringProperty(default="")
    target_text_key: StringProperty(default="")
    target_set: StringProperty(default="")
    mix_profile: StringProperty(default="")
    status_prefix: StringProperty(default="已导入")
    module_action: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow, module = resolve_workflow_module(
            context.scene,
            self.workflow_name,
            self.module_name,
            space_type=self.space_type or current_space_type(context=context),
        )
        if workflow is None or module is None:
            workflow = get_active_workflow(get_state(context=context))
            if workflow is None or not workflow.modules:
                self.report({"ERROR"}, "找不到发起导入的工作流模块")
                return {"CANCELLED"}
            module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        filepath = bpy.path.abspath(self.filepath)
        if not filepath or not os.path.isfile(filepath):
            self.report({"ERROR"}, "导入文件不存在")
            return {"CANCELLED"}
        try:
            content = read_cached_text_file(
                filepath,
                encodings=("utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16", "utf-16-le", "utf-16-be"),
                errors="replace",
            )
        except Exception as exc:
            self.report({"ERROR"}, f"读取导入文件失败: {exc}")
            return {"CANCELLED"}
        if self.target_text_key:
            save_module_runtime_store(context.scene, workflow, module, ensure_module_runtime_store(context.scene, workflow, module, allow_writes=True))
            namespace = load_module_namespace(
                context,
                context.scene,
                workflow,
                module,
                "__go_workflow_import_text__",
                allow_writes=True,
                persist_state=False,
            )
            panel_api = namespace.get("panel_api")
            if panel_api is not None:
                panel_api.set_text(self.target_text_key, filepath)
                if self.target_set:
                    panel_api.set_enum("target_set", self.target_set)
                if self.mix_profile:
                    panel_api.set_enum("mix_profile", self.mix_profile)
            if self.module_action:
                action_fn = namespace.get("on_panel_action")
                if callable(action_fn):
                    try:
                        result = action_fn(
                            self.module_action,
                            context,
                            context.scene,
                            workflow,
                            module,
                            panel_api,
                            namespace.get("module_state"),
                        )
                        if namespace.get("module_state") is not None and hasattr(namespace["module_state"], "to_dict"):
                            merge_module_runtime_store(context.scene, workflow, module, namespace["module_state"].to_dict())
                        if isinstance(result, set) and "CANCELLED" in result:
                            return result
                    except BaseException as exc:
                        traceback.print_exc()
                        self.report({"ERROR"}, f"导入处理失败: {exc}")
                        return {"CANCELLED"}
        self.report({"INFO"}, f"{self.status_prefix}: {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_module_export_text_file(Operator, ExportHelper):
    bl_idname = "bworkflow.module_export_text_file"
    bl_label = "导出模块文本文件"
    bl_description = "通过 Blender 原生文件浏览器为当前模块选择导出位置，并执行自定义导出动作"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext: StringProperty(default=".txt")
    filter_glob: StringProperty(default="*.csv;*.txt", options={"HIDDEN"})
    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    space_type: StringProperty(default="")
    target_text_key: StringProperty(default="recipe_file_path")
    status_prefix: StringProperty(default="已选择导出位置")
    module_action: StringProperty(default="")
    default_filename: StringProperty(default="")
    text_payload: StringProperty(default="", options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def invoke(self, context, event):
        filename = str(self.default_filename or "").strip()
        if filename:
            try:
                self.filepath = bpy.path.abspath("//" + filename)
            except Exception:
                self.filepath = filename
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        workflow, module = resolve_workflow_module(
            context.scene,
            self.workflow_name,
            self.module_name,
            space_type=self.space_type or current_space_type(context=context),
        )
        if workflow is None or module is None:
            workflow = get_active_workflow(get_state(context=context))
            if workflow is None or not workflow.modules:
                self.report({"ERROR"}, "找不到发起导出的工作流模块")
                return {"CANCELLED"}
            module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        filepath = bpy.path.abspath(self.filepath)
        if not filepath:
            self.report({"ERROR"}, "导出路径为空")
            return {"CANCELLED"}
        folder = os.path.dirname(filepath)
        if folder:
            os.makedirs(folder, exist_ok=True)
        if self.text_payload:
            try:
                with open(filepath, "w", encoding="utf-8", newline="") as handle:
                    handle.write(self.text_payload)
            except Exception as exc:
                self.report({"ERROR"}, f"导出文件失败: {exc}")
                return {"CANCELLED"}
            if not self.module_action:
                self.report({"INFO"}, f"{self.status_prefix}: {filepath}")
                return {"FINISHED"}
        save_module_runtime_store(context.scene, workflow, module, ensure_module_runtime_store(context.scene, workflow, module, allow_writes=True))
        namespace = load_module_namespace(
            context,
            context.scene,
            workflow,
            module,
            "__go_workflow_export_text__",
            allow_writes=True,
            persist_state=False,
        )
        panel_api = namespace.get("panel_api")
        if panel_api is not None and self.target_text_key:
            panel_api.set_text(self.target_text_key, filepath)
        if self.module_action:
            action_fn = namespace.get("on_panel_action")
            if callable(action_fn):
                try:
                    result = action_fn(
                        self.module_action,
                        context,
                        context.scene,
                        workflow,
                        module,
                        panel_api,
                        namespace.get("module_state"),
                    )
                    if namespace.get("module_state") is not None and hasattr(namespace["module_state"], "to_dict"):
                        merge_module_runtime_store(context.scene, workflow, module, namespace["module_state"].to_dict())
                    if isinstance(result, set) and "CANCELLED" in result:
                        return result
                except BaseException as exc:
                    traceback.print_exc()
                    self.report({"ERROR"}, f"导出处理失败: {exc}")
                    return {"CANCELLED"}
        self.report({"INFO"}, f"{self.status_prefix}: {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_module_pick_file_path(Operator, ImportHelper):
    bl_idname = "bworkflow.module_pick_file_path"
    bl_label = "选择文件路径"
    bl_description = "通过 Blender 原生文件浏览器为模块字段写入文件路径"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.*", options={"HIDDEN"})
    workflow_name: StringProperty(default="")
    module_name: StringProperty(default="")
    space_type: StringProperty(default="")
    target_text_key: StringProperty(default="")
    status_prefix: StringProperty(default="已选择文件")

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow, module = resolve_workflow_module(
            context.scene,
            self.workflow_name,
            self.module_name,
            space_type=self.space_type or current_space_type(context=context),
        )
        if workflow is None or module is None:
            self.report({"ERROR"}, "找不到发起选择的工作流模块")
            return {"CANCELLED"}
        filepath = bpy.path.abspath(self.filepath)
        if not filepath:
            self.report({"ERROR"}, "文件路径为空")
            return {"CANCELLED"}
        save_module_runtime_store(context.scene, workflow, module, ensure_module_runtime_store(context.scene, workflow, module, allow_writes=True))
        namespace = load_module_namespace(
            context,
            context.scene,
            workflow,
            module,
            "__go_workflow_pick_file_path__",
            allow_writes=True,
            persist_state=False,
        )
        panel_api = namespace.get("panel_api")
        if panel_api is not None and self.target_text_key:
            panel_api.set_text(self.target_text_key, filepath)
        if namespace.get("module_state") is not None and hasattr(namespace["module_state"], "to_dict"):
            merge_module_runtime_store(context.scene, workflow, module, namespace["module_state"].to_dict())
        self.report({"INFO"}, f"{self.status_prefix}: {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_module_edit_description(Operator):
    bl_idname = "bworkflow.module_edit_description"
    bl_label = "编辑说明"
    bl_description = "在当前面板弹窗中编辑当前模块说明"

    description_text: StringProperty(default="", options={"TEXTEDIT_UPDATE"})

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def invoke(self, context, event):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        self.description_text = module.description or ""
        return context.window_manager.invoke_props_dialog(self, width=720)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.scale_y = 3.0
        col.prop(self, "description_text", text="")

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        module.description = self.description_text
        module.ai_doc = build_module_ai_doc(workflow, module)
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_module_paste_script_source(Operator):
    bl_idname = "bworkflow.module_paste_script_source"
    bl_label = "从剪贴板载入代码"
    bl_description = "把系统剪贴板里的 Python 代码直接保存到当前模块编辑区"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        if workflow is None or not workflow.modules:
            return False
        return bool((context.window_manager.clipboard or "").strip())

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        clipboard_text = context.window_manager.clipboard or ""
        if not clipboard_text.strip():
            self.report({"WARNING"}, "剪贴板里没有可用代码")
            return {"CANCELLED"}
        apply_module_script_source_update(context, workflow, module, clipboard_text)
        self.report({"INFO"}, "已从剪贴板载入代码并刷新自定义面板")
        return {"FINISHED"}


class BWFLOW_OT_module_copy_ai_doc(Operator):
    bl_idname = "bworkflow.module_copy_ai_doc"
    bl_label = "复制智能辅助说明"
    bl_description = "把当前模块的智能辅助说明复制到剪贴板"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        module.ai_doc = build_module_ai_doc(workflow, module)
        context.window_manager.clipboard = module.ai_doc
        save_global_workflow_state(context.scene)
        self.report({"INFO"}, "智能辅助说明已复制到剪贴板")
        return {"FINISHED"}


class BWFLOW_OT_module_copy_script_source(Operator):
    bl_idname = "bworkflow.module_copy_script_source"
    bl_label = "复制当前代码"
    bl_description = "把当前模块编辑区里的代码复制到系统剪贴板"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        if workflow is None or not workflow.modules:
            return False
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        return bool(module.script_source.strip())

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        context.window_manager.clipboard = module.script_source
        self.report({"INFO"}, "当前模块代码已复制到剪贴板")
        return {"FINISHED"}


class BWFLOW_OT_module_load_script_file(Operator):
    bl_idname = "bworkflow.module_load_script_file"
    bl_label = "从文件读取脚本"
    bl_description = "把当前脚本文件内容读取回插件内置编辑区"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        if workflow is None or not workflow.modules:
            return False
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        filepath = module_script_abspath(module)
        return bool(filepath) and os.path.isfile(filepath)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        filepath = module_script_abspath(module)
        try:
            source = read_cached_text_file(filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"读取脚本失败: {exc}")
            return {"CANCELLED"}
        apply_module_script_source_update(context, workflow, module, source)
        self.report({"INFO"}, "脚本文件内容已加载并刷新自定义面板")
        return {"FINISHED"}


class BWFLOW_OT_module_write_template(Operator):
    bl_idname = "bworkflow.module_write_template"
    bl_label = "写入脚本文件"
    bl_description = "把当前代码内容写入当前模块绑定的 .py 文件"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        sync_module_source_from_text_block(module)
        try:
            filepath = write_module_source_file(workflow, module)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"脚本文件已写入: {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_module_run(Operator):
    bl_idname = "bworkflow.module_run"
    bl_label = "运行模块"
    bl_description = "运行当前工作流模块绑定的 Python 脚本"
    bl_options = {"REGISTER", "UNDO"}

    module_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.modules)

    def execute(self, context):
        workflow = get_active_workflow(get_state(context=context))
        index = self.module_index
        if index < 0:
            index = clamp_index(workflow.active_module_index, len(workflow.modules))
        else:
            index = clamp_index(index, len(workflow.modules))

        module = workflow.modules[index]
        if not module.enabled:
            self.report({"WARNING"}, "该模块已禁用")
            return {"CANCELLED"}

        sync_module_source_from_text_block(module)
        source = (module.script_source or "").strip()
        filepath = module_script_abspath(module)
        if not source:
            if not filepath:
                self.report({"ERROR"}, "当前模块没有代码内容，也没有脚本路径")
                return {"CANCELLED"}
            if not os.path.isfile(filepath):
                self.report({"ERROR"}, f"脚本不存在: {filepath}")
                return {"CANCELLED"}
            if not filepath.lower().endswith(".py"):
                self.report({"ERROR"}, "当前只支持运行 .py 脚本")
                return {"CANCELLED"}
            try:
                source = read_cached_text_file(filepath)
            except Exception as exc:
                self.report({"ERROR"}, f"脚本读取失败: {exc}")
                return {"CANCELLED"}

        try:
            namespace = execute_module_source(source, context, context.scene, workflow, module, filepath or "__go_workflow_run__")
            entry = namespace.get("run")
            if callable(entry):
                result = entry(context, context.scene, workflow, module)
                if "module_state" in namespace:
                    merge_module_runtime_store(context.scene, workflow, module, namespace["module_state"].to_dict())
                if isinstance(result, set):
                    self.report({"INFO"}, f"模块执行完成: {module.name}")
                    return result
            if "module_state" in namespace:
                merge_module_runtime_store(context.scene, workflow, module, namespace["module_state"].to_dict())
            self.report({"INFO"}, f"脚本已执行: {module.name}")
            return {"FINISHED"}
        except BaseException as exc:
            traceback.print_exc()
            self.report({"ERROR"}, f"模块运行失败: {exc}")
            return {"CANCELLED"}


class BWFLOW_OT_script_library_save_current_module(Operator):
    bl_idname = "bworkflow.script_library_save_current_module"
    bl_label = "保存到脚本库"
    bl_description = "把当前模块的脚本内容保存到脚本库里，便于在其他工作流复用"

    overwrite_existing: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and bool(workflow.modules)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        if not sync_module_source_from_text_block(module):
            sync_module_source_from_file(module)
        module.name = normalize_workflow_name(module.name, "脚本模板")
        module.ai_doc = build_module_ai_doc(workflow, module)
        index = -1
        if self.overwrite_existing and state.script_library:
            index = clamp_index(getattr(state, "script_library_index", 0), len(state.script_library))
            item = state.script_library[index]
        else:
            item = state.script_library.add()
            index = len(state.script_library) - 1
        item.name = unique_script_library_name(state, module.name or "脚本模板", exclude_index=index)
        copy_module_to_script_library_item(item, module)
        state.script_library_index = index
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        action = "已覆盖脚本库条目" if self.overwrite_existing else "已新增脚本库条目"
        self.report({"INFO"}, f"{action}: {item.name}")
        return {"FINISHED"}


class BWFLOW_OT_script_library_apply_to_module(Operator):
    bl_idname = "bworkflow.script_library_apply_to_module"
    bl_label = "载入到当前模块"
    bl_description = "把选中的脚本库条目载入当前模块"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and bool(workflow.modules) and bool(state.script_library)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
        index = clamp_index(state.script_library_index, len(state.script_library))
        item = state.script_library[index]
        apply_script_library_item_to_module(module, item)
        module.script_path = ensure_module_script_path_matches_name(workflow, module, force=True)
        ensure_module_text_block(workflow, module)
        module.ai_doc = module.ai_doc or build_module_ai_doc(workflow, module)
        initialize_module_runtime_fields(context.scene, workflow, module, context=context)
        rebuild_runtime_panels(scene=context.scene, rebuild_cache=False)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        self.report({"INFO"}, f"已添加脚本库条目: {item.name}")
        return {"FINISHED"}


class BWFLOW_OT_script_library_toggle_workflow(Operator):
    bl_idname = "bworkflow.script_library_toggle_workflow"
    bl_label = "切换脚本库工作流启用"
    bl_description = "在指定工作流中启用或关闭当前脚本库条目"

    workflow_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(state.script_library) and bool(state.workflows)

    def execute(self, context):
        state = get_state(context=context)
        if state is None or not state.script_library or not state.workflows:
            return {"CANCELLED"}

        script_index = clamp_index(state.script_library_index, len(state.script_library))
        workflow_index = clamp_index(self.workflow_index, len(state.workflows))
        item = state.script_library[script_index]
        workflow = state.workflows[workflow_index]

        module, module_index = find_workflow_module_for_script_item(workflow, item)
        if module is None:
            module = add_script_item_to_workflow_module(workflow, item)
            if module is None:
                return {"CANCELLED"}
            module.enabled = True
            message = f"已在 {workflow.name} 启用脚本: {item.name}"
        else:
            module.enabled = not bool(module.enabled)
            workflow.active_module_index = clamp_index(module_index, len(workflow.modules))
            message = f"{workflow.name}: {'已启用' if module.enabled else '已关闭'} {item.name}"

        ensure_module_text_block(workflow, module)
        ensure_module_script_path_matches_name(workflow, module)
        initialize_module_runtime_fields(context.scene, workflow, module, context=context)
        rebuild_runtime_panels(scene=context.scene, rebuild_cache=False)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.25,))
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        self.report({"INFO"}, message)
        return {"FINISHED"}


class BWFLOW_OT_script_library_remove(Operator):
    bl_idname = "bworkflow.script_library_remove"
    bl_label = "删除脚本库条目"
    bl_description = "删除当前选中的脚本库条目"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(state.script_library)

    def execute(self, context):
        state = get_state(context=context)
        index = clamp_index(state.script_library_index, len(state.script_library))
        removed_name = state.script_library[index].name if state.script_library else ""
        state.script_library.remove(index)
        state.script_library_index = clamp_index(index, len(state.script_library))
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        self.report({"INFO"}, f"已删除脚本库条目: {removed_name or '未命名'}")
        return {"FINISHED"}


class BWFLOW_OT_script_library_refresh(Operator):
    bl_idname = "bworkflow.script_library_refresh"
    bl_label = "刷新脚本库"
    bl_description = "同步脚本库条目的文本块和 .py 文件内容，并刷新当前列表"

    @classmethod
    def poll(cls, context):
        return get_state(context=context) is not None

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}

        refreshed = 0
        failed = 0
        for item in state.script_library:
            try:
                updated = sync_script_library_item_source(item)
            except Exception:
                updated = False
                failed += 1

            if updated:
                refreshed += 1

        state.script_library_index = clamp_index(getattr(state, "script_library_index", 0), len(state.script_library))
        save_global_workflow_state(context.scene)
        tag_redraw_all()
        if failed:
            self.report({"WARNING"}, f"脚本库已刷新 {refreshed} 项，{failed} 项读取失败")
        else:
            self.report({"INFO"}, f"脚本库已刷新 {refreshed} 项")
        return {"FINISHED"}


class BWFLOW_OT_script_library_open_storage_folder(Operator):
    bl_idname = "bworkflow.script_library_open_storage_folder"
    bl_label = "打开脚本文件夹"
    bl_description = "用 Windows 文件资源管理器打开当前脚本库条目的脚本存储文件夹"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(state.script_library)

    def execute(self, context):
        state = get_state(context=context)
        if state is None or not state.script_library:
            self.report({"ERROR"}, "当前没有脚本库条目")
            return {"CANCELLED"}

        item = state.script_library[clamp_index(state.script_library_index, len(state.script_library))]
        raw_path = (getattr(item, "script_path", "") or "").strip()
        try:
            if raw_path:
                target_path = bpy.path.abspath(raw_path)
                if os.path.isfile(target_path):
                    opened = open_path_in_file_explorer(target_path)
                else:
                    folder = target_path if os.path.isdir(target_path) else os.path.dirname(target_path)
                    if folder:
                        os.makedirs(folder, exist_ok=True)
                        opened = open_path_in_file_explorer(folder)
                    else:
                        opened = open_path_in_file_explorer(script_library_storage_dir())
            else:
                os.makedirs(script_library_storage_dir(), exist_ok=True)
                opened = open_path_in_file_explorer(script_library_storage_dir())
        except Exception as exc:
            self.report({"ERROR"}, f"打开脚本文件夹失败: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"已打开脚本文件夹: {opened}")
        return {"FINISHED"}


class BWFLOW_OT_panel_toggle_for_workflow(Operator):
    bl_idname = "bworkflow.panel_toggle_for_workflow"
    bl_label = "切换当前面板组"
    bl_description = "把当前选中面板所属的组件组加入或移出当前工作流"

    panel_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and bool(state.panel_registry)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if workflow.is_default:
            self.report({"INFO"}, "默认工作流始终显示全部第三方 N 面板，无需手动勾选。")
            clear_panel_library_click_state(state)
            return {"CANCELLED"}

        index = self.panel_index if self.panel_index >= 0 else state.panel_registry_index
        index = clamp_index(index, len(state.panel_registry))
        state.panel_registry_index = index
        record = state.panel_registry[index]
        panel_id = record.panel_id
        if panel_id == "BWFLOW_PT_workflow":
            self.report({"INFO"}, "Go工作流主面板固定保留，不参与手动勾选。")
            clear_panel_library_click_state(state)
            return {"CANCELLED"}

        workflow_panel_ids = workflow_toggleable_panel_ids(state, panel_drawer_workflow_ids(state, panel_id))
        selected_ids = {item.panel_id for item in workflow.panels}
        has_any = any(candidate_id in selected_ids for candidate_id in workflow_panel_ids)

        if has_any:
            kept_ids = [item.panel_id for item in workflow.panels if item.panel_id not in workflow_panel_ids]
            replace_workflow_panels(workflow, kept_ids)
            queue_panel_visibility_pending(state, scene=context.scene, context=context)
            clear_panel_library_click_state(state)
            self.report({"INFO"}, f"已移出当前抽屉面板，共 {len(workflow_panel_ids)} 个。")
            return {"FINISHED"}

        added = append_panel_ids_to_workflow(workflow, workflow_panel_ids)
        queue_panel_visibility_pending(state, scene=context.scene, context=context)
        clear_panel_library_click_state(state)
        self.report({"INFO"}, f"已加入当前抽屉面板，共 {added} 个。")
        return {"FINISHED"}


def toggle_panel_group_for_workflow(context, state, workflow, group_key="", panel_index=-1):
    if state is None or workflow is None or workflow.is_default or not state.panel_registry:
        return {"CANCELLED"}, ""
    groups = build_panel_library_groups(state, workflow)
    target_group = next((group for group in groups if group.get("key") == group_key), None)

    if target_group is None and panel_index >= 0:
        index = clamp_index(panel_index, len(state.panel_registry))
        state.panel_registry_index = index
        record = state.panel_registry[index]
        target_key = panel_library_group_key_for_panel(state, record.panel_id)
        target_group = next((group for group in groups if group.get("key") == target_key), None)

    if target_group is None:
        return {"CANCELLED"}, ""

    drawer_ids = workflow_toggleable_panel_ids(
        state,
        target_group.get("drawer_ids", ()) or (),
    )
    if not drawer_ids:
        return {"CANCELLED"}, ""

    selected_ids = {item.panel_id for item in workflow.panels}
    if all(panel_id in selected_ids for panel_id in drawer_ids):
        kept_ids = [item.panel_id for item in workflow.panels if item.panel_id not in set(drawer_ids)]
        replace_workflow_panels(workflow, kept_ids)
        message = f"已移出面板大组: {target_group.get('title', '')}"
    else:
        append_panel_ids_to_workflow(workflow, drawer_ids)
        message = f"已加入面板大组: {target_group.get('title', '')}"

    set_active_workflow_panel_by_id(workflow, drawer_ids[0])
    scene = getattr(context, "scene", None)
    queue_panel_visibility_pending(state, scene=scene, context=context)
    clear_panel_library_click_state(state)
    return {"FINISHED"}, message


class BWFLOW_OT_panel_toggle_group_for_workflow(Operator):
    bl_idname = "bworkflow.panel_toggle_group_for_workflow"
    bl_label = "切换当前面板大组"
    bl_description = "把当前面板大组下的抽屉面板整体加入或移出当前工作流"

    group_key: StringProperty(default="")
    panel_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default and bool(state.panel_registry)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        result, message = toggle_panel_group_for_workflow(
            context,
            state,
            workflow,
            group_key=self.group_key,
            panel_index=self.panel_index,
        )
        if message:
            self.report({"INFO"}, message)
        return result


class BWFLOW_OT_panel_library_click(Operator):
    bl_idname = "bworkflow.panel_library_click"
    bl_label = "选择面板"
    bl_description = "选中面板；双击子面板只切换当前项"

    index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(state.panel_registry)

    def execute(self, context):
        return self._handle(context, event=None)

    def invoke(self, context, event):
        return self._handle(context, event=event)

    def _handle(self, context, event=None):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if state is None or not state.panel_registry:
            return {"CANCELLED"}

        index = clamp_index(self.index, len(state.panel_registry))
        click_target = f"panel:{index}"
        state.panel_registry_index = index
        state.panel_library_last_click_index = index
        record = state.panel_registry[index]
        if is_builtin_default_panel_record(record):
            clear_panel_library_click_state(state)
            return {"FINISHED"}

        if workflow is None or workflow.is_default:
            should_treat_as_double_click(state, click_target, event=event)
            return {"FINISHED"}

        if should_treat_as_double_click(state, click_target, event=event):
            return bpy.ops.bworkflow.panel_toggle_for_workflow("EXEC_DEFAULT", panel_index=index)
        return {"FINISHED"}


class BWFLOW_OT_panel_add_all_to_workflow(Operator):
    bl_idname = "bworkflow.panel_add_all_to_workflow"
    bl_label = "按默认 N 面板加入"
    bl_description = "按当前默认 N 面板顺序把已发现的第三方抽屉面板加入当前工作流"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        space_type = getattr(state, "space_type", "VIEW_3D")
        drawer_ids = []
        for record in state.panel_registry:
            if not record.discovered or record.panel_id == "BWFLOW_PT_workflow":
                continue
            panel_ids = panel_drawer_workflow_ids(state, record.panel_id)
            if panel_ids:
                drawer_ids.append(panel_ids[0])
        drawer_ids = sorted(
            unique_panel_ids(drawer_ids),
            key=lambda panel_id: (panel_drawer_default_order_index(state, panel_id, space_type=space_type), panel_id),
        )
        added = append_panel_ids_to_workflow(
            workflow,
            drawer_ids,
        )
        queue_panel_visibility_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, f"已按默认 N 面板顺序加入 {added} 个面板组")
        return {"FINISHED"}


class BWFLOW_OT_panel_add_current_plugin_to_workflow(Operator):
    bl_idname = "bworkflow.panel_add_current_plugin_to_workflow"
    bl_label = "添加当前面板组"
    bl_description = "把当前选中面板所属的组件组加入当前工作流"

    panel_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default and bool(state.panel_registry)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        index = self.panel_index if self.panel_index >= 0 else state.panel_registry_index
        index = clamp_index(index, len(state.panel_registry))
        state.panel_registry_index = index
        record = state.panel_registry[index]
        panel_ids = panel_drawer_workflow_ids(state, record.panel_id)
        added = append_panel_ids_to_workflow(workflow, panel_ids)
        queue_panel_visibility_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, f"已添加当前抽屉面板，共 {added} 个。")
        return {"FINISHED"}


class BWFLOW_OT_panel_toggle_single_for_workflow(Operator):
    bl_idname = "bworkflow.panel_toggle_single_for_workflow"
    bl_label = "切换单个面板"
    bl_description = "只把当前选中面板加入或移出当前工作流"

    panel_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default and bool(state.panel_registry)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        index = self.panel_index if self.panel_index >= 0 else state.panel_registry_index
        index = clamp_index(index, len(state.panel_registry))
        state.panel_registry_index = index
        record = state.panel_registry[index]
        panel_id = record.panel_id

        if panel_id == "BWFLOW_PT_workflow":
            self.report({"INFO"}, "Go工作流主面板固定保留，不参与手动勾选。")
            clear_panel_library_click_state(state)
            return {"CANCELLED"}

        selected_ids = {item.panel_id for item in workflow.panels}
        if panel_id in selected_ids:
            kept_ids = [item.panel_id for item in workflow.panels if item.panel_id != panel_id]
            replace_workflow_panels(workflow, kept_ids)
            queue_panel_visibility_pending(state, scene=context.scene, context=context)
            clear_panel_library_click_state(state)
            self.report({"INFO"}, "已移出当前面板。")
            return {"FINISHED"}

        added = append_panel_ids_to_workflow(workflow, [panel_id])
        queue_panel_visibility_pending(state, scene=context.scene, context=context)
        clear_panel_library_click_state(state)
        self.report({"INFO"}, f"已加入当前面板，共 {added} 个。")
        return {"FINISHED"}


class BWFLOW_OT_group_expand_toggle(Operator):
    bl_idname = "bworkflow.group_expand_toggle"
    bl_label = "展开或收起分组"
    bl_description = "展开或收起当前面板组"

    group_key: StringProperty(default="")
    target: StringProperty(default="LIBRARY")

    def execute(self, context):
        state = get_state(context=context)
        toggle_group_expanded(state, self.group_key, selected=self.target == "SELECTED")
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_panel_match_imported_by_name(Operator):
    bl_idname = "bworkflow.panel_match_imported_by_name"
    bl_label = "重新查找缺失插件面板"
    bl_description = "插件启用后，按插件名称、面板标题和分类重新对齐导入时缺失的面板"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow_can_reveal_or_match_missing_panels(state, workflow)

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        workflow = get_active_workflow(state)
        if not workflow_can_reveal_or_match_missing_panels(state, workflow):
            return {"CANCELLED"}
        restored_warning = False
        if bool(getattr(workflow, "missing_warning_dismissed", False)) and workflow_missing_panel_ids(state, workflow):
            workflow.missing_warning_dismissed = False
            state.settings.show_missing_summary = True
            restored_warning = True
        space_type = getattr(state, "space_type", current_space_type(context=context))
        rebuild_panel_cache(scene=context.scene, space_type=space_type)
        validate_panel_registry_against_runtime(state, space_type=space_type, prune_missing_unreferenced=False)

        total_changed = 0
        total_missing = 0
        if workflow_has_imported_missing_panel_matches(state, workflow):
            changed, missing = rematch_workflow_panels_by_name(state, workflow)
            total_changed += changed
            total_missing += missing

        if total_changed or restored_warning:
            normalize_state_data(state)
            mark_panel_visibility_pending(state, scene=context.scene, context=context)
            save_global_workflow_state(context.scene)
        else:
            tag_redraw_context_area(context)

        unresolved = max(0, total_missing - total_changed)
        if total_changed:
            self.report({"INFO"}, f"已按名称匹配 {total_changed} 个导入面板；未解决 {unresolved} 个")
        elif restored_warning:
            self.report({"INFO"}, "已恢复当前工作流缺失提示")
        elif total_missing:
            self.report({"WARNING"}, f"没有匹配到缺失的导入面板；未解决 {total_missing} 个")
        else:
            self.report({"INFO"}, "当前没有需要匹配的缺失导入面板")
        return {"FINISHED"}


class BWFLOW_OT_panel_group_page(Operator):
    bl_idname = "bworkflow.panel_group_page"
    bl_label = "切换面板组页"
    bl_description = "切换面板组列表当前页"

    target: StringProperty(default="LIBRARY")
    direction: StringProperty(default="NEXT")

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        prop_name = "selected_panel_group_page" if self.target == "SELECTED" else "panel_group_page"
        current = int(getattr(state, prop_name, 0) or 0)
        if self.direction == "PREV":
            current = max(0, current - 1)
        else:
            current = current + 1
        setattr(state, prop_name, current)
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_clear_panel_group_filter(Operator):
    bl_idname = "bworkflow.clear_panel_group_filter"
    bl_label = "清除面板组搜索"
    bl_description = "清空当前面板组搜索文本"

    target: StringProperty(default="LIBRARY")

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        if self.target == "SELECTED":
            state.selected_panel_group_filter_text = ""
            state.selected_panel_group_page = 0
        else:
            state.panel_group_filter_text = ""
            state.panel_group_page = 0
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_select_workflow_panel(Operator):
    bl_idname = "bworkflow.select_workflow_panel"
    bl_label = "选择工作流面板"
    bl_description = "单击选中，双击切换当前工作流中的这个面板"

    panel_id: StringProperty(default="")
    tooltip_text: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        return getattr(properties, "tooltip_text", "") or cls.bl_description

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and bool(workflow.panels)

    def execute(self, context):
        return self._handle(context, event=None)

    def invoke(self, context, event):
        return self._handle(context, event=event)

    def _handle(self, context, event=None):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if state is None or workflow is None:
            return {"CANCELLED"}
        click_target = f"selected:{self.panel_id}"
        group_key = workflow_group_key_for_panel(state, self.panel_id)

        for index, item in enumerate(workflow.panels):
            if item.panel_id == self.panel_id:
                workflow.active_panel_index = index
                break

        if should_treat_as_double_click(state, click_target, event=event):
            drawer_ids = workflow_family_drawer_ids(state, workflow, group_key)
            registry_index = workflow_panel_registry_index(state, workflow, drawer_ids[0] if drawer_ids else self.panel_id)
            if registry_index >= 0 and group_key:
                result, message = toggle_panel_group_for_workflow(
                    context,
                    state,
                    workflow,
                    group_key=group_key,
                    panel_index=registry_index,
                )
                if message:
                    self.report({"INFO"}, message)
                return result
        return {"FINISHED"}


class BWFLOW_OT_panel_group_click(Operator):
    bl_idname = "bworkflow.panel_group_click"
    bl_label = "选择面板大组"
    bl_description = "单击展开或收起分组，双击把当前面板组加入或移出当前工作流"

    group_key: StringProperty(default="")
    panel_index: IntProperty(default=-1)
    target: StringProperty(default="LIBRARY")
    tooltip_text: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        return getattr(properties, "tooltip_text", "") or cls.bl_description

    def execute(self, context):
        return self._handle(context, event=None)

    def invoke(self, context, event):
        return self._handle(context, event=event)

    def _handle(self, context, event=None):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if state is None or workflow is None:
            return {"CANCELLED"}
        click_target = f"group:{self.group_key}"

        if self.panel_index >= 0:
            state.panel_registry_index = clamp_index(self.panel_index, len(state.panel_registry))
            state.panel_library_last_click_index = self.panel_index

        if self.target == "LIBRARY":
            if should_treat_as_double_click(state, click_target, event=event):
                result, message = toggle_panel_group_for_workflow(
                    context,
                    state,
                    workflow,
                    group_key=self.group_key,
                    panel_index=self.panel_index,
                )
                if message:
                    self.report({"INFO"}, message)
                return result
        else:
            if self.panel_index >= 0 and self.panel_index < len(state.panel_registry):
                record = state.panel_registry[self.panel_index]
                if is_builtin_default_panel_record(record):
                    return {"FINISHED"}
            register_click_target(state, click_target)
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_panel_add_tagged_to_workflow(Operator):
    bl_idname = "bworkflow.panel_add_tagged_to_workflow"
    bl_label = "加入标签命中面板"
    bl_description = "把当前工作流按标签自动加入命中的面板加入当前工作流显示列表"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and not workflow.is_default and bool(parse_tags(workflow.tag_filter))

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        tag_filter = set(parse_tags(workflow.tag_filter))
        added = append_panel_ids_to_workflow(
            workflow,
            unique_panel_ids(
                panel_drawer_workflow_ids(state, record.panel_id)[0]
                for record in state.panel_registry
                if (
                    record.discovered
                    and record.panel_id != "BWFLOW_PT_workflow"
                    and tag_filter.intersection(parse_tags(record.tags))
                    and panel_drawer_workflow_ids(state, record.panel_id)
                )
            ),
        )
        mark_panel_visibility_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, f"已按标签加入 {added} 个面板组")
        return {"FINISHED"}


class BWFLOW_OT_panel_clear_workflow(Operator):
    bl_idname = "bworkflow.panel_clear_workflow"
    bl_label = "清空全部"
    bl_description = "清空当前工作流的全部面板勾选"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and not workflow.is_default and bool(workflow.panels)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        go_panel_entry = [item.panel_id for item in workflow.panels if item.panel_id == "BWFLOW_PT_workflow"]
        replace_workflow_panels(workflow, go_panel_entry)
        workflow.active_panel_index = 0
        mark_panel_visibility_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, "已清空全部面板勾选")
        return {"FINISHED"}


class BWFLOW_OT_panel_remove_missing_from_workflow(Operator):
    bl_idname = "bworkflow.panel_remove_missing_from_workflow"
    bl_label = "移除缺失面板"
    bl_description = "移除当前工作流列表里在当前环境缺失的面板"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default and bool(workflow.panels)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        missing_ids = set(workflow_missing_panel_ids(state, workflow))
        if not missing_ids:
            self.report({"INFO"}, "当前工作流没有缺失面板")
            return {"FINISHED"}
        kept_ids = [item.panel_id for item in workflow.panels if item.panel_id not in missing_ids]
        removed = len(workflow.panels) - len(kept_ids)
        replace_workflow_panels(workflow, kept_ids)
        mark_panel_visibility_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, f"已移除 {removed} 个缺失面板")
        return {"FINISHED"}


class BWFLOW_OT_workflow_dismiss_missing_warning(Operator):
    bl_idname = "bworkflow.workflow_dismiss_missing_warning"
    bl_label = "忽略缺失提示"
    bl_description = "仅隐藏当前工作流的缺失面板提示，不移除预设里的面板记录"

    dismiss: BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        workflow.missing_warning_dismissed = bool(self.dismiss)
        save_global_workflow_state(context.scene)
        tag_redraw_all(space_type=getattr(state, "space_type", None))
        self.report({"INFO"}, "已忽略当前工作流缺失提示" if self.dismiss else "已恢复当前工作流缺失提示")
        return {"FINISHED"}


class BWFLOW_OT_clear_missing_panel_warnings(Operator):
    bl_idname = "bworkflow.clear_missing_panel_warnings"
    bl_label = "清除缺失面板提示"
    bl_description = "从当前场景所有工作流中移除当前环境找不到的面板记录"

    @classmethod
    def poll(cls, context):
        return safe_context_scene() is not None

    def execute(self, context):
        scene = getattr(context, "scene", None) or safe_context_scene()
        if scene is None:
            return {"CANCELLED"}
        removed = 0
        changed_states = set()
        for space_type in iter_supported_space_types():
            state = get_state(scene=scene, space_type=space_type)
            if state is None:
                continue
            for workflow in getattr(state, "workflows", []):
                if workflow.is_default:
                    continue
                missing_ids = set(workflow_missing_panel_ids(state, workflow))
                if missing_ids:
                    kept_ids = [
                        item.panel_id
                        for item in workflow.panels
                        if item.panel_id not in missing_ids
                    ]
                    removed += len(workflow.panels) - len(kept_ids)
                    replace_workflow_panels(workflow, kept_ids)
                    changed_states.add(space_type)
                workflow.missing_warning_dismissed = False
                cache_key = imported_workflow_match_cache_key(state, workflow)
                matches = IMPORTED_WORKFLOW_PANEL_MATCH_CACHE.get(cache_key)
                if isinstance(matches, list):
                    IMPORTED_WORKFLOW_PANEL_MATCH_CACHE[cache_key] = [
                        payload
                        for payload in matches
                        if payload.get("panel_id", "") not in missing_ids
                    ]
                IMPORTED_WORKFLOW_MISSING_MATCH_CACHE.pop(cache_key, None)
            clear_space_prefixed_cache(WORKFLOW_MISSING_PANEL_IDS_CACHE_BY_SPACE, space_type)
            clear_space_prefixed_cache(WORKFLOW_MISSING_RECORDS_CACHE_BY_SPACE, space_type)
        for space_type in changed_states:
            state = get_state(scene=scene, space_type=space_type)
            mark_panel_visibility_pending(state, scene=scene)
        if removed or changed_states:
            save_global_workflow_state(scene)
            tag_redraw_all()
        self.report({"INFO"}, f"已移除 {removed} 条缺失面板记录")
        return {"FINISHED"}


class BWFLOW_OT_export_missing_plugins_csv(Operator, ExportHelper):
    bl_idname = "bworkflow.export_missing_plugins_csv"
    bl_label = "导出缺失插件 CSV"
    bl_description = "导出当前工作流缺失面板对应的插件名称和版本信息"

    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv", options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default

    def invoke(self, context, event):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        workflow_name = safe_filename_component(getattr(workflow, "name", "") if workflow is not None else "workflow", "workflow")
        self.filepath = os.path.join(os.path.expanduser("~"), f"{workflow_name}_missing_plugins.csv")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if state is None or workflow is None:
            return {"CANCELLED"}
        records = workflow_missing_records(state, workflow)
        rows = []
        seen = set()
        for record in records:
            if record is None:
                continue
            panel_id = getattr(record, "panel_id", "")
            source_module = getattr(record, "source_module", "")
            plugin_key = panel_plugin_key_from_module(source_module) or infer_plugin_key_from_panel_id(panel_id) or source_module
            required_version = version_tuple_to_text(getattr(record, "addon_version", ""))
            current_version = addon_version_from_module_name(source_module)
            key = (plugin_key, required_version, panel_id)
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                {
                    "workflow": getattr(workflow, "name", ""),
                    "plugin_key": plugin_key,
                    "required_version": required_version,
                    "current_version": current_version,
                    "panel_id": panel_id,
                    "panel_title": clean_panel_title(getattr(record, "title", ""), panel_id),
                    "source_module": source_module,
                    "category": getattr(record, "category", ""),
                }
            )
        try:
            folder = os.path.dirname(bpy.path.abspath(self.filepath))
            if folder:
                os.makedirs(folder, exist_ok=True)
            with open(bpy.path.abspath(self.filepath), "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "workflow",
                        "plugin_key",
                        "required_version",
                        "current_version",
                        "panel_id",
                        "panel_title",
                        "source_module",
                        "category",
                    ],
                )
                writer.writeheader()
                writer.writerows(rows)
        except Exception as exc:
            self.report({"ERROR"}, f"导出缺失插件 CSV 失败: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已导出 {len(rows)} 条缺失插件记录")
        return {"FINISHED"}


class BWFLOW_OT_panel_reset_workflow_order(Operator):
    bl_idname = "bworkflow.panel_reset_workflow_order"
    bl_label = "重置面板顺序"
    bl_description = "按当前扫描到的大组与组件顺序，重建当前工作流的显式面板组顺序"

    @classmethod
    def poll(cls, context):
        workflow = get_active_workflow(get_state(context=context))
        return workflow is not None and len(workflow.panels) > 1

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        active_panel_id = workflow.panels[active_index].panel_id if workflow.panels else ""
        groups = workflow_family_order_groups(state, workflow)
        groups.sort(key=lambda group: (group["title"].casefold(), group["key"]))
        replace_workflow_groups(workflow, groups, active_panel_id=active_panel_id)
        mark_panel_order_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, "当前工作流面板组顺序已重置")
        return {"FINISHED"}


class BWFLOW_OT_panel_jump_in_workflow(Operator):
    bl_idname = "bworkflow.panel_jump_in_workflow"
    bl_label = "快速移动工作流面板"
    bl_description = "把当前选中的面板组直接移到顶部或底部"

    target: StringProperty()
    group_key: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow is not None and len(workflow.panels) > 1

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        groups = workflow_family_order_groups(state, workflow)
        if len(groups) <= 1:
            return {"CANCELLED"}
        active_key = self.group_key or active_workflow_family_group_key(state, workflow)
        old_pos = next((index for index, group in enumerate(groups) if group["key"] == active_key), -1)
        if old_pos < 0:
            return {"CANCELLED"}
        if self.target == "TOP":
            new_pos = 0
        else:
            new_pos = len(groups) - 1
        if new_pos == old_pos:
            return {"CANCELLED"}
        group = groups.pop(old_pos)
        groups.insert(new_pos, group)
        replace_workflow_groups(workflow, groups, active_panel_id=group["ids"][0] if group["ids"] else "")
        mark_panel_order_pending(state, scene=context.scene, context=context)
        return {"FINISHED"}


class BWFLOW_OT_panel_reverse_workflow_order(Operator):
    bl_idname = "bworkflow.panel_reverse_workflow_order"
    bl_label = "反转面板顺序"
    bl_description = "反转当前工作流面板组顺序"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow is not None and len(workflow.panels) > 1

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        active_panel_id = workflow.panels[active_index].panel_id if workflow.panels else ""
        groups = list(reversed(workflow_family_order_groups(state, workflow)))
        replace_workflow_groups(workflow, groups, active_panel_id=active_panel_id)
        mark_panel_order_pending(state, scene=context.scene, context=context)
        self.report({"INFO"}, "当前工作流面板组顺序已反转")
        return {"FINISHED"}


class BWFLOW_OT_panel_move_in_workflow(Operator):
    bl_idname = "bworkflow.panel_move_in_workflow"
    bl_label = "移动工作流面板"
    bl_description = "调整当前工作流内已勾选面板组的顺序"

    direction: StringProperty()
    group_key: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow is not None and len(workflow.panels) > 1

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        groups = workflow_family_order_groups(state, workflow)
        if len(groups) <= 1:
            return {"CANCELLED"}
        active_key = self.group_key or active_workflow_family_group_key(state, workflow)
        old_pos = next((index for index, group in enumerate(groups) if group["key"] == active_key), -1)
        if old_pos < 0:
            return {"CANCELLED"}
        new_pos = clamp_index(old_pos + (-1 if self.direction == "UP" else 1), len(groups))
        if new_pos == old_pos:
            return {"CANCELLED"}
        group = groups.pop(old_pos)
        groups.insert(new_pos, group)
        replace_workflow_groups(workflow, groups, active_panel_id=group["ids"][0] if group["ids"] else "")
        mark_panel_order_pending(state, scene=context.scene, context=context)
        return {"FINISHED"}


class BWFLOW_OT_panel_move_child_in_group(Operator):
    bl_idname = "bworkflow.panel_move_child_in_group"
    bl_label = "移动组内子面板"
    bl_description = "调整当前面板大组内部抽屉面板的顺序"

    direction: StringProperty()
    group_key: StringProperty(default="")
    panel_id: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow is not None and not workflow.is_default and bool(workflow.panels)

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        groups = workflow_family_order_groups(state, workflow)
        active_group_key = self.group_key or workflow_group_key_for_panel(state, self.panel_id)
        group = next((item for item in groups if item.get("key") == active_group_key), None)
        if (group is None or len(group.get("ids", [])) <= 1) and self.panel_id:
            fallback_key = workflow_group_key_for_panel(state, self.panel_id)
            if fallback_key and fallback_key != active_group_key:
                active_group_key = fallback_key
                group = next((item for item in groups if item.get("key") == active_group_key), None)
        if group is None or len(group.get("ids", [])) <= 1:
            return {"CANCELLED"}

        ids = list(group["ids"])
        space_type = getattr(state, "space_type", "VIEW_3D")
        target_id = self.panel_id
        drawer_id = panel_drawer_root_id(target_id, space_type=space_type) or target_id
        old_pos = ids.index(target_id) if target_id in ids else -1
        if old_pos < 0:
            for group_pos, panel_id in enumerate(ids):
                if panel_drawer_root_id(panel_id, space_type=space_type) == drawer_id:
                    old_pos = group_pos
                    target_id = panel_id
                    break
        if old_pos < 0:
            return {"CANCELLED"}

        new_pos = clamp_index(old_pos + (-1 if self.direction == "UP" else 1), len(ids))
        if new_pos == old_pos:
            return {"CANCELLED"}

        moved_id = ids.pop(old_pos)
        ids.insert(new_pos, moved_id)
        group["ids"] = ids
        replace_workflow_groups(workflow, groups, active_panel_id=moved_id)
        mark_panel_order_pending(state, scene=context.scene, context=context)
        return {"FINISHED"}


class BWFLOW_OT_panel_sort_children_by_default_order(Operator):
    bl_idname = "bworkflow.panel_sort_children_by_default_order"
    bl_label = "子抽屉默认排序"
    bl_description = "按插件默认扫描顺序重排当前勾选列表内每个大组的子抽屉"

    group_key: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return workflow is not None and not workflow.is_default and len(workflow.panels) > 1

    def execute(self, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        if state is None or workflow is None or workflow.is_default:
            return {"CANCELLED"}

        space_type = getattr(state, "space_type", "VIEW_3D")
        quarantine_broken_panel_polls(space_type=space_type)
        repair_missing_panel_poll_callbacks(space_type=space_type)
        groups = workflow_family_order_groups(state, workflow)
        if not groups:
            return {"CANCELLED"}

        active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
        active_panel_id = workflow.panels[active_index].panel_id if workflow.panels else ""
        changed_count = 0

        for group in groups:
            if self.group_key and group.get("key") != self.group_key:
                continue
            ids = list(group.get("ids", []))
            if len(ids) <= 1:
                continue
            sorted_ids = [
                panel_id
                for _order_index, _old_index, panel_id in sorted(
                    (
                        (
                            panel_drawer_default_order_index(state, panel_id, space_type=space_type),
                            old_index,
                            panel_id,
                        )
                        for old_index, panel_id in enumerate(ids)
                    )
                )
            ]
            if sorted_ids != ids:
                group["ids"] = sorted_ids
                changed_count += 1

        if not changed_count:
            self.report({"INFO"}, "子抽屉已经是插件默认顺序")
            return {"FINISHED"}

        replace_workflow_groups(workflow, groups, active_panel_id=active_panel_id)
        mark_panel_order_pending(state, scene=context.scene, context=context)
        quarantine_broken_panel_polls(space_type=space_type)
        self.report({"INFO"}, f"已按插件默认顺序整理 {changed_count} 个面板组")
        return {"FINISHED"}


class BWFLOW_OT_panel_apply_workflow_order(Operator):
    bl_idname = "bworkflow.panel_apply_workflow_order"
    bl_label = "应用到 N 面板"
    bl_description = "把当前勾选列表和排序一次性应用到 Blender N 面板；连续调整时不会自动应用"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        workflow = get_active_workflow(state)
        return state is not None and workflow is not None and not workflow.is_default

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        space_type = getattr(state, "space_type", "VIEW_3D")
        PANEL_VISIBILITY_DATA_CACHE_BY_SPACE.pop(space_type, None)
        state.panel_order_pending_apply = False
        changed = rebuild_runtime_panels(scene=context.scene, space_type=space_type)
        schedule_deferred_runtime_refresh(scene=context.scene, intervals=(0.5,), space_type=space_type)
        state.panel_visibility_pending_apply = False
        state.panel_order_pending_apply = False
        save_global_workflow_state(context.scene)
        tag_redraw_all(space_type=space_type)
        self.report({"INFO"}, "已应用当前 N 面板配置" if changed else "当前 N 面板配置已是最新")
        return {"FINISHED"}


class BWFLOW_OT_debug_dump_panels(Operator):
    bl_idname = "bworkflow.debug_dump_panels"
    bl_label = "输出当前面板清单"
    bl_description = "把当前扫描到的第三方 N 面板清单输出到 Blender 系统控制台"

    def execute(self, context):
        space_type = current_space_type(context=context)
        rebuild_panel_cache(scene=context.scene, space_type=space_type)
        lines = []
        for panel_id, cls in get_panel_cache(space_type).items():
            category = panel_display_category(panel_id, cls, space_type=space_type) or "-"
            parent_id = getattr(cls, "bl_parent_id", "") or "-"
            source_module = getattr(cls, "__module__", "") or "-"
            lines.append(f"{panel_id} | category={category} | parent={parent_id} | module={source_module}")
        print("[Go工作流] 面板清单开始")
        for line in lines:
            print(line)
        print("[Go工作流] 面板清单结束")
        self.report({"INFO"}, f"已输出 {len(lines)} 个面板到系统控制台")
        return {"FINISHED"}


def native_windows_file_dialog_open(title="Select preset", default_ext="gwpreset"):
    if not hasattr(ctypes, "windll"):
        return ""
    try:
        from ctypes import wintypes

        class OPENFILENAMEW(ctypes.Structure):
            _fields_ = (
                ("lStructSize", wintypes.DWORD),
                ("hwndOwner", wintypes.HWND),
                ("hInstance", wintypes.HINSTANCE),
                ("lpstrFilter", wintypes.LPCWSTR),
                ("lpstrCustomFilter", wintypes.LPWSTR),
                ("nMaxCustFilter", wintypes.DWORD),
                ("nFilterIndex", wintypes.DWORD),
                ("lpstrFile", wintypes.LPWSTR),
                ("nMaxFile", wintypes.DWORD),
                ("lpstrFileTitle", wintypes.LPWSTR),
                ("nMaxFileTitle", wintypes.DWORD),
                ("lpstrInitialDir", wintypes.LPCWSTR),
                ("lpstrTitle", wintypes.LPCWSTR),
                ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD),
                ("nFileExtension", wintypes.WORD),
                ("lpstrDefExt", wintypes.LPCWSTR),
                ("lCustData", wintypes.LPARAM),
                ("lpfnHook", wintypes.LPVOID),
                ("lpTemplateName", wintypes.LPCWSTR),
                ("pvReserved", wintypes.LPVOID),
                ("dwReserved", wintypes.DWORD),
                ("FlagsEx", wintypes.DWORD),
            )

        buffer = ctypes.create_unicode_buffer(32768)
        filters = "Go Workflow Preset (*.gwpreset)\0*.gwpreset\0Legacy Preset (*.goworkflow;*.bworkflow;*.zip)\0*.goworkflow;*.bworkflow;*.zip\0All Files (*.*)\0*.*\0\0"
        ofn = OPENFILENAMEW()
        ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
        ofn.lpstrFilter = filters
        ofn.nFilterIndex = 1
        ofn.lpstrFile = ctypes.cast(buffer, wintypes.LPWSTR)
        ofn.nMaxFile = len(buffer)
        ofn.lpstrTitle = str(title or "Select preset")
        ofn.lpstrDefExt = str(default_ext or "gwpreset")
        ofn.Flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000400
        if ctypes.windll.comdlg32.GetOpenFileNameW(ctypes.byref(ofn)):
            return buffer.value
    except Exception:
        traceback.print_exc()
    return ""


def native_windows_file_dialog_save(default_path="", title="Save preset", default_ext="gwpreset"):
    if not hasattr(ctypes, "windll"):
        return ""
    try:
        from ctypes import wintypes

        class OPENFILENAMEW(ctypes.Structure):
            _fields_ = (
                ("lStructSize", wintypes.DWORD),
                ("hwndOwner", wintypes.HWND),
                ("hInstance", wintypes.HINSTANCE),
                ("lpstrFilter", wintypes.LPCWSTR),
                ("lpstrCustomFilter", wintypes.LPWSTR),
                ("nMaxCustFilter", wintypes.DWORD),
                ("nFilterIndex", wintypes.DWORD),
                ("lpstrFile", wintypes.LPWSTR),
                ("nMaxFile", wintypes.DWORD),
                ("lpstrFileTitle", wintypes.LPWSTR),
                ("nMaxFileTitle", wintypes.DWORD),
                ("lpstrInitialDir", wintypes.LPCWSTR),
                ("lpstrTitle", wintypes.LPCWSTR),
                ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD),
                ("nFileExtension", wintypes.WORD),
                ("lpstrDefExt", wintypes.LPCWSTR),
                ("lCustData", wintypes.LPARAM),
                ("lpfnHook", wintypes.LPVOID),
                ("lpTemplateName", wintypes.LPCWSTR),
                ("pvReserved", wintypes.LPVOID),
                ("dwReserved", wintypes.DWORD),
                ("FlagsEx", wintypes.DWORD),
            )

        initial = str(default_path or "")
        buffer = ctypes.create_unicode_buffer(32768)
        buffer.value = initial[: len(buffer) - 1]
        filters = "Go Workflow Preset (*.gwpreset)\0*.gwpreset\0All Files (*.*)\0*.*\0\0"
        ofn = OPENFILENAMEW()
        ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
        ofn.lpstrFilter = filters
        ofn.nFilterIndex = 1
        ofn.lpstrFile = ctypes.cast(buffer, wintypes.LPWSTR)
        ofn.nMaxFile = len(buffer)
        ofn.lpstrTitle = str(title or "Save preset")
        ofn.lpstrDefExt = str(default_ext or "gwpreset")
        ofn.Flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000002 | 0x00000400
        if ctypes.windll.comdlg32.GetSaveFileNameW(ctypes.byref(ofn)):
            filepath = buffer.value
            if filepath and not os.path.splitext(filepath)[1]:
                filepath += "." + str(default_ext or "gwpreset").lstrip(".")
            return filepath
    except Exception:
        traceback.print_exc()
    return ""


def import_preset_file_direct(context, filepath):
    try:
        payload = read_preset_archive(filepath, max_bytes=MAX_PRESET_FILE_BYTES, hydrate_scripts=False)
    except Exception as exc:
        print(f"[Go Workflow] Preset read failed: {exc}")
        return False
    if not isinstance(payload, dict):
        print("[Go Workflow] Invalid preset payload.")
        return False
    state = get_state(context=context)
    if state is None:
        print("[Go Workflow] No available state.")
        return False
    ensure_minimum_setup(context.scene, restore_global=False, save_state=False)
    preferred_space_type = current_space_type(context=context)
    entries = prepare_safe_preset_entries(workflow_preset_entries_from_payload(payload, preferred_space_type=preferred_space_type))
    non_default_entries = [
        entry for entry in entries if not workflow_entry_is_default(entry)
    ]
    entries = non_default_entries or direct_import_workflow_entries(
        entries,
        preferred_space_type=preferred_space_type,
    )
    imported = []
    for entry in entries:
        imported.extend(import_preset_entry_across_spaces(context, entry))
    if not imported:
        print("[Go Workflow] No workflow imported.")
        return False
    print(f"[Go Workflow] Imported {len(imported)} workflow(s) across editor spaces.")
    return True


class BWFLOW_OT_preset_export(Operator):
    bl_idname = "bworkflow.preset_export"
    bl_label = "导出预设"
    bl_description = "将勾选的工作流和脚本模块导出为 .gwpreset 压缩预设包"

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        state = get_state(context=context)
        default_path = default_preset_export_path(context, state) if state is not None else ""
        filepath = native_windows_file_dialog_save(default_path, title="Save Go Workflow preset")
        if not filepath:
            print("[Go Workflow] Preset export cancelled.")
            return {"CANCELLED"}
        if normalize_workflow_texts(state):
            save_global_workflow_state(context.scene)
            tag_redraw_all()
        workflows = selected_preset_export_workflows(state)
        if not workflows:
            workflow = get_active_workflow(state)
            workflows = [workflow] if workflow is not None else []
        refresh_script_library_sources_for_workflows(state, workflows)
        space_type = getattr(state, "space_type", "") or current_space_type(context=context)
        payload = build_selected_workflows_preset_payload(context.scene, context=context, space_type=space_type)
        if payload is None:
            print("[Go Workflow] No workflow selected for export.")
            return {"CANCELLED"}
        write_preset_archive(filepath, payload)

        workflow_count = len(workflows)
        print(f"[Go Workflow] Exported {workflow_count} workflow(s): {filepath}")
        return {"FINISHED"}


class BWFLOW_OT_preset_import(Operator):
    bl_idname = "bworkflow.preset_import"
    bl_label = "导入预设"
    bl_description = "导入 .gwpreset 压缩预设包；旧 .goworkflow/.bworkflow 仍可读取"

    def execute(self, context):
        filepath = native_windows_file_dialog_open(title="Import Go Workflow preset")
        if not filepath:
            print("[Go Workflow] Preset import cancelled.")
            return {"CANCELLED"}
        return {"FINISHED"} if import_preset_file_direct(context, filepath) else {"CANCELLED"}


class BWFLOW_OT_preset_load(Operator):
    bl_idname = "bworkflow.preset_load"
    bl_label = "载入预设"
    bl_description = "读取 .gwpreset 压缩预设包，并列出可单独导入的工作流"

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            print("[Go Workflow] No available state.")
            return {"CANCELLED"}
        filepath = native_windows_file_dialog_open(title="Load Go Workflow preset")
        if not filepath:
            print("[Go Workflow] Preset load cancelled.")
            return {"CANCELLED"}
        try:
            payload = read_preset_archive(filepath, max_bytes=MAX_PRESET_FILE_BYTES, hydrate_scripts=False)
        except Exception as exc:
            print(f"[Go Workflow] Preset read failed: {exc}")
            return {"CANCELLED"}

        preferred_space_type = current_space_type(context=context)
        entries = prepare_safe_preset_entries(workflow_preset_entries_from_payload(payload, preferred_space_type=preferred_space_type))
        set_preset_import_cache(state, filepath, entries, selected_index=0)
        count = populate_preset_workflow_list(state, entries, preferred_space_type=preferred_space_type)
        selected_count, _total_count = preset_workflow_selection_counts(state)
        if count <= 0:
            print("[Go Workflow] No workflow found in preset.")
            return {"CANCELLED"}
        print(f"[Go Workflow] Loaded {count} workflow(s); selected {selected_count}.")
        return {"FINISHED"}


def load_preset_entries_from_filepath(context, state, filepath):
    payload = read_preset_archive(filepath, max_bytes=MAX_PRESET_FILE_BYTES, hydrate_scripts=False)
    preferred_space_type = current_space_type(context=context)
    entries = prepare_safe_preset_entries(workflow_preset_entries_from_payload(payload, preferred_space_type=preferred_space_type))
    set_preset_import_cache(state, filepath, entries, selected_index=0)
    count = populate_preset_workflow_list(state, entries, preferred_space_type=preferred_space_type)
    return count, preset_workflow_selection_counts(state)[0]


class BWFLOW_OT_preset_load_from_clipboard(Operator):
    bl_idname = "bworkflow.preset_load_from_clipboard"
    bl_label = "从剪贴板加载预设"
    bl_description = "从剪贴板读取 .gwpreset 路径，绕过 Blender 文件浏览器"

    @classmethod
    def poll(cls, context):
        return get_state(context=context) is not None

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        filepath = str(getattr(context.window_manager, "clipboard", "") or "").strip().strip('"')
        if not filepath:
            print("[Go Workflow] Clipboard is empty.")
            return {"CANCELLED"}
        try:
            count, selected = load_preset_entries_from_filepath(context, state, filepath)
        except Exception as exc:
            traceback.print_exc()
            print(f"[Go Workflow] Preset clipboard load failed: {exc}")
            return {"CANCELLED"}
        if count <= 0:
            print("[Go Workflow] No workflow found in preset.")
            return {"CANCELLED"}
        print(f"[Go Workflow] Loaded {count} workflow(s); selected {selected}.")
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_preset_export_select_all(Operator):
    bl_idname = "bworkflow.preset_export_select_all"
    bl_label = "选择导出工作流"
    bl_description = "全选或清空预设导出的工作流"

    select: BoolProperty(default=True)

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        for workflow in state.workflows:
            workflow.preset_export_selected = bool(self.select)
        return {"FINISHED"}


class BWFLOW_OT_preset_select_all(Operator):
    bl_idname = "bworkflow.preset_select_all"
    bl_label = "选择预设工作流"
    bl_description = "兼容旧预设列表按钮；当前导入流程使用单选预览"

    select: BoolProperty(default=True)

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        active_index = preset_import_selected_index(state)
        if active_index >= 0:
            set_preset_import_selected_index(state, active_index if self.select else 0)
        selected_count, total_count = preset_workflow_selection_counts(state)
        state.preset_status = f"当前选中 {selected_count}/{total_count} 个工作流"
        print(f"[Go Workflow] Selected {selected_count}/{total_count}.")
        return {"FINISHED"}


class BWFLOW_OT_preset_select_current_space(Operator):
    bl_idname = "bworkflow.preset_select_current_space"
    bl_label = "只选当前编辑器"
    bl_description = "在预设预览中切到当前编辑器空间的第一个非默认工作流"

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        space_type = current_space_type(context=context)
        entries = get_preset_import_entries(state)
        for index, entry in enumerate(entries):
            workflow = entry.get("workflow", {}) if isinstance(entry, dict) else {}
            if entry.get("space_type", "VIEW_3D") == space_type and not bool(workflow.get("is_default", False)):
                set_preset_import_selected_index(state, index)
                break
        selected_count, total_count = preset_workflow_selection_counts(state)
        state.preset_status = f"当前选中 {selected_count}/{total_count} 个工作流"
        print(f"[Go Workflow] Selected {selected_count}/{total_count}.")
        return {"FINISHED"}


class BWFLOW_OT_preset_clear_loaded(Operator):
    bl_idname = "bworkflow.preset_clear_loaded"
    bl_label = "清空预设列表"
    bl_description = "清空当前已载入的预设预览列表"

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        clear_preset_import_cache(state)
        return {"FINISHED"}


class BWFLOW_OT_preset_select_cached(Operator):
    bl_idname = "bworkflow.preset_select_cached"
    bl_label = "选择预设工作流"
    bl_description = "选择一个已载入的预设工作流用于导入"

    index: IntProperty(default=0, min=0)

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(get_preset_import_entries(state))

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        selected_index = set_preset_import_selected_index(state, int(self.index))
        if selected_index < 0:
            return {"CANCELLED"}
        if not tag_redraw_context_area(context):
            tag_redraw_all()
        return {"FINISHED"}


class BWFLOW_OT_preset_import_selected(Operator):
    bl_idname = "bworkflow.preset_import_selected"
    bl_label = "导入选中工作流"
    bl_description = "将当前选中的预设工作流导入到当前编辑器空间"

    @classmethod
    def poll(cls, context):
        state = get_state(context=context)
        return state is not None and bool(get_preset_import_entries(state))

    def execute(self, context):
        state = get_state(context=context)
        if state is None:
            return {"CANCELLED"}
        selected_index = preset_import_selected_index(state)
        selected_entry = preset_import_entry_at(state, selected_index)
        selected_entries = [selected_entry] if isinstance(selected_entry, dict) else []
        if not selected_entries:
            print("[Go Workflow] No selected workflow to import.")
            return {"CANCELLED"}

        ensure_minimum_setup(context.scene, restore_global=False, save_state=False)
        imported = []
        for entry in selected_entries:
            imported.extend(import_preset_entry_across_spaces(context, entry))

        if not imported:
            print("[Go Workflow] No workflow imported.")
            return {"CANCELLED"}

        print(f"[Go Workflow] Imported {len(imported)} workflow(s) across editor spaces.")
        return {"FINISHED"}


def refresh_all_panel_registries(scene):
    summary = {
        "removed_duplicates": 0,
        "removed_stale": 0,
        "removed_empty": 0,
        "added_runtime": 0,
    }

    for space_type in iter_supported_space_types():
        rebuild_panel_cache(scene=scene, space_type=space_type)
        state = get_state(scene=scene, space_type=space_type)
        if state is None:
            continue

        state_summary = validate_panel_registry_against_runtime(
            state,
            space_type=space_type,
            prune_missing_unreferenced=True,
        )
        summary["removed_duplicates"] += state_summary["removed_duplicates"]
        summary["removed_stale"] += state_summary["removed_stale"]
        summary["removed_empty"] += state_summary["removed_empty"]
        summary["added_runtime"] += state_summary["added_runtime"]

        dedupe_workflows(state)
        ensure_one_default_workflow(state)
        ensure_go_workflow_panel_entry(state)
        purge_builtin_default_panels(state)

    return summary


def draw_workflow_switcher(layout, state):
    for start in range(0, len(state.workflows), WORKFLOW_SWITCHER_COLUMNS):
        row = layout.row(align=True)
        chunk = state.workflows[start : start + WORKFLOW_SWITCHER_COLUMNS]
        for offset, workflow in enumerate(chunk):
            index = start + offset
            icon = "RADIOBUT_ON" if index == state.active_workflow_index else "RADIOBUT_OFF"
            op = row.operator(
                "bworkflow.workflow_activate",
                text=workflow.name,
                icon=icon,
                depress=index == state.active_workflow_index,
            )
            op.index = index
        for _unused in range(len(chunk), WORKFLOW_SWITCHER_COLUMNS):
            row.label(text="")


def draw_workflow_runtime(layout, state):
    workflow = get_active_workflow(state)
    if workflow is None:
        layout.label(text="当前没有可用 Go工作流", icon="INFO")
        return

    if not workflow_runtime_initialized(state):
        box = layout.box()
        box.label(text="Go工作流尚未初始化，当前未修改第三方 N 面板", icon="INFO")
        box.operator("bworkflow.initialize_defaults", icon="ADD")
        return

    preview_lines = state.settings.runtime_preview_lines

    header = layout.row(align=True)
    header.label(text="Go工作流", icon="FILE_FOLDER")
    header.prop(
        state.settings,
        "show_settings",
        text="",
        icon="PREFERENCES",
        toggle=True,
    )

    switch_col = layout.column(align=True)
    draw_workflow_switcher(switch_col, state)

    info = layout.column(align=True)
    info.label(text=workflow.name, icon="OUTLINER_COLLECTION")
    summary = info.row(align=True)
    summary.label(text="默认模式" if workflow.is_default else "筛选模式", icon="HOME" if workflow.is_default else "BOOKMARKS")
    summary.label(text=f"模块 {len(workflow.modules)}", icon="CONSOLE")
    if workflow.description:
        draw_folded_text_block(
            info,
            state.settings,
            "show_workflow_description",
            "工作流说明",
            workflow.description,
            icon="INFO",
            expanded_limit=preview_lines,
            width=64,
        )
    if workflow.is_default:
        repair_box = layout.box()
        repair_box.label(text="默认工作流修复", icon="FILE_REFRESH")
        repair_box.label(text="如果 N 面板显示异常，可用这里一键恢复 Blender 初始 N 面板。", icon="INFO")
        repair_box.operator("bworkflow.restore_default_n_panels", text="重置 Blender 初始 N 面板", icon="FILE_REFRESH")

    if state.settings.show_missing_summary:
        missing_records = workflow_missing_records(state, workflow)
        if missing_records:
            warning = layout.box()
            warning.alert = True
            row = warning.row(align=True)
            row.label(text=f"当前 Go工作流有 {len(missing_records)} 个缺失面板", icon="ERROR")
            op = row.operator("bworkflow.workflow_dismiss_missing_warning", text="忽略提示", icon="HIDE_ON")
            op.dismiss = True
            row.operator("bworkflow.export_missing_plugins_csv", text="导出 CSV", icon="EXPORT")
            for record in missing_records[: min(len(missing_records), preview_lines)]:
                label = record.title if record and record.title else (record.panel_id if record else "未知面板")
                warning.label(text=label)
            if len(missing_records) > preview_lines:
                warning.label(text=f"其余 {len(missing_records) - preview_lines} 项请导出 CSV 查看", icon="INFO")
        elif bool(getattr(workflow, "missing_warning_dismissed", False)) and workflow_missing_panel_ids(state, workflow):
            row = layout.row(align=True)
            row.label(text="当前工作流的缺失面板提示已忽略", icon="HIDE_ON")
            op = row.operator("bworkflow.workflow_dismiss_missing_warning", text="恢复提示", icon="HIDE_OFF")
            op.dismiss = False

    modules_box = layout.box()
    modules_box.label(text="自定义脚本模块", icon="CONSOLE")
    if not workflow.modules:
        modules_box.label(text="当前 Go工作流还没有脚本模块，请到“独立设置 > 脚本模板”中添加。", icon="INFO")
        return

    for index, module in enumerate(workflow.modules):
        card = modules_box.box()
        if not module.enabled:
            card.label(text="该模块已禁用，请到脚本模板页启用。", icon="PAUSE")
            continue
        card.enabled = True
        header = card.row(align=True)
        needs_panel = module_needs_runtime_panel(module)
        if needs_panel:
            header.prop(
                module,
                "runtime_panel_expanded",
                text="",
                icon="TRIA_DOWN" if module.runtime_panel_expanded else "TRIA_RIGHT",
                toggle=True,
            )
        header.label(text=module.name or f"模块 {index + 1}", icon="CONSOLE")
        run_op = header.operator("bworkflow.module_run", text="运行")
        run_op.module_index = index

        if needs_panel and not module.runtime_panel_expanded:
            continue

        if module.description:
            draw_folded_text_block(
                card,
                module,
                "runtime_description_expanded",
                "模块说明",
                module.description,
                icon="INFO",
                expanded_limit=2,
                width=64,
            )

        if needs_panel:
            panel_box = card.box()
            draw_module_runtime_panel(panel_box, bpy.context, workflow, module)


def draw_settings_embedded(layout, state):
    settings_box = layout.column(align=True)
    header = settings_box.row(align=True)
    header.label(text="Go工作流设置", icon="PREFERENCES")
    header.prop(state.settings, "show_settings", text="", icon="X", toggle=True)

    tabs = settings_box.row(align=True)
    tabs.prop(state.settings, "ui_tab", expand=True)

    body = settings_box.column(align=True)
    tab = state.settings.ui_tab
    if tab == "WORKFLOWS":
        draw_workflow_settings(body, state)
    elif tab == "PANELS":
        draw_panel_library_editor(body, state)
    elif tab == "MODULES":
        draw_module_template_editor(body, state)
    elif tab == "SCRIPTS":
        draw_script_library_editor(body, state)
    elif tab == "PRESETS":
        draw_preset_editor(body, state)
    else:
        draw_global_settings(body, state)


def begin_settings_module(layout, title, icon):
    frame = layout.box()
    header = frame.row(align=True)
    header.label(text=title, icon=icon)
    return frame.column(align=True)


def draw_workflow_settings(layout, state):
    layout = begin_settings_module(layout, "工作流管理", "FILE_FOLDER")
    list_box = layout.box()
    list_box.label(text="Go工作流列表", icon="FILE_FOLDER")
    row = list_box.row()
    row.template_list(
        "BWFLOW_UL_workflows",
        "",
        state,
        "workflows",
        state,
        "active_workflow_index",
        rows=7,
    )
    ops = row.column(align=True)
    ops.operator("bworkflow.workflow_add", text="", icon="ADD")
    ops.operator("bworkflow.workflow_duplicate", text="", icon="DUPLICATE")
    ops.operator("bworkflow.workflow_remove", text="", icon="REMOVE")
    ops.separator()
    move_up = ops.operator("bworkflow.workflow_move", text="", icon="TRIA_UP")
    move_up.direction = "UP"
    move_down = ops.operator("bworkflow.workflow_move", text="", icon="TRIA_DOWN")
    move_down.direction = "DOWN"

    workflow = get_active_workflow(state)
    if workflow is None:
        layout.label(text="请先创建 Go工作流", icon="INFO")
        return

    detail = layout.box()
    detail.label(text="当前工作流设置", icon="SETTINGS")
    detail.prop(workflow, "name", text="名称")
    detail.prop(workflow, "description", text="说明")
    if workflow.is_default:
        detail.label(text="当前 Go工作流就是默认 Go工作流。", icon="CHECKMARK")
        return
    missing_panel_ids = workflow_missing_panel_ids(state, workflow)
    if missing_panel_ids:
        row = detail.row(align=True)
        if bool(getattr(workflow, "missing_warning_dismissed", False)):
            row.label(text=f"缺失面板提示已忽略（{len(missing_panel_ids)} 个）", icon="HIDE_ON")
            op = row.operator("bworkflow.workflow_dismiss_missing_warning", text="恢复提示", icon="HIDE_OFF")
            op.dismiss = False
        else:
            row.label(text=f"当前 Go工作流存在 {len(missing_panel_ids)} 个缺失面板。", icon="ERROR")
            op = row.operator("bworkflow.workflow_dismiss_missing_warning", text="忽略提示", icon="HIDE_ON")
            op.dismiss = True
            row.operator("bworkflow.export_missing_plugins_csv", text="导出 CSV", icon="EXPORT")


def draw_panel_library_editor(layout, state):
    layout = begin_settings_module(layout, "面板库", "MENU_PANEL")
    workflow = get_active_workflow(state)
    if workflow is None:
        layout.label(text="请先创建 Go工作流", icon="INFO")
        return

    groups = build_panel_library_groups(state, workflow)
    expanded_library_keys = parse_expanded_group_keys(getattr(state, "panel_group_expanded_keys", ""))
    expanded_selected_keys = parse_expanded_group_keys(getattr(state, "selected_group_expanded_keys", ""))

    header = layout.box()
    header.label(text=f"当前 Go工作流配置目标: {workflow.name}", icon="OUTLINER_COLLECTION")
    if workflow.is_default:
        header.label(text="默认 Go工作流不需要勾选，默认显示全部面板。", icon="HOME")

    split = layout.split(factor=0.52)
    left = split.column(align=True)
    right = split.column(align=True)

    selected_ids = {item.panel_id for item in workflow.panels}

    space_type = getattr(state, "space_type", "VIEW_3D")

    if not state.panel_registry:
        left.label(text="面板库为空，请先刷新。", icon="INFO")
        return

    record = state.panel_registry[clamp_index(state.panel_registry_index, len(state.panel_registry))]
    record_discovered = panel_drawer_discovered(state, panel_drawer_root_id(record.panel_id, space_type=space_type))
    component_ids = set(panel_drawer_workflow_ids(state, record.panel_id))
    is_checked = bool(component_ids.intersection(selected_ids)) or record.panel_id in selected_ids

    detail = left.box()
    detail.label(text="面板详情", icon="MENU_PANEL")
    detail.label(text=f"名称: {clean_panel_title(record.title, record.panel_id)}")
    status_row = detail.row(align=True)
    if is_checked:
        status_row.label(text="已加入", icon="CHECKMARK")
    elif not record_discovered:
        status_row.label(text="缺失", icon="ERROR")
    else:
        status_row.label(text=" ", icon="BLANK1")
    detail.label(text=f"所属抽屉面板: {panel_drawer_title(state, panel_drawer_root_id(record.panel_id, space_type=space_type))}")
    if not workflow.is_default:
        action_row = detail.row(align=True)
        toggle_plugin_op = action_row.operator("bworkflow.panel_toggle_for_workflow", text="抽屉面板加入/移出")
        toggle_plugin_op.panel_index = clamp_index(state.panel_registry_index, len(state.panel_registry))

    library_box = left.box()
    library_box.prop(state, "panel_group_filter_text", text="搜索")
    filtered_groups = filtered_panel_groups(
        groups,
        getattr(state, "panel_group_filter_text", ""),
        cache_key=f"{space_type}:library",
    )
    library_box.label(text=f"共有 {len(filtered_groups)} / {len(groups)} 个面板组", icon="OUTLINER_COLLECTION")
    tool_row = library_box.row(align=True)
    tool_row.operator("bworkflow.panel_match_imported_by_name", text="重新查找缺失插件面板", icon="VIEWZOOM")
    tool_row.operator("bworkflow.refresh_registry", text="刷新面板库")
    tool_row.operator("bworkflow.panel_add_all_to_workflow", text="按默认 N 面板加入")
    if getattr(state, "panel_group_filter_text", ""):
        clear_filter = tool_row.operator("bworkflow.clear_panel_group_filter", text="", icon="X")
        clear_filter.target = "LIBRARY"

    visible_groups, library_page, library_page_count = paged_panel_groups(
        state, filtered_groups, "panel_group_page", PANEL_GROUP_DRAW_LIMIT
    )
    if library_page_count > 1:
        page_row = library_box.row(align=True)
        page_row.alignment = "CENTER"
        prev_page = page_row.operator("bworkflow.panel_group_page", text="", icon="TRIA_LEFT")
        prev_page.target = "LIBRARY"
        prev_page.direction = "PREV"
        page_row.label(text=f"{library_page + 1}/{library_page_count}")
        next_page = page_row.operator("bworkflow.panel_group_page", text="", icon="TRIA_RIGHT")
        next_page.target = "LIBRARY"
        next_page.direction = "NEXT"
    if visible_groups:
        for group in visible_groups:
            expanded = group["key"] in expanded_library_keys
            group_box = library_box.box() if expanded else library_box
            header_row = group_box.row(align=True)
            header_row.operator_context = "INVOKE_DEFAULT"
            selected_count = group.get("selected_count", 0)
            if selected_count:
                status_icon = "CHECKBOX_HLT"
            else:
                status_icon = "CHECKBOX_DEHLT"
            expand_icon = "TRIA_DOWN" if expanded else "TRIA_RIGHT"
            expand_op = header_row.operator(
                "bworkflow.group_expand_toggle",
                text="",
                icon=expand_icon,
                emboss=False,
            )
            expand_op.group_key = group["key"]
            expand_op.target = "LIBRARY"
            group_icon = panel_group_icon_data(state, group)
            icon_kwargs = {
                "text": group_icon["text"],
                "emboss": False,
                "translate": False,
            }
            if group_icon["icon_value"]:
                icon_kwargs["icon_value"] = group_icon["icon_value"]
            else:
                icon_kwargs["icon"] = group_icon["icon"]
            icon_cell = header_row.row(align=True)
            icon_cell.scale_x = 0.9 if group_icon["icon_value"] or group_icon["icon"] != "NONE" else 0.68
            group_icon_op = icon_cell.operator(
                "bworkflow.panel_group_click",
                **icon_kwargs,
            )
            group_icon_op.group_key = group["key"]
            group_icon_op.panel_index = group.get("first_panel_index", -1)
            group_icon_op.target = "LIBRARY"
            group_icon_op.tooltip_text = (
                f"\u539f\u63d2\u4ef6\u540d\u79f0\uff1a{group.get('original_title', group['title'])}"
            )
            group_op = header_row.operator(
                "bworkflow.panel_group_click",
                text=group["title"],
                icon="NONE",
                emboss=False,
                translate=False,
            )
            group_op.group_key = group["key"]
            group_op.panel_index = group.get("first_panel_index", -1)
            group_op.target = "LIBRARY"
            group_op.tooltip_text = (
                f"\u539f\u63d2\u4ef6\u540d\u79f0\uff1a{group.get('original_title', group['title'])}"
            )
            header_row.label(text="", icon=status_icon)
            header_row.label(text=panel_count_label(group.get("panel_count", 0)), icon="MENU_PANEL")
            if expanded:
                for entry in panel_library_group_entries(state, workflow, group):
                    record = entry["record"]
                    row = group_box.row(align=True)
                    row.operator_context = "INVOKE_DEFAULT"
                    row.alert = not entry["discovered"]
                    title = entry.get("component_title") or entry.get("title") or clean_panel_title(record.title if record else "", entry.get("panel_id", ""))
                    op = row.operator(
                        "bworkflow.panel_library_click",
                        text=("    " * min(entry["depth"] + 1, 4)) + title,
                        icon="ERROR" if not entry["discovered"] else ("CHECKBOX_HLT" if entry["selected"] else "CHECKBOX_DEHLT"),
                        emboss=False,
                    )
                    op.index = entry["index"]

    selected = right.box()
    selected.label(text=f"{workflow.name} 当前勾选")
    if workflow.is_default:
        selected.label(text="默认工作流不显示勾选限制。", icon="INFO")
    elif workflow.panels:
        active_title = ""
        active_panel_id = ""
        if workflow.panels:
            active_index = clamp_index(workflow.active_panel_index, len(workflow.panels))
            active_panel_id = workflow.panels[active_index].panel_id
        if active_panel_id and active_panel_id != "BWFLOW_PT_workflow":
            active_record = find_registry_record(state, active_panel_id)
            active_title = clean_panel_title(active_record.title if active_record else "", active_panel_id)
        active_hint = selected.box()
        active_hint.label(
            text=f"当前高亮: {active_title}" if active_title else "当前没有高亮面板",
            icon="LAYER_ACTIVE" if active_title else "INFO",
        )
        order_box = selected.box()
        order_box.label(text="抽屉顺序操作", icon="SORTALPHA")
        jump_row = order_box.row(align=True)
        top = jump_row.operator("bworkflow.panel_jump_in_workflow", text="置顶当前组", icon="TRIA_UP_BAR")
        top.target = "TOP"
        bottom = jump_row.operator("bworkflow.panel_jump_in_workflow", text="置底当前组", icon="TRIA_DOWN_BAR")
        bottom.target = "BOTTOM"
        move_row = order_box.row(align=True)
        up = move_row.operator("bworkflow.panel_move_in_workflow", text="上移当前组")
        up.direction = "UP"
        down = move_row.operator("bworkflow.panel_move_in_workflow", text="下移当前组")
        down.direction = "DOWN"
        row = order_box.row(align=True)
        row.operator("bworkflow.panel_sort_children_by_default_order", text="子抽屉默认排序", icon="SORTALPHA")
        row = order_box.row(align=True)
        row.operator("bworkflow.panel_clear_workflow", text="清空全部")

        selected_groups = build_selected_panel_groups(state, workflow)
        selected_filter_row = selected.row(align=True)
        selected_filter_row.prop(state, "selected_panel_group_filter_text", text="搜索")
        if getattr(state, "selected_panel_group_filter_text", ""):
            clear_filter = selected_filter_row.operator("bworkflow.clear_panel_group_filter", text="", icon="X")
            clear_filter.target = "SELECTED"
        filtered_selected_groups = filtered_panel_groups(
            selected_groups,
            getattr(state, "selected_panel_group_filter_text", ""),
            cache_key=f"{space_type}:selected",
        )
        visible_selected_groups, selected_page, selected_page_count = paged_panel_groups(
            state, filtered_selected_groups, "selected_panel_group_page", SELECTED_PANEL_GROUP_DRAW_LIMIT
        )
        if selected_page_count > 1:
            page_row = selected.row(align=True)
            page_row.alignment = "CENTER"
            prev_page = page_row.operator("bworkflow.panel_group_page", text="", icon="TRIA_LEFT")
            prev_page.target = "SELECTED"
            prev_page.direction = "PREV"
            page_row.label(text=f"{selected_page + 1}/{selected_page_count}")
            next_page = page_row.operator("bworkflow.panel_group_page", text="", icon="TRIA_RIGHT")
            next_page.target = "SELECTED"
            next_page.direction = "NEXT"
        for group in visible_selected_groups:
            expanded = group["key"] in expanded_selected_keys
            group_box = selected.box() if expanded else selected
            header_row = group_box.row(align=True)
            header_row.operator_context = "INVOKE_DEFAULT"
            expand_icon = "TRIA_DOWN" if expanded else "TRIA_RIGHT"
            group_toggle = header_row.operator(
                "bworkflow.group_expand_toggle",
                text="",
                icon=expand_icon,
                emboss=False,
            )
            group_toggle.group_key = group["key"]
            group_toggle.target = "SELECTED"
            group_icon = panel_group_icon_data(state, group)
            icon_kwargs = {
                "text": group_icon["text"],
                "emboss": False,
                "translate": False,
            }
            if group_icon["icon_value"]:
                icon_kwargs["icon_value"] = group_icon["icon_value"]
            else:
                icon_kwargs["icon"] = group_icon["icon"]
            icon_cell = header_row.row(align=True)
            icon_cell.scale_x = 0.9 if group_icon["icon_value"] or group_icon["icon"] != "NONE" else 0.68
            group_icon_op = icon_cell.operator(
                "bworkflow.select_workflow_panel",
                **icon_kwargs,
            )
            group_icon_op.panel_id = group.get("panel_id", "")
            group_icon_op.tooltip_text = (
                f"\u4e2d\u6587\u540d\u79f0\uff1a{group.get('title', '')}\n"
                f"\u539f\u63d2\u4ef6\u540d\uff1a{group.get('original_title', group.get('title', ''))}"
            )
            group_select = header_row.operator(
                "bworkflow.select_workflow_panel",
                text=group["title"],
                icon="NONE",
                emboss=False,
                translate=False,
            )
            group_select.panel_id = group.get("panel_id", "")
            group_select.tooltip_text = (
                f"\u4e2d\u6587\u540d\u79f0\uff1a{group.get('title', '')}\n"
                f"\u539f\u63d2\u4ef6\u540d\uff1a{group.get('original_title', group.get('title', ''))}"
            )
            header_row.label(text=panel_count_label(group.get("panel_count", 0)), icon="DOT")
            group_up = header_row.operator(
                "bworkflow.panel_move_in_workflow",
                text="",
                icon="TRIA_UP",
                emboss=False,
            )
            group_up.direction = "UP"
            group_up.group_key = group["key"]
            group_down = header_row.operator(
                "bworkflow.panel_move_in_workflow",
                text="",
                icon="TRIA_DOWN",
                emboss=False,
            )
            group_down.direction = "DOWN"
            group_down.group_key = group["key"]
            if expanded:
                for entry in selected_panel_group_entries(state, workflow, group):
                    row_host = group_box.box() if entry.get("is_active", False) else group_box
                    row = row_host.row(align=True)
                    row.operator_context = "INVOKE_DEFAULT"
                    row.alert = not entry["discovered"]
                    select_op = row.operator(
                        "bworkflow.select_workflow_panel",
                        text=("    " * min(entry["depth"] + 1, 4)) + entry["title"],
                        icon="LAYER_ACTIVE" if entry.get("is_active", False) else ("PLUGIN" if entry["discovered"] else "ERROR"),
                        emboss=False,
                    )
                    select_op.panel_id = entry["panel_id"]
                    select_op.tooltip_text = (
                        f"\u4e2d\u6587\u540d\u79f0\uff1a{entry.get('title', '')}\n"
                        f"\u539f\u63d2\u4ef6\u540d\uff1a{panel_group_original_title(state, entry.get('panel_id', ''), entry.get('title', ''))}"
                    )
                    child_up = row.operator(
                        "bworkflow.panel_move_child_in_group",
                        text="",
                        icon="TRIA_UP",
                        emboss=False,
                    )
                    child_up.direction = "UP"
                    child_up.group_key = group["key"]
                    child_up.panel_id = entry["panel_id"]
                    child_down = row.operator(
                        "bworkflow.panel_move_child_in_group",
                        text="",
                        icon="TRIA_DOWN",
                        emboss=False,
                    )
                    child_down.direction = "DOWN"
                    child_down.group_key = group["key"]
                    child_down.panel_id = entry["panel_id"]
    else:
        selected.label(text="当前 Go工作流还没有勾选任何面板。", icon="INFO")
        row = selected.row(align=True)
        row.operator("bworkflow.panel_add_all_to_workflow", text="按默认 N 面板加入")
        row.operator("bworkflow.panel_add_tagged_to_workflow", text="加入标签命中")


def draw_module_template_editor(layout, state):
    layout = begin_settings_module(layout, "脚本模块", "CONSOLE")
    workflow = get_active_workflow(state)
    if workflow is None:
        layout.label(text="请先创建 Go工作流", icon="INFO")
        return

    top = layout.column(align=True)
    top.label(text=f"当前 Go工作流: {workflow.name}", icon="OUTLINER_COLLECTION")
    top.label(text="脚本模块只属于当前工作流；代码可直接保存在插件内，也可以写入 .py 文件。", icon="INFO")

    row = top.row()
    row.template_list(
        "BWFLOW_UL_workflow_modules",
        "",
        workflow,
        "modules",
        workflow,
        "active_module_index",
        rows=7,
    )
    ops = row.column(align=True)
    ops.operator("bworkflow.module_add", text="", icon="ADD")
    ops.operator("bworkflow.module_remove", text="", icon="REMOVE")
    ops.separator()
    move_up = ops.operator("bworkflow.module_move", text="", icon="TRIA_UP")
    move_up.direction = "UP"
    move_down = ops.operator("bworkflow.module_move", text="", icon="TRIA_DOWN")
    move_down.direction = "DOWN"

    if not workflow.modules:
        layout.label(text="当前 Go工作流还没有模块。", icon="INFO")
        return

    module = workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))]
    detail = layout.box()
    detail.label(text="当前模块设置", icon="CONSOLE")
    detail.prop(module, "name", text="模块名称")
    detail.operator("bworkflow.module_assign_default_path", text="按模块名称生成 .py 路径", icon="FILE_TEXT")
    detail.prop(module, "script_path", text="脚本路径")
    detail.prop(module, "enabled", text="启用")
    detail.prop(module, "use_custom_panel", text="需要自定义面板")
    detail.prop(module, "description", text="模块说明")

    actions = layout.box()
    actions.label(text="模块操作", icon="TOOL_SETTINGS")
    row = actions.row(align=True)
    row.operator("bworkflow.module_fill_ai_doc", text="生成 AI 文档", icon="TEXT")
    row.operator("bworkflow.module_copy_ai_doc", text="复制 AI 文档", icon="COPYDOWN")
    row = actions.row(align=True)
    row.operator("bworkflow.module_edit_script_source", text="打开代码编辑", icon="TEXT")
    row.operator("bworkflow.module_paste_script_source", text="从剪贴板载入", icon="PASTEDOWN")
    row = actions.row(align=True)
    row.operator("bworkflow.module_write_template", text="写入 .py 文件", icon="FILE_TICK")
    row = actions.row(align=True)
    row.operator("bworkflow.module_run", text="运行测试", icon="PLAY").module_index = workflow.active_module_index
    actions.operator("bworkflow.script_library_save_current_module", text="保存到脚本库", icon="ASSET_MANAGER")

    if module.script_source.strip():
        actions.label(text=f"当前已保存 {len(module.script_source)} 个字符的代码内容", icon="TEXT")
    else:
        actions.label(text="当前还没有代码内容；可以打开编辑器编写，或从剪贴板载入。", icon="INFO")

    if module_needs_runtime_panel(module):
        actions.label(text="当前模块会在 Go工作流 主面板里显示自定义面板区域。", icon="MENU_PANEL")
    else:
        actions.label(text="当前模块不会在 Go工作流 主面板里额外占用面板位置。", icon="INFO")

    protocol = layout.box()
    protocol.label(text="模块脚本固定入口", icon="INFO")
    protocol.label(text="def run(context, scene, workflow, module):")
    protocol.label(text="    return {'FINISHED'}")
    protocol.label(text="可选: def draw_panel(layout, context, scene, workflow, module, panel_api, module_state):")
    protocol.label(text="panel_api 提供 UI、字段、数据块选择、状态日志与上下文辅助。")
    protocol.label(text="module_state 用于保存当前模块自己的短状态和调试记录。")

    preview = layout.box()
    if module.ai_doc.strip():
        draw_folded_text_block(
            preview,
            state.settings,
            "show_module_ai_doc_preview",
            "AI 辅助说明预览",
            module.ai_doc,
            icon="TEXT",
            expanded_limit=8,
            width=64,
        )
    else:
        preview.label(text="当前还没有生成 AI 文档。点击“生成 AI 文档”后再预览。", icon="INFO")


def draw_preset_editor(layout, state):
    layout = begin_settings_module(layout, "预设管理", "PRESET")
    col = layout.column(align=True)

    special_box = col.box()
    special_box.label(text="特殊预设", icon="SHAPEKEY_DATA")
    special_box.operator(
        "bworkflow.workflow_add_special_preset",
        text="创建arkit形态键工作流参考",
        icon="SHAPEKEY_DATA",
    ).preset_type = SPECIAL_PRESET_ARKIT_52

    export_box = col.box()
    export_box.label(text="导出勾选的工作流", icon="EXPORT")
    if state.workflows:
        for index, workflow in enumerate(state.workflows):
            row = export_box.row(align=True)
            row.prop(workflow, "preset_export_selected", text="")
            row.label(text=workflow.name or f"Workflow {index + 1}", icon="HOME" if workflow.is_default else "FILE_FOLDER")
            row.label(text=f"{len(workflow.panels)} 面板")
            row.label(text=f"{len(workflow.modules)} 模块")
        row = export_box.row(align=True)
        row.operator("bworkflow.preset_export_select_all", text="全选", icon="CHECKBOX_HLT").select = True
        row.operator("bworkflow.preset_export_select_all", text="清空", icon="CHECKBOX_DEHLT").select = False
        export_box.operator("bworkflow.preset_export", text="导出勾选工作流", icon="EXPORT")
    else:
        export_box.label(text="当前没有可导出的工作流。", icon="INFO")

    import_box = col.box()
    import_box.label(text="从预设导入工作流", icon="IMPORT")
    load_row = import_box.row(align=True)
    load_row.operator("bworkflow.preset_load", text="选择 .gwpreset 预设包", icon="FILE_FOLDER")
    load_row.operator("bworkflow.preset_load_from_clipboard", text="", icon="PASTEDOWN")
    if get_preset_import_entries(state):
        load_row.operator("bworkflow.preset_clear_loaded", text="", icon="X")
    preset_cache = get_preset_import_cache(state)
    preset_filepath = preset_cache.get("filepath", "")
    if preset_filepath:
        import_box.label(text=os.path.basename(bpy.path.abspath(preset_filepath)), icon="FILE")

    preset_entries = get_preset_import_entries(state)
    if preset_entries:
        selected_count, total_count = preset_workflow_selection_counts(state)
        import_box.label(text=f"当前选中 {selected_count}/{total_count}", icon="RADIOBUT_ON" if selected_count else "RADIOBUT_OFF")
        selected_index = preset_import_selected_index(state)
        list_box = import_box.box()
        for index, entry in enumerate(preset_entries[:8]):
            workflow = entry.get("workflow", {}) if isinstance(entry, dict) else {}
            name = workflow.get("name", "") or f"工作流 {index + 1}"
            space_type = entry.get("space_type", "VIEW_3D") if isinstance(entry, dict) else "VIEW_3D"
            module_count = len(workflow.get("modules", [])) if isinstance(workflow, dict) else 0
            panel_count = len(workflow.get("panels", [])) if isinstance(workflow, dict) else 0
            row = list_box.row(align=True)
            op = row.operator(
                "bworkflow.preset_select_cached",
                text=name,
                icon="RADIOBUT_ON" if index == selected_index else "RADIOBUT_OFF",
                depress=index == selected_index,
            )
            op.index = index
            row.label(text=SPACE_LABELS.get(space_type, space_type))
            row.label(text=f"{panel_count} 面板")
            row.label(text=f"{module_count} 模块")
        if len(preset_entries) > 8:
            list_box.label(text=f"仅显示前 8/{len(preset_entries)} 个工作流", icon="INFO")
        import_row = import_box.row(align=True)
        import_row.enabled = selected_count > 0
        import_row.operator("bworkflow.preset_import_selected", text="导入当前选中工作流", icon="IMPORT")
    else:
        import_box.label(text="请选择 .gwpreset 预设包，先预览再单独导入。", icon="INFO")

    info = col.box()
    draw_folded_text_block(
        info,
        state.settings,
        "show_help_text_blocks",
        "预设说明",
        "导出会生成 .gwpreset 压缩包；脚本按 .py 文件保存。面板组只使用轻量名称匹配信息，导入时不会覆盖当前 N 面板顺序。",
        icon="INFO",
        expanded_limit=3,
        width=56,
    )


def draw_script_library_editor(layout, state):
    layout = layout.box().column(align=True)
    workflow = get_active_workflow(state)
    box = layout.column(align=True)
    header = box.row(align=True)
    header.label(text="脚本库", icon="FILE_SCRIPT")
    docs = header.operator("wm.url_open", text="腾讯文档", icon="URL")
    docs.url = SCRIPT_LIBRARY_DOC_URL
    box.label(text="把常用脚本先存起来，下次切到别的工作流也能直接复用。")
    if workflow is not None and workflow.modules:
        box.label(text=f"当前可保存来源: {workflow.name} / {workflow.modules[clamp_index(workflow.active_module_index, len(workflow.modules))].name}", icon="INFO")

    split = layout.split(factor=0.50)
    left = split.column(align=True)
    right = split.column(align=True)

    list_box = left.box()
    list_box.label(text="脚本目录", icon="PRESET")
    row = list_box.row()
    row.template_list(
        "BWFLOW_UL_script_library",
        "",
        state,
        "script_library",
        state,
        "script_library_index",
        rows=8,
    )
    ops = row.column(align=True)
    ops.operator("bworkflow.script_library_save_current_module", text="", icon="ADD")
    ops.operator("bworkflow.script_library_remove", text="", icon="REMOVE")
    ops.operator("bworkflow.script_library_refresh", text="", icon="FILE_REFRESH")

    if not state.script_library:
        left.label(text="当前没有脚本库条目，先到“脚本模板”页保存一个。", icon="INFO")
        return

    item = state.script_library[clamp_index(state.script_library_index, len(state.script_library))]
    detail = left.box()
    detail.label(text="脚本详情", icon="TEXT")
    detail.prop(item, "name", text="名称")
    detail.prop(item, "description", text="说明")
    detail.prop(item, "tags", text="标签")
    detail.prop(item, "use_custom_panel", text="载入后显示自定义面板")
    detail.prop(item, "script_path", text="路径")
    detail.prop(item, "text_block_name", text="文本块")
    draw_folded_text_block(
        detail,
        state.settings,
        "show_script_library_source_preview",
        "脚本内容预览",
        item.script_source or "",
        icon="FILE_TEXT",
        expanded_limit=6,
        width=48,
    )
    if item.ai_doc.strip():
        draw_folded_text_block(
            detail,
            state.settings,
            "show_script_library_ai_doc_preview",
            "AI 文档预览",
            item.ai_doc,
            icon="INFO",
            expanded_limit=6,
            width=48,
        )
    action = detail.row(align=True)
    action.operator("bworkflow.script_library_apply_to_module", text="载入到当前模块", icon="IMPORT")
    action.operator("bworkflow.script_library_save_current_module", text="覆盖当前条目", icon="FILE_TICK").overwrite_existing = True
    action.operator("bworkflow.script_library_open_storage_folder", text="打开脚本文件夹", icon="FILE_FOLDER")

    workflow_box = right.box()
    workflow_box.label(text="工作流启用状态", icon="OUTLINER_COLLECTION")
    workflow_box.label(text="按钮会把当前脚本载入对应工作流，或切换该工作流里的启用状态。", icon="INFO")
    if not state.workflows:
        workflow_box.label(text="当前没有工作流。", icon="INFO")
    else:
        workflow_matches = script_library_workflow_match_index(state, item)
        for workflow_index, target_workflow in enumerate(state.workflows):
            match_info = workflow_matches[workflow_index] if workflow_index < len(workflow_matches) else {}
            is_installed = bool(match_info.get("installed", False))
            is_enabled = bool(match_info.get("enabled", False))
            row = workflow_box.row(align=True)
            row.label(text=target_workflow.name, icon="HOME" if target_workflow.is_default else "FILE_FOLDER")
            button_text = "已启用" if is_enabled else "已关闭"
            icon = "CHECKMARK" if is_enabled else "ADD"
            op = row.operator(
                "bworkflow.script_library_toggle_workflow",
                text=button_text,
                icon=icon,
                depress=is_enabled,
            )
            op.workflow_index = workflow_index

def draw_global_settings(layout, state):
    layout = begin_settings_module(layout, "全局设置", "PREFERENCES")
    box = layout.column(align=True)
    box.prop(state.settings, "auto_sync_registry")
    box.prop(state.settings, "show_missing_summary")
    box.prop(state.settings, "runtime_preview_lines")
    box.operator("bworkflow.clear_missing_panel_warnings", text="清除缺失面板提示", icon="HIDE_ON")

    if tuple(getattr(bpy.app, "version", ()) or ()) >= (5, 2, 0):
        icon_box = box.box()
        icon_box.label(text="Blender 5.2 N 面板", icon="MENU_PANEL")
        icon_box.prop(
            bpy.context.preferences.system,
            "show_panel_tabs_compact",
            text="Compact Tabs",
            toggle=True,
        )

    mem_box = box.box()
    mem_box.label(text="内存管理", icon="MEMORY")
    mem_box.operator("bworkflow.release_memory", text="现在释放内存", icon="TRASH")
    mem_box.prop(state.settings, "auto_gc_enabled")
    if state.settings.auto_gc_enabled:
        mem_box.prop(state.settings, "auto_gc_interval")

    danger = box.box()
    danger.alert = True
    danger.label(text="危险操作", icon="ERROR")
    danger.operator("bworkflow.restore_default_n_panels", text="恢复默认 N 面板", icon="FILE_REFRESH")
    disable_op = danger.operator("bworkflow.restore_default_n_panels", text="恢复默认 N 面板并禁用插件", icon="CANCEL")
    disable_op.disable_addon = True
    uninstall_op = danger.operator("bworkflow.restore_default_n_panels", text="恢复默认并尝试卸载插件", icon="TRASH")
    uninstall_op.uninstall_addon = True
    danger.operator("bworkflow.reset_all_settings", text="清除所有设置并恢复默认", icon="TRASH")


class BWFLOW_AddonPreferences(AddonPreferences):
    bl_idname = addon_module_name()

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Go工作流 / Go Workflow 维护", icon="PREFERENCES")
        box.label(text="如果 N 面板没有恢复，先执行恢复按钮，再用 Blender 插件列表卸载。", icon="INFO")
        box.operator("bworkflow.restore_default_n_panels", text="恢复默认 N 面板", icon="FILE_REFRESH")
        danger = box.box()
        danger.alert = True
        op = danger.operator("bworkflow.restore_default_n_panels", text="恢复默认 N 面板并禁用插件", icon="CANCEL")
        op.disable_addon = True
        uninstall_op = danger.operator("bworkflow.restore_default_n_panels", text="恢复默认并尝试卸载插件", icon="TRASH")
        uninstall_op.uninstall_addon = True



class BWFLOW_PT_workflow(Panel):
    bl_idname = "BWFLOW_PT_workflow"
    bl_label = "Go工作流"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = WORKFLOW_CATEGORY
    bl_order = 1

    def draw(self, context):
        state = get_state(context=context)
        layout = self.layout

        if state is None:
            layout.label(text="当前无法读取插件状态。", icon="ERROR")
            return

        if not state.workflows:
            box = layout.box()
            box.label(text="当前没有 Go工作流", icon="INFO")
            box.operator("bworkflow.initialize_defaults", icon="ADD")
            return

        draw_workflow_runtime(layout, state)
        if state.settings.show_settings:
            draw_settings_embedded(layout, state)


class BWFLOW_PT_workflow_image_editor(Panel):
    bl_idname = "BWFLOW_PT_workflow_image_editor"
    bl_label = "Go工作流"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = WORKFLOW_CATEGORY
    bl_order = 1

    def draw(self, context):
        state = get_state(context=context, space_type="IMAGE_EDITOR")
        layout = self.layout

        if state is None:
            layout.label(text="当前无法读取插件状态。", icon="ERROR")
            return

        if not state.workflows:
            box = layout.box()
            box.label(text="当前没有 Go工作流", icon="INFO")
            box.operator("bworkflow.initialize_defaults", icon="ADD")
            return

        draw_workflow_runtime(layout, state)
        if state.settings.show_settings:
            draw_settings_embedded(layout, state)


class BWFLOW_PT_workflow_node_editor(Panel):
    bl_idname = "BWFLOW_PT_workflow_node_editor"
    bl_label = "Go工作流"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = WORKFLOW_CATEGORY
    bl_order = 1

    def draw(self, context):
        state = get_state(context=context, space_type="NODE_EDITOR")
        layout = self.layout

        if state is None:
            layout.label(text="当前无法读取插件状态。", icon="ERROR")
            return

        if not state.workflows:
            box = layout.box()
            box.label(text="当前没有 Go工作流", icon="INFO")
            box.operator("bworkflow.initialize_defaults", icon="ADD")
            return

        draw_workflow_runtime(layout, state)
        if state.settings.show_settings:
            draw_settings_embedded(layout, state)


@persistent
def bworkflow_load_post(_dummy):
    def _initialize_after_load():
        global IS_INITIALIZING_ADDON
        IS_INITIALIZING_ADDON = True
        scenes = iter_available_scenes()
        try:
            for scene in scenes:
                ensure_minimum_setup(scene, restore_global=True, save_state=False)
            scene = safe_context_scene() or (scenes[0] if scenes else None)
            for target_scene in scenes:
                for target_space in iter_supported_space_types():
                    target_state = get_state(scene=target_scene, space_type=target_space)
                    if not workflow_runtime_initialized(target_state):
                        continue
                    rebuild_panel_cache(scene=target_scene, space_type=target_space)
                    refresh_runtime_overrides(
                        scene=target_scene,
                        space_type=target_space,
                        include_script_panels=True,
                    )
                    schedule_deferred_runtime_refresh(
                        scene=target_scene,
                        intervals=(0.25,),
                        space_type=target_space,
                    )
        except Exception:
            traceback.print_exc()
        finally:
            IS_INITIALIZING_ADDON = False
        return None

    try:
        _register_one_shot_timer(_initialize_after_load, first_interval=0.1)
    except Exception:
        traceback.print_exc()


OPERATOR_TOOLTIP_OVERRIDES = {
    "bworkflow.workflow_activate": "切换当前工作流，并按该工作流更新第三方 N 面板的显示范围。",
    "bworkflow.workflow_add": "新建一个空的自定义工作流，不会修改现有工作流。",
    "bworkflow.workflow_add_special_preset": "创建带预置模块和配套数据的专项工作流。",
    "bworkflow.workflow_duplicate": "复制当前工作流的面板、模块和说明，生成独立副本。",
    "bworkflow.workflow_remove": "删除当前工作流及其配置，不会卸载第三方插件。",
    "bworkflow.workflow_move": "调整当前工作流在列表中的顺序，不改变工作流内容。",
    "bworkflow.module_add": "在当前工作流末尾新增一个脚本模块。",
    "bworkflow.module_move": "调整当前脚本模块在工作流中的顺序。",
    "bworkflow.module_run": "执行当前模块绑定的 Python 脚本，并显示运行结果或错误。",
    "bworkflow.script_library_save_current_module": "将当前模块源码保存为脚本库中的 .py 文件，并新增或覆盖脚本库条目。",
    "bworkflow.script_library_apply_to_module": "将选中的脚本库 .py 内容载入当前模块，不会修改原脚本库文件。",
    "bworkflow.script_library_refresh": "重新读取脚本库条目关联的 .py 文件，更新列表中的源码。",
    "bworkflow.script_library_remove": "删除当前脚本库条目，不会删除当前工作流中的模块。",
    "bworkflow.panel_library_click": "选择面板；双击时切换当前工作流是否显示该面板。",
    "bworkflow.panel_group_click": "展开或收起面板大组；双击时整体加入或移出当前工作流。",
    "bworkflow.panel_toggle_for_workflow": "将当前选中面板所属的组件组加入或移出当前工作流。",
    "bworkflow.panel_toggle_group_for_workflow": "将当前大组下的全部抽屉面板加入或移出当前工作流。",
    "bworkflow.panel_add_all_to_workflow": "按 Blender 当前扫描顺序，将发现的第三方抽屉面板加入当前工作流。",
    "bworkflow.panel_add_tagged_to_workflow": "按当前工作流标签筛选，并加入所有命中的面板。",
    "bworkflow.panel_clear_workflow": "清除当前工作流的面板选择，不删除第三方插件面板。",
    "bworkflow.panel_remove_missing_from_workflow": "从当前工作流中移除当前环境无法找到的面板记录。",
    "bworkflow.workflow_dismiss_missing_warning": "仅隐藏当前工作流的缺失面板提示，不删除缺失面板记录。",
    "bworkflow.clear_missing_panel_warnings": "从当前场景所有工作流中移除当前环境找不到的面板记录，不只是隐藏提示。",
    "bworkflow.panel_apply_workflow_order": "将当前面板选择和排序一次性应用到 Blender N 面板。",
    "bworkflow.panel_reset_workflow_order": "按当前扫描结果重建当前工作流的面板组顺序。",
    "bworkflow.panel_jump_in_workflow": "将当前选中的面板组移动到列表顶部或底部。",
    "bworkflow.panel_reverse_workflow_order": "反转当前工作流中的面板组顺序。",
    "bworkflow.preset_export": "将选中的工作流和脚本模块保存为 .gwpreset 压缩预设包。",
    "bworkflow.preset_import": "从 .gwpreset 文件导入工作流到当前编辑器空间。",
    "bworkflow.preset_load": "读取 .gwpreset 并显示其中可单独导入的工作流列表。",
    "bworkflow.preset_import_selected": "将预设列表中当前选中的工作流导入当前编辑器空间。",
    "bworkflow.preset_clear_loaded": "清空当前预设预览列表，不删除已经导入的工作流。",
    "bworkflow.refresh_registry": "重新扫描当前编辑器中的第三方 N 面板并刷新面板库。",
    "bworkflow.restore_default_n_panels": "恢复 Go Workflow 修改过的 N 面板显示和排序状态。",
    "bworkflow.reset_all_settings": "清除 Go Workflow 的工作流、脚本库、面板设置和缓存，并恢复默认状态。",
}


def apply_operator_tooltip_overrides():
    for cls in CLASSES:
        operator_id = getattr(cls, "bl_idname", "")
        if not operator_id or not operator_id.startswith("bworkflow."):
            continue
        description = OPERATOR_TOOLTIP_OVERRIDES.get(operator_id)
        if description:
            cls.bl_description = description
            continue
        if not str(getattr(cls, "bl_description", "") or "").strip():
            label = str(getattr(cls, "bl_label", "") or operator_id)
            cls.bl_description = f"执行“{label}”操作。"


CLASSES = [
    BWFLOW_PG_PanelRecord,
    BWFLOW_PG_ScriptLibraryItem,
    BWFLOW_PG_WorkflowPanel,
    BWFLOW_PG_WorkflowModule,
    BWFLOW_PG_PresetWorkflowItem,
    BWFLOW_PG_Workflow,
    BWFLOW_PG_Settings,
    BWFLOW_PG_State,
    BWFLOW_PG_ShapeKeyInspectorItem,
    BWFLOW_UL_workflows,
    BWFLOW_UL_workflow_panels,
    BWFLOW_UL_panel_library,
    BWFLOW_UL_workflow_modules,
    BWFLOW_UL_script_library,
    BWFLOW_UL_preset_workflows,
    BWFLOW_UL_shape_key_inspector_results,
    BWFLOW_AddonPreferences,
    BWFLOW_OT_refresh_registry,
    BWFLOW_OT_initialize_defaults,
    BWFLOW_OT_reset_all_settings,
    BWFLOW_OT_release_memory,
    BWFLOW_OT_restore_default_n_panels,
    BWFLOW_OT_workflow_activate,
    BWFLOW_OT_workflow_add,
    BWFLOW_OT_workflow_add_special_preset,
    BWFLOW_OT_workflow_duplicate,
    BWFLOW_OT_workflow_remove,
    BWFLOW_OT_workflow_move,
    BWFLOW_OT_workflow_set_default,
    BWFLOW_OT_workflow_clear_description,
    BWFLOW_OT_module_add,
    BWFLOW_OT_module_assign_default_path,
    BWFLOW_OT_module_remove,
    BWFLOW_OT_module_move,
    BWFLOW_OT_module_fill_ai_doc,
    BWFLOW_OT_module_edit_script_source,
    BWFLOW_OT_module_open_script_path,
    BWFLOW_OT_module_import_text_file,
    BWFLOW_OT_module_export_text_file,
    BWFLOW_OT_module_pick_file_path,
    BWFLOW_OT_module_edit_description,
    BWFLOW_OT_module_paste_script_source,
    BWFLOW_OT_module_copy_ai_doc,
    BWFLOW_OT_module_copy_script_source,
    BWFLOW_OT_module_load_script_file,
    BWFLOW_OT_module_write_template,
    BWFLOW_OT_module_run,
    BWFLOW_OT_script_library_save_current_module,
    BWFLOW_OT_script_library_apply_to_module,
    BWFLOW_OT_script_library_toggle_workflow,
    BWFLOW_OT_script_library_remove,
    BWFLOW_OT_script_library_refresh,
    BWFLOW_OT_script_library_open_storage_folder,
    BWFLOW_OT_module_runtime_field_write,
    BWFLOW_OT_module_runtime_action,
    BWFLOW_OT_copy_runtime_error,
    BWFLOW_OT_open_runtime_error_report,
    BWFLOW_OT_native_reference_cleanup,
    BWFLOW_OT_native_reference_viewer,
    BWFLOW_OT_panel_toggle_for_workflow,
    BWFLOW_OT_panel_toggle_group_for_workflow,
    BWFLOW_OT_panel_library_click,
    BWFLOW_OT_panel_add_all_to_workflow,
    BWFLOW_OT_panel_add_current_plugin_to_workflow,
    BWFLOW_OT_panel_toggle_single_for_workflow,
    BWFLOW_OT_group_expand_toggle,
    BWFLOW_OT_panel_match_imported_by_name,
    BWFLOW_OT_panel_group_page,
    BWFLOW_OT_clear_panel_group_filter,
    BWFLOW_OT_select_workflow_panel,
    BWFLOW_OT_panel_group_click,
    BWFLOW_OT_panel_add_tagged_to_workflow,
    BWFLOW_OT_panel_clear_workflow,
    BWFLOW_OT_panel_remove_missing_from_workflow,
    BWFLOW_OT_workflow_dismiss_missing_warning,
    BWFLOW_OT_clear_missing_panel_warnings,
    BWFLOW_OT_export_missing_plugins_csv,
    BWFLOW_OT_panel_reset_workflow_order,
    BWFLOW_OT_panel_jump_in_workflow,
    BWFLOW_OT_panel_reverse_workflow_order,
    BWFLOW_OT_panel_move_in_workflow,
    BWFLOW_OT_panel_move_child_in_group,
    BWFLOW_OT_panel_sort_children_by_default_order,
    BWFLOW_OT_debug_dump_panels,
    BWFLOW_OT_preset_export,
    BWFLOW_OT_preset_import,
    BWFLOW_OT_preset_load,
    BWFLOW_OT_preset_load_from_clipboard,
    BWFLOW_OT_preset_export_select_all,
    BWFLOW_OT_preset_select_all,
    BWFLOW_OT_preset_select_current_space,
    BWFLOW_OT_preset_clear_loaded,
    BWFLOW_OT_preset_select_cached,
    BWFLOW_OT_preset_import_selected,
    BWFLOW_PT_workflow,
    BWFLOW_PT_workflow_image_editor,
    BWFLOW_PT_workflow_node_editor,
]


AUTO_GC_TIMER_HANDLE = None


def _empty_working_set():
    """调用 Windows EmptyWorkingSet API 释放物理内存。

    参考 Mem Reduct 的实现原理：
    1. EmptyWorkingSet / SetProcessWorkingSetSize(-1,-1) 告诉 OS
       将当前进程工作集暂时不用的页面 trim 掉
    2. Windows 立即回收对应物理 RAM，数据仍在虚拟内存中
    3. 后续访问触发 soft page fault 按需加载，几乎无感知

    返回 (释放前_MB, 释放后_MB)，失败/非 Windows 返回 None。
    """
    if not hasattr(ctypes, "windll"):
        return None
    try:
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi

        # 设置正确的函数签名，避免调用约定错误
        kernel32.GetCurrentProcess.restype = ctypes.c_void_p
        psapi.EmptyWorkingSet.argtypes = [ctypes.c_void_p]
        psapi.EmptyWorkingSet.restype = ctypes.c_bool

        h = kernel32.GetCurrentProcess()

        # --- 读取释放前的 WorkingSetSize ---
        # 不用自定义 struct（64位对齐坑多），直接用 psutil 或 CreateToolhelp32Snapshot
        ws_before = _read_working_set_bytes(h)

        # --- 执行 trim ---
        ok = psapi.EmptyWorkingSet(h)
        if not ok:
            # EmptyWorkingSet 可能失败，尝试 SetProcessWorkingSetSize(-1,-1)
            kernel32.SetProcessWorkingSetSize.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_size_t]
            kernel32.SetProcessWorkingSetSize.restype = ctypes.c_bool
            kernel32.SetProcessWorkingSetSize(h, ctypes.c_size_t(-1), ctypes.c_size_t(-1))

        # --- 读取释放后的 WorkingSetSize ---
        ws_after = _read_working_set_bytes(h)

        if ws_before is not None and ws_after is not None:
            return (ws_before / (1024 * 1024), ws_after / (1024 * 1024))
        return None
    except Exception:
        return None


def _read_working_set_bytes(h_process):
    """通过 GetProcessMemoryInfo 读取 WorkingSetSize（字节）。

    使用 pointer-to-buffer 方式避免 struct 对齐陷阱：
    分配一块足够大的 buffer，让 API 直接填充。
    """
    try:
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        # PROCESS_MEMORY_COUNTERS_EX = 10 * SIZE_T + 2 * DWORD ≈ 88 bytes on 64-bit
        # 多分配一些以防万一
        buf = (ctypes.c_byte * 128)()
        # 前 4 字节写 cb = sizeof(PROCESS_MEMORY_COUNTERS_EX) = 80 (64-bit)
        cb = ctypes.c_ulong(80)
        ctypes.memmove(buf, ctypes.addressof(cb), 4)
        psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
        psapi.GetProcessMemoryInfo.restype = ctypes.c_bool
        ok = psapi.GetProcessMemoryInfo(h_process, buf, 128)
        if not ok:
            return None
        # WorkingSetSize 在 PROCESS_MEMORY_COUNTERS 中偏移 16 (64-bit)
        # cb(4) + PageFaultCount(4) + PeakWorkingSetSize(8) = 16
        ws = ctypes.c_ulonglong.from_buffer(buf, 16)
        return ws.value
    except Exception:
        return None


def _auto_gc_run():
    """执行一次自动 GC：EmptyWorkingSet trim。"""
    _empty_working_set()


def _auto_gc_timer():
    """定期检查 auto_gc_enabled，触发时执行内存回收"""
    try:
        scene = safe_context_scene()
        if scene is None:
            return 5.0
        state = get_state(scene=scene)
        if state is None or not state.settings.auto_gc_enabled:
            return 5.0
    except Exception:
        return 5.0
    _auto_gc_run()
    try:
        interval = max(5.0, float(getattr(state.settings, "auto_gc_interval", 15) or 15))
    except (TypeError, ValueError):
        interval = 15.0
    return interval


def _start_auto_gc_timer():
    global AUTO_GC_TIMER_HANDLE
    _stop_auto_gc_timer()
    AUTO_GC_TIMER_HANDLE = _auto_gc_timer
    try:
        bpy.app.timers.register(_auto_gc_timer, first_interval=10.0)
    except Exception:
        pass


def _stop_auto_gc_timer():
    global AUTO_GC_TIMER_HANDLE
    if AUTO_GC_TIMER_HANDLE is not None:
        try:
            bpy.app.timers.unregister(AUTO_GC_TIMER_HANDLE)
        except Exception:
            pass
        AUTO_GC_TIMER_HANDLE = None


def register_shape_key_capture_scene_props():
    bpy.types.Scene.sk_capture_interval = FloatProperty(
        name="采样间隔",
        description="每次采样之间的秒数",
        default=1.0 / 60.0,
        min=0.001,
        soft_min=0.001,
        soft_max=0.1,
        precision=4,
    )
    bpy.types.Scene.sk_capture_include_basis = BoolProperty(
        name="包含 Basis",
        description="同时采集 Basis 形态键",
        default=False,
    )
    bpy.types.Scene.sk_capture_only_selected = BoolProperty(
        name="仅选中对象",
        description="只采集当前选中的带形态键网格对象",
        default=False,
    )
    bpy.types.Scene.sk_capture_skip_separator_keys = BoolProperty(
        name="跳过分组键",
        description="跳过 '-- ARKIT --' 这类分组/标签形态键",
        default=True,
    )
    bpy.types.Scene.sk_capture_arkit_only = BoolProperty(
        name="仅 ARKit 52 键",
        description="只记录 ARKit 52 个主键",
        default=False,
    )
    bpy.types.Scene.sk_capture_export_denoised = BoolProperty(
        name="输出降噪曲线",
        description="结束采集时自动输出 One Euro 降噪版 JSONL/CSV",
        default=True,
    )
    bpy.types.Scene.sk_capture_denoise_deadband = FloatProperty(
        name="死区阈值",
        description="小于此值的微小抖动会被归零",
        default=0.002,
        min=0.0,
        soft_max=0.05,
        precision=4,
    )
    bpy.types.Scene.sk_capture_denoise_min_cutoff = FloatProperty(
        name="One Euro Min Cutoff",
        description="基础截止频率",
        default=1.2,
        min=0.01,
        soft_max=10.0,
        precision=3,
    )
    bpy.types.Scene.sk_capture_denoise_beta = FloatProperty(
        name="One Euro Beta",
        description="动态跟手强度",
        default=0.15,
        min=0.0,
        soft_max=5.0,
        precision=3,
    )
    bpy.types.Scene.sk_capture_denoise_d_cutoff = FloatProperty(
        name="One Euro D Cutoff",
        description="速度项的滤波截止频率",
        default=1.0,
        min=0.01,
        soft_max=10.0,
        precision=3,
    )
    bpy.types.Scene.sk_capture_running = BoolProperty(name="采集运行中", default=False)
    bpy.types.Scene.sk_capture_status = StringProperty(name="采集状态", default="空闲")
    bpy.types.Scene.sk_capture_session_dir = StringProperty(name="会话目录", default="")
    bpy.types.Scene.sk_capture_sample_count = IntProperty(name="样本数", default=0, min=0)
    bpy.types.Scene.sk_replay_file_path = StringProperty(
        name="记录文件",
        description="选择 samples.jsonl 或 samples_denoised.jsonl 文件",
        default="",
        subtype="FILE_PATH",
    )
    bpy.types.Scene.sk_replay_target_object = PointerProperty(name="目标物体", type=bpy.types.Object)
    bpy.types.Scene.sk_replay_source_object = StringProperty(
        name="源对象名",
        description="不填时默认使用文件中的第一个 objects 项",
        default="",
    )
    bpy.types.Scene.sk_replay_strength = FloatProperty(
        name="投射强度",
        description="将记录值乘以该强度再写入目标形态键",
        default=1.0,
        min=0.0,
        soft_max=2.0,
        precision=3,
    )
    bpy.types.Scene.sk_replay_speed = FloatProperty(
        name="回放倍速",
        description="实时回放倍速",
        default=1.0,
        min=0.01,
        soft_max=4.0,
        precision=3,
    )
    bpy.types.Scene.sk_replay_loop = BoolProperty(name="循环回放", description="播放到结尾后重新从头播放", default=False)
    bpy.types.Scene.sk_replay_sample_index = IntProperty(
        name="当前样本",
        description="用于单样本应用或回放起点",
        default=0,
        min=0,
    )
    bpy.types.Scene.sk_replay_key_set = StringProperty(
        name="验证套件",
        description="数据回放时验证全部、ARKit 或 MMD 形态键",
        default="AUTO",
    )
    bpy.types.Scene.sk_replay_running = BoolProperty(name="回放运行中", default=False)
    bpy.types.Scene.sk_replay_status = StringProperty(name="回放状态", default="空闲")
    bpy.types.Scene.sk_replay_mapped_count = IntProperty(name="映射键数", default=0, min=0)
    bpy.types.Scene.sk_replay_total_source_keys = IntProperty(name="源键数", default=0, min=0)
    bpy.types.Scene.sk_replay_total_samples = IntProperty(name="总样本数", default=0, min=0)


def unregister_shape_key_capture_scene_props():
    prop_names = (
        "sk_capture_interval",
        "sk_capture_include_basis",
        "sk_capture_only_selected",
        "sk_capture_skip_separator_keys",
        "sk_capture_arkit_only",
        "sk_capture_export_denoised",
        "sk_capture_denoise_deadband",
        "sk_capture_denoise_min_cutoff",
        "sk_capture_denoise_beta",
        "sk_capture_denoise_d_cutoff",
        "sk_capture_running",
        "sk_capture_status",
        "sk_capture_session_dir",
        "sk_capture_sample_count",
        "sk_replay_file_path",
        "sk_replay_target_object",
        "sk_replay_source_object",
        "sk_replay_strength",
        "sk_replay_speed",
        "sk_replay_loop",
        "sk_replay_sample_index",
        "sk_replay_key_set",
        "sk_replay_running",
        "sk_replay_status",
        "sk_replay_mapped_count",
        "sk_replay_total_source_keys",
        "sk_replay_total_samples",
    )
    for prop_name in prop_names:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)


def register():
    global LOAD_HANDLER_REGISTERED, IS_INITIALIZING_ADDON
    IS_INITIALIZING_ADDON = True

    try:
        capture_pre_go_workflow_state()
        apply_operator_tooltip_overrides()
        for cls in CLASSES:
            bpy.utils.register_class(cls)

        for prop_name in SPACE_STATE_PROP_NAMES.values():
            setattr(bpy.types.Scene, prop_name, PointerProperty(type=BWFLOW_PG_State))
        bpy.types.Scene.bwflow_shape_key_inspector_items = CollectionProperty(type=BWFLOW_PG_ShapeKeyInspectorItem)
        bpy.types.Scene.bwflow_shape_key_inspector_index = IntProperty(default=-1, update=on_shape_key_inspector_index_changed)
        register_shape_key_capture_scene_props()

        scenes = iter_available_scenes()
        for scene in scenes:
            ensure_minimum_setup(scene, restore_global=True, save_state=False)

        if bworkflow_load_post not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(bworkflow_load_post)
            LOAD_HANDLER_REGISTERED = True

        scene = safe_context_scene() or (scenes[0] if scenes else None)
        for target_scene in scenes:
            for target_space in iter_supported_space_types():
                target_state = get_state(scene=target_scene, space_type=target_space)
                if not workflow_runtime_initialized(target_state):
                    continue
                rebuild_panel_cache(scene=target_scene, space_type=target_space)
                refresh_runtime_overrides(
                    scene=target_scene,
                    space_type=target_space,
                    include_script_panels=True,
                )
                schedule_deferred_runtime_refresh(
                    scene=target_scene,
                    intervals=(0.25,),
                    space_type=target_space,
                )
    finally:
        IS_INITIALIZING_ADDON = False

    _start_auto_gc_timer()


def unregister():
    global LOAD_HANDLER_REGISTERED, MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE, PANEL_CUSTOM_ICON_PREVIEWS

    try:
        quarantine_broken_panel_polls()
    except Exception:
        traceback.print_exc()

    _stop_auto_gc_timer()

    try:
        _cancel_tracked_one_shot_timers()
    except Exception:
        traceback.print_exc()
    if PANEL_CUSTOM_ICON_PREVIEWS is not None:
        try:
            bpy.utils.previews.remove(PANEL_CUSTOM_ICON_PREVIEWS)
        except Exception:
            pass
        PANEL_CUSTOM_ICON_PREVIEWS = None
        PANEL_CUSTOM_ICON_CACHE.clear()
    PANEL_GROUP_ICON_CACHE_BY_SPACE.clear()
    try:
        drain_validation_timer_callbacks()
    except Exception:
        traceback.print_exc()
    try:
        cleanup_module_runtimes(context=getattr(bpy, "context", None))
    except Exception:
        traceback.print_exc()
    try:
        drain_validation_timer_callbacks()
    except Exception:
        traceback.print_exc()
    try:
        _cancel_tracked_one_shot_timers()
    except Exception:
        traceback.print_exc()

    scenes = list(iter_available_scenes())
    for scene in scenes:
        try:
            save_global_workflow_state_now(scene)
            break
        except Exception:
            traceback.print_exc()
    for scene in scenes:
        try:
            restore_default_n_panel_state(
                scene=scene,
                disable_filters=True,
                switch_workflow=False,
                sync_registry_after_restore=False,
            )
        except Exception:
            traceback.print_exc()
    if not scenes:
        try:
            restore_default_n_panel_state(
                disable_filters=True,
                switch_workflow=False,
                sync_registry_after_restore=False,
            )
        except Exception:
            traceback.print_exc()
    try:
        unregister_shape_key_capture_scene_props()
    except Exception:
        traceback.print_exc()
    try:
        uninstall_panel_poll_overrides()
    except Exception:
        traceback.print_exc()
    try:
        restore_problematic_panel_draw_callbacks()
    except Exception:
        traceback.print_exc()
    try:
        clear_panel_order_overrides()
    except Exception:
        traceback.print_exc()
    FILE_TEXT_CACHE.clear()
    FILE_JSON_CACHE.clear()
    IMAGE_PREVIEW_ICON_CACHE.clear()
    MODULE_RUNTIME_NAMESPACE_CACHE.clear()
    MODULE_SOURCE_TEXT_CACHE.clear()
    MODULE_RUNTIME_FIELD_INIT_CACHE.clear()
    MODULE_RUNTIME_VOLATILE_STORE.clear()
    MODULE_RUNTIME_FIELD_SYNC_QUEUE.clear()
    MODULE_RUNTIME_FIELD_SYNC_TIMER_ACTIVE = False
    BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE["signature"] = None
    BUILTIN_SCRIPT_LIBRARY_PAYLOAD_CACHE["payloads"] = []
    MODULE_RUNTIME_CLEANUP_CACHE.clear()
    try:
        if LOAD_HANDLER_REGISTERED and bworkflow_load_post in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(bworkflow_load_post)
    except Exception:
        traceback.print_exc()
    LOAD_HANDLER_REGISTERED = False

    for prop_name in SPACE_STATE_PROP_NAMES.values():
        try:
            if hasattr(bpy.types.Scene, prop_name):
                delattr(bpy.types.Scene, prop_name)
        except Exception:
            traceback.print_exc()
    for prop_name in ("bwflow_shape_key_inspector_items", "bwflow_shape_key_inspector_index"):
        try:
            if hasattr(bpy.types.Scene, prop_name):
                delattr(bpy.types.Scene, prop_name)
        except Exception:
            traceback.print_exc()

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        except Exception:
            traceback.print_exc()
    clear_pre_go_workflow_state()


if __name__ == "__main__":
    register()
